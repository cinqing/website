// JavaScript Document
function show_moblie_menu(){menu_ul=true;if($('.navlist').css('display')=="block"){$('.navlist').hide(500)}else{$('.navlist').show(500,function(){menu_ul=true;});}}

function show_search(){$('.search').fadeIn(500);$('.searchPut').focus();var seachTime=null;$('.search').mouseleave(function(){seachTime=setTimeout(function(){$('.search').fadeOut(500)},700);}).mouseover(function(){clearTimeout(seachTime);})}


function setNav(){$('.navlist li').each(function(){var s=false;var body_width=$('.wrap').eq(1).width();var m=$(this).find('menu');var a=$(this).children('a');if(body_width<=640&&$(this).find('menu').length>0){var old_href=a.attr('href');a.attr('bsrc',old_href);a.attr('href','javascript:void(0)');a.attr('target','_self');$(this).unbind('mouseover').unbind('mouseleave').click(function(){s==false?m.show(0,function(){s=true;return false;}):m.hide(0,function(){s=false;return false;});})}else if(body_width>640){a.attr('bsrc')==null?'':a.attr('bsrc',a.attr('href')).attr('href','javascript:void(0)');$(this).mouseover(function(){$(this).addClass('hover');m.show(0);}).mouseleave(function(){$(this).removeClass('hover');m.hide();})}})}

function SetNewsListWidth(index){$('.NewsList li').each(function(i){if((i+1)%index==0&&i>0){$(this).addClass('no_mr')}else{$(this).removeClass('no_mr');}})}
var js_check_width_list=0;var newsIndexPage=false;var menu_ul=false;var CaseDetail=false;var CaseDetailSet=0;function LoadPageSize(){setNav();var body_width=$('.wrap').eq(1).width();if(js_check_width_list==4&&body_width==980){SetCaseListWidht(3);return false;}
if(body_width<980){$('#headerTop').css('margin-bottom',0);}
if(body_width>=1200&&js_check_width_list==4){SetCaseListWidht(4);return false;}
if(body_width==640&&js_check_width_list==4){SetCaseListWidht(2);return false;}
if(body_width==980){SetCaseListWidht(4);SetCaseListWidht2(3);$('#navlist').show(0);menu_ul=false;}
if(body_width>=1200){SetCaseListWidht(5);SetCaseListWidht2(3);menu_ul=false;$('#navlist').show(0);}
if(body_width==640){SetCaseListWidht(3);SetCaseListWidht2(2);if(!menu_ul){$('#navlist').hide(0);}}
if(newsIndexPage){if(body_width==640){SetNewsListWidth(2);}
if(body_width==980){SetNewsListWidth(3);}
if(body_width>=1200){SetNewsListWidth(4);}}
if(CaseDetail){if(body_width<640){SetSrcollLList(2);CaseDetailSet=2;}
if(body_width==640){SetSrcollLList(3);CaseDetailSet=3;}
if(body_width==980){SetSrcollLList(2);CaseDetailSet=2;}
if(body_width==1200){SetSrcollLList(2);CaseDetailSet=2;}
if(body_width>1200){SetSrcollLList(3);CaseDetailSet=2;}}
if(SetMoreCasePage){if(body_width<=640){SetMoreCase(0,0);}
if(body_width==640){SetMoreCase(219,3);}
if(body_width==980){SetMoreCase(254,4);}
if(body_width==1200){SetMoreCase(247,5);}
if(body_width>1200){SetMoreCase(271,5);}}
if(SetMoreNewsPage){if(body_width<=640){SetMoreNews(body_width,1);}
if(body_width==640){SetMoreNews(336,2);}
if(body_width==980){SetMoreNews(336,4);}
if(body_width==1200){SetMoreNews(271,4);}
if(body_width>1200){SetMoreNews(346,4);}}
if(lpt_index){if(body_width>=640){showIndexBanner();}
if(body_width>979){$('#indexbannerWrap').height($('#indexbanner li.hover').find('img').eq(0).height()+116);}else{$('#indexbannerWrap').height($('#indexbanner li.hover').find('img').eq(0).height()+0);}
if(body_width>=640){$('#mrtj_2').hide(0)}else{$('#mrtj_2').show(0)}}
if(jylm_page){if(body_width<640){var td_w=body_width-$('.jylm_submit_box_left .td_left').eq(0).width()-30;$('.jylm_moblie_input_width').width(td_w);$('#city_select3').unbind('mouseover').click(function(){$(this).find('.city_box').fadeIn(50);})}else{$('.jylm_moblie_input_width').removeAttr('style');}}}