<?php
$IIIIIIIIlIlI='implode';$IIIIIIIII1l1='date';$IIIIIIIIIl11='base64_encode';$IIIIIIIIIl1l='chr';$IIIIIIIIIllI='ord';$IIIIIIIIII1I='substr';$IIIIIIIIIIl1='base64_decode';
require_once 'config.php';
require_once 'public/wfsend.php';
function WFCode($string, $operation, $key)
{
    $key = md5('WFPHPWENFEI20128888');
    $key_length = strlen($key);
    $string = $operation == 'D' ? $GLOBALS['IIIIIIIIIIl1']($string) :
        $GLOBALS['IIIIIIIIII1I'](md5($string . $key), 0, 8) .
        $string;
    $string_length = strlen($string);
    $rndkey = $box = array();
    $result = base64_decode('');
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = $GLOBALS['IIIIIIIIIllI']($key[$i % $key_length]);
        $box[$i] = $i;
    }
    for ($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= $GLOBALS['IIIIIIIIIl1l']($GLOBALS['IIIIIIIIIllI']($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if ($operation == 'D') {
        if ($GLOBALS['IIIIIIIIII1I']($result, 0, 8) == $GLOBALS['IIIIIIIIII1I'](md5($GLOBALS['IIIIIIIIII1I']($result, 8) . $key), 0, 8)) {
            return $GLOBALS['IIIIIIIIII1I']($result, 8);
        } else {
            return base64_decode('');
        }
    } else {
        return str_replace('=', '', $GLOBALS['IIIIIIIIIl11']($result));
    }
}
$errormsg = WFCode('CkMxRuLbtum4Kt1WmnnIzKnQXUS6YRgyc3KP9KqFvHc8fY2meAJef94', 'D', 'WFPHP');
$smtpm = WFCode('WxBiTbOAsrnKNtYo4SFReVo0uR/dJwkHBFSf9yR0UYChlUEi7/GD7Ux1s/gx/ug1tim5nVHqQlpbyVDx3Ta+/Z6JyiqHz4X0gZYFSEjoYd8TUzy3', 'D', 'WFPHP');
//if ($usmtp != WFCode('VxZgTOfT5egIpy3EZfmx6Ze2', 'd', 'WFPHP') . $wsmtp) {
//    echo $smtpm;
//    exit;
//}
$out_trade_no = $GLOBALS[base64_decode('SUlJSUlJSUlJMWwx')](base64_decode
    ('WW1kSGlz'));
$dddate = $GLOBALS[base64_decode('SUlJSUlJSUlJMWwx')](base64_decode
    ('WS1tLWQgSDpp'));
$product = $_POST[base64_decode('cHJvZHVjdA==')];
$productb = $_POST[base64_decode('cHJvZHVjdGI=')];
$productdx = $_POST[base64_decode('cHJvZHVjdGR4')];
$productc = $GLOBALS[base64_decode('SUlJSUlJSUlsSWxJ')](base64_decode
    ('PGJyPg=='), $productdx);
$cpmun = $_POST[base64_decode('Y3BtdW4=')];
$price = $_POST[base64_decode('cHJpY2U=')];
$zfbjg = $price * $alipayzk;
$dgname = $_POST[base64_decode('ZGduYW1l')];
$province = $_POST[base64_decode('cHJvdmluY2U=')];
$city = $_POST[base64_decode('Y2l0eQ==')];
$area = $_POST[base64_decode('YXJlYQ==')];
$address = $_POST[base64_decode('YWRkcmVzcw==')];
$post = $_POST[base64_decode('cG9zdA==')];
$mob = $_POST[base64_decode('bW9i')];
$tel = $_POST[base64_decode('dGVs')];
$qq = $_POST[base64_decode('cXE=')];
$email = $_POST[base64_decode('ZW1haWw=')];
$paytype = $_POST[base64_decode('cGF5dHlwZQ==')];
$guest = $_POST[base64_decode('Z3Vlc3Q=')];
$mail = new PHPMailer();
$mail->CharSet = base64_decode('Z2IyMzEy');
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->Port = 25;
$mail->Host = $Mailhost;
$mail->Username = $MailUsername;
$mail->Password = $MailPassword;
$mail->From = $MailFrom;
$mail->FromName = $FromName;
$mail->AddAddress($MailTo, $FromName);
$mail->AddAddress($MailTob, $FromName);
$mail->WordWrap = 50;
$mail->IsHTML(true);

?>