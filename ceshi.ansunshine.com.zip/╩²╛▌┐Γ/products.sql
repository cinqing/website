-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2020-10-25 10:15:54
-- 服务器版本： 5.5.62-log
-- PHP Version: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mono`
--

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) NOT NULL,
  `imgname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `imgtxt` varchar(100) CHARACTER SET utf8 NOT NULL,
  `function` varchar(100) CHARACTER SET utf8 NOT NULL,
  `href` varchar(100) CHARACTER SET utf8 NOT NULL,
  `kind` varchar(100) CHARACTER SET utf8 NOT NULL,
  `price` float DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `products`
--

INSERT INTO `products` (`id`, `imgname`, `imgtxt`, `function`, `href`, `kind`, `price`) VALUES
(1, '201709181650336813.png\r\n', '美百颜弹润紧致修护霜', '多效修护 击退暗沉细纹', 'quzhou.php', '去皱', 920),
(2, '2017091816514310395.png', '美百颜焕肌精华液', '水感透白 奢华成分自愈肌础', 'quzhou1.php', '去皱', 590),
(3, '201801231551266532.png', '美百颜玛瑞安美白祛斑霜', '直击斑源 锻造无暇美肌', 'quban.php', '去斑', 920),
(4, '2019112815352619149.png', '美百颜莹润紧致多肽面膜', '时光“膜”法 绽现无龄少女肌', 'bushuimask.php', '护肤', 135),
(5, '2019062818275717146.png', '美百颜玻尿酸水润护肤套盒', '快渗肌底 给肌肤满分水润', 'roufushui.php', '护肤', 404),
(6, '201911151139436401.png', '氨基酸温和洁面乳', '温和洁净 还肌肤一个“清”白', 'jiemian.php', '护肤', 138),
(8, '2018071313360210203.png', '美百颜燕窝胶原蛋白肽果饮', '每天一瓶 维稳肌肤年轻态', 'jiaoyuandanbai.php', '美容', 398),
(9, '201801231552237628.png', '人参护肤甘油', '加倍滋润 抗干燥的“守护器”', 'ganyou.php', '护肤', 99);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
