-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2020-10-25 10:15:29
-- 服务器版本： 5.5.62-log
-- PHP Version: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mono`
--

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) NOT NULL,
  `imgname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `imgtxt` varchar(100) CHARACTER SET utf8 NOT NULL,
  `function` varchar(100) CHARACTER SET utf8 NOT NULL,
  `href` varchar(100) CHARACTER SET utf8 NOT NULL,
  `kind` varchar(100) CHARACTER SET utf8 NOT NULL,
  `price` float DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `products`
--

INSERT INTO `products` (`id`, `imgname`, `imgtxt`, `function`, `href`, `kind`, `price`) VALUES
(1, '201709181650336813.png\r\n', '美百颜弹润紧致修护霜', '多效修护 击退暗沉细纹', 'quzhou.php', '去皱', 920),
(2, '2017091816514310395.png', '美百颜焕肌精华液', '水感透白 奢华成分自愈肌础', 'quzhou1.php', '去皱', 590),
(3, '201801231551266532.png', '美百颜玛瑞安美白祛斑霜', '直击斑源 锻造无暇美肌', 'quban.php', '去斑', 920),
(4, '2019112815352619149.png', '美百颜莹润紧致多肽面膜', '时光“膜”法 绽现无龄少女肌', 'bushuimask.php', '护肤', 135),
(5, '2019062818275717146.png', '美百颜玻尿酸水润护肤套盒', '快渗肌底 给肌肤满分水润', 'roufushui.php', '护肤', 404),
(6, '201911151139436401.png', '氨基酸温和洁面乳', '温和洁净 还肌肤一个“清”白', 'jiemian.php', '护肤', 138),
(8, '2018071313360210203.png', '美百颜燕窝胶原蛋白肽果饮', '每天一瓶 维稳肌肤年轻态', 'jiaoyuandanbai.php', '美容', 398),
(9, '201801231552237628.png', '人参护肤甘油', '加倍滋润 抗干燥的“守护器”', 'ganyou.php', '护肤', 99);

-- --------------------------------------------------------

--
-- 表的结构 `qzorder`
--

CREATE TABLE IF NOT EXISTS `qzorder` (
  `id` int(10) NOT NULL,
  `name` varchar(10) CHARACTER SET utf8 NOT NULL,
  `mobile` double NOT NULL,
  `productname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `province` varchar(20) CHARACTER SET utf8 NOT NULL,
  `city` varchar(20) CHARACTER SET utf8 NOT NULL,
  `area` varchar(20) CHARACTER SET utf8 NOT NULL,
  `address` varchar(100) CHARACTER SET utf8 NOT NULL,
  `paytype` varchar(10) CHARACTER SET utf8 NOT NULL,
  `code` varchar(20) CHARACTER SET utf8 NOT NULL,
  `total` varchar(100) NOT NULL,
  `productnum` varchar(100) NOT NULL,
  `beizhu` varchar(100) CHARACTER SET utf8 NOT NULL,
  `datetimes` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `qzorder`
--

INSERT INTO `qzorder` (`id`, `name`, `mobile`, `productname`, `province`, `city`, `area`, `address`, `paytype`, `code`, `total`, `productnum`, `beizhu`, `datetimes`) VALUES
(22, '张飞', 15687414528, '舒润洁面乳', '天津市', '市辖区', '和平区', '公关大道20号', '货到付款', '2721', '774', '9', '', '2020-04-24 09:20:07'),
(21, '林芝否', 13475895487, '舒润洁面乳', '辽宁省', '沈阳市', '市辖区', '大同路星光大道20号', '货到付款', '4167', '86', '1', '', '2020-04-22 09:16:57'),
(20, '林芝', 13475895487, '舒润洁面乳', '内蒙古自治区', '呼和浩特市', '市辖区', '大同路20号', '货到付款', '0004', '86', '1', '', '2020-04-22 09:09:20'),
(18, '练习', 13475895487, '舒润洁面乳', '山西省', '太原市', '市辖区', '的地点方法', '货到付款', '2551', '516', '6', '', '2020-04-22 08:59:55'),
(19, '林芝', 13475895487, '舒润洁面乳', '河北省', '石家庄市', '市辖区', '大同路20号', '货到付款', '0978', '86', '1', '', '2020-04-22 09:07:33'),
(16, '小虎牙', 13425687452, '', '天津市', '市辖区', '和平区', '马大大', '货到付款', '1478', '', '', '', '2020-04-21 02:15:16'),
(17, '练习', 13475895487, '舒润洁面乳', '北京市', '市辖区', '东城区', '的地点方法', '货到付款', '8022', '344', '4', '', '2020-04-22 08:50:33'),
(14, '小你', 13729006545, 'pname', '天津市', '市辖区', '和平区', '当成区', '货到付款', '3616', 'count', 'pnum', '', '2020-04-20 09:39:22'),
(15, '小虎牙', 13425687452, '', '北京市', '市辖区', '东城区', '马大大', '货到付款', '8037', '', '', '', '2020-04-21 01:52:50'),
(23, '王小仙', 15898741542, '', '天津市', '市辖区', '和平区', '和平大道', '0', '6486', '', '', '尽快', '2020-04-25 09:46:04'),
(24, '王小仙', 15898741542, '舒润滋养面膜', '河南省', '郑州市', '市辖区', '和平大道', '0', '1590', '128', '1', '尽快', '2020-04-25 09:55:02'),
(25, '王红', 15245789542, '舒润滋养面膜', '河南省', '郑州市', '市辖区', '大地方', '货到付款', '2674', '128', '1', '尽快吧', '2020-04-26 06:55:36'),
(26, '翘楚', 13752485264, '舒润滋养面膜', '天津市', '市辖区', '和平区', '天河大道39号天贵花园1栋', '货到付款', '0191', '128', '1', '尽快发货', '2020-04-28 01:34:34'),
(27, '翘楚', 13752485264, '舒润洁面乳', '天津市', '市辖区', '和平区', '天河大道39号天贵花园1栋', '货到付款', '2650', '86', '1', '', '2020-04-28 02:32:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qzorder`
--
ALTER TABLE `qzorder`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `qzorder`
--
ALTER TABLE `qzorder`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
