﻿<?php
	include_once './IpLocation.php';
	$IpLocation = new IpLocation();
	$is_mobile=$IpLocation->checkmobile();
	//验证手机，如果不是手机，则跳转到审核页
	if(!$is_mobile){ 
	//跳转  
	header('Location:http://ceshi.ansunshine.com/mono/index.php'); 
	exit;}

		header('Location:http://ceshi.ansunshine.com/m_mono/index.php'); 
	
	
?>

<!--复制手机端完整代码-->



		