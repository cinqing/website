// 悬浮导航条
	$(window).scroll(function() {
		var top = $(window).scrollTop();
		if (top >= 240) {
			$(".header").hide();
			$(".fixed_header").show().addClass("fixed");

		} else if (top <= 60) {
			$(".fixed_header").hide()
			$(".header").show();
		}

		// if (top >= 900) {
		// 	$(".Online").show()
		// } else {
		// 	$(".Online").hide()
		// }
	});
	
	
	// 导航下拉
	$(".drop-down").mouseover(function() {
		$(".nav_drop-down").show()
	})
	$(".nav_drop-down").mouseout(function() {
		$(".nav_drop-down").hide()
	})
	
	$(".fixed_header .drop-down").mouseover(function() {
		$(".fixed_nav_drop-down").show()
		$(".fixed_nav_drop-down").css({
			"top": "60px",
			"position": "fixed"
		})
	})
	$(" fixed_header .nav_drop-down").mouseout(function() {
		$(".nav_drop-down").hide()
	})
	
	// 显示与隐藏在线咨询弹窗
	$(".line_btn").on('click', function() {
		$('.Online_win').show()
	})
	$(".ico_off").on('click', function() {
		$('.Online_win').hide()
	})
	
	// 显示与隐藏在线咨询弹窗
	$(".new_box").on('click', function() {
		$('.Online_win').show()
	})