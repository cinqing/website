// $(window).scroll(function() {
// 		var top = $(window).scrollTop();
// 		if (top >= 900) {
// 			$(".Online").show()
// 		} else {
// 			$(".Online").hide()
// 		}
// 	});


// 轮播图
var swiper = new Swiper('.swiper-container', {
	pagination: '.swiper-pagination',
	// nextButton: '.swiper-button-next',
	// prevButton: '.swiper-button-prev',
	paginationClickable: true,
	spaceBetween: 0,
	centeredSlides: true,
	autoplay: 5000,
	autoplayDisableOnInteraction: false,
	onTransitionEnd: function(swiper) {
		if (swiper.activeIndex == 1) {
			$(".slide2").children('.banner_con').children('.banner_title_e').addClass('wow fadeInUp animated animated')
			$(".slide2").children('.banner_con').children('.banner_title_eng').addClass('wow fadeInLeft animated animated')
			$(".slide2").children('.banner_con').children('.banner_title_ch').addClass('wow fadeInUp animated animated')
			$(".slide2").children('.banner_con').children('a').addClass('wow fadeInUp animated animated')
		}
		if (swiper.activeIndex == 2) {
			$(".slide3").children('.banner_con').children('.banner_title_e').addClass('wow fadeInUp animated animated')
			$(".slide3").children('.banner_con').children('.banner_title_eng').addClass('wow fadeInUp animated animated')
			$(".slide3").children('.banner_con').children('.banner_title_ch').addClass('wow fadeInUp animated animated')
			$(".slide3").children('.banner_con').children('.banner_buy_btn').addClass('wow fadeInUp animated animated')
			$(".slide3").children('.banner_pro').addClass('wow fadeInUp animated animated')
		}
	}
});

// 执行滚动动画
if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {
	new WOW().init();
};


// 礼遇切换
$(function() {
	$(".ly_icons>ul>li").mouseenter(function() {
		//alert($(this).index())
		var index = $(this).index();
		$(".ly_tit>ul>li:eq(" + index + ")").show().siblings("li").hide()
	});
});



$(".Online").on('click', function() {
	$(".Online_win").show()
})

// 显示与隐藏在线咨询弹窗
$(".ico_off").on('click', function() {
	$('.Online_win').hide()
})
$(".new_box").on('click', function() {
	$('.Online_win').show()
})
