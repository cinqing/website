<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="" />
<meta name="keywords" content=""/>
<title>在线订购_美百颜官网</title>
<link rel="stylesheet" type="text/css" href="dist/css/css.css">
<link rel="stylesheet" href="css/aui.css">
<link rel="stylesheet" type="text/css" href="dist/css/style.css">
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<script src="dist/js/zepto.min.js"></script>
<script src="dist/js/main.js"></script>
<script src="dist/js/tool.js"></script>
<script src="dist/js/swipe.js"></script>
</head>
<body>
<!--header-->
<div class="main">

   
<?php
include_once("top.php");
?>
   

 
 <ul class="bread"><li><a href="index.php">首页</a></li><li><a href="dinggou.php">在线订购</a></li></ul>
<div class="art">
  <div class="adv"><img src="dist/images/adv.jpg"></div>
  <div class="con">
			<script src="js/referer.js" type="text/javascript"></script>
						<iframe width="100%"  frameborder="0" id="orderform" src="ordernew.php#cart" scrolling="no" onload="this.height=400"></iframe>

    </div>


</div>

    <script>
	var cart_display = "none";

	
	function reinitIframe(){
var iframe = document.getElementById("orderform");
try{
var bHeight = iframe.contentWindow.document.body.scrollHeight;
var dHeight = iframe.contentWindow.document.documentElement.scrollHeight;
var height = Math.max(bHeight, dHeight);
iframe.height = height;
//console.log(height);
}catch (ex){}
}
window.setInterval("reinitIframe()", 1000);

	</script>
	
  
   
   
  
   
   
   
<div class="fx_main">
<div class="fx_vm">
<div class="fenxiang bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1505366263498">
               
					<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                    <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                    <a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
                    <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                </div>
<span class="fx_close">取消</span>
</div>
</div>

   
<?php
include_once("foot.php");
?>


  
 


         <script src="js/api.js"></script>
		 <script src="js/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js" ></script>
	<script type="text/javascript" src="js/jquery.cookie.js"></script>
<script type="text/javascript" src="js/aui-dialog.js"></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js"></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<!-- <script>(function() {var _53code = document.createElement("script");_53code.src = "https://tb.53kf.com/code/code/10159345/6";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>	 --></body>
</html>