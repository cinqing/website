
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>cart购物车</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<title>购物车—vense美百颜,重塑自然之美_美百颜官方网站</title>
<meta name="Keywords" content="美百颜,美百颜效果怎么样,美百颜官方网站,美百颜多少一套,美百颜官网,美百颜价钱,美百颜怎么样" />
<meta name="Description" content="美百颜以创新科技重组古老配方，塑造国际潮流的东方护肤美学，采用针对性护理方式应对不同年龄阶段肌肤问题，美百颜专业护肤老师为每一位肌肤问题用户提供完美的解决方案，塑造自然美肤。" />

<!-- Bootstrap -->
<link href="../vense/css/bootstrap.min.css"  rel="stylesheet">
<link href="../vense/css/vense.css"  rel="stylesheet">
<link href="../vense/cssnew/vense.css"  rel="stylesheet">
<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
<link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<script src="dist/js/zepto.min.js" ></script>
<script src="dist/js/main.js" ></script>


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="../cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js" tppabs="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="../cdn.bootcss.com/respond.js/1.4.2/respond.min.js" tppabs="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
     <script src="../vense/js/html5shiv.min.js" ></script>
     <script src="../vense/js/respond.min.js" ></script>
	<script type="text/javascript" src="js/jquery.min.js" ></script>
	<script type="text/javascript" src="../vense/js/jquery.cookie.js" ></script>
	<script type="text/javascript" src="../vense/js/cart.php" ></script>
	<script  type="text/javascript">window._pt_lt  =  new  Date().getTime();</script>

	 <script src="js/api.js" ></script>
    <script type="text/javascript" src="js/aui-tab.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js"></script>
</head>
<body>




<style type="text/css">
.jscenter{ max-width:100%; margin:0 auto; background:#f5f5f5}
.jslist{ font-size:12px;}
.jstitle{ background:#fff; border-bottom:1px #e0e0e0 solid; height:70px;}
.jslistc{border-bottom:1px #e0e0e0 solid; height:110px; background:#fff; font-size:15px}

.jspd20{ padding-top:20px; line-height:18px;}
.jsend{background:#f3f3f3; height:40px; line-height:40px;}
.jsbtn{ display:block; height:50px; line-height:50px; font-size:18px; width:204px; text-align:center; color:#FFF; background:#010e80; margin-left:50px}
.jsbtn:hover{ color:#fff}
.jscount{ font-size:30px; color:#010e80; }
.jstxt{ width:48px; height:25px; border:0; text-align:center; margin:0 15px; }


<!---购物车位空->

</style>
<div class="main">
<?php
include_once("top.php");
?>
<div class="jscenter">
	<div class="jslist">
		<div id="cartlist" style="width:100%;max-width: 640px;width: 100%; margin:0 auto;">
			
		</div>
		<style type="text/css">
			.dscenter{ margin-top:60px; padding-bottom:130px}
			.dstitle{ width:100%; height:73px; border-bottom:0; color:#757575; font-size:30px; text-align:center; line-height:40px;}
			.dstitle hr{ width:100%; border:1px solid #e0e0e0}
			.dstitle span{ display:block;  width:100%;}
			.dslist{ position:relative; padding:10px 0; width:100%; margin:0 auto}
			.dsdiv{ padding:0;}
			.dsdiv ul{ list-style:none; margin:0; padding:0;}
			.dsdiv ul li{ float:left; margin:0; margin-right:10px; text-align:center; width:235px; background:#fff; height:302px; margin-top:10px; padding-top:30px;    transition: all .2s linear;}
			.dsdiv ul li:hover{z-index:2; box-shadow:0 15px 30px rgba(0,0,0,0.1); transform:translate3d(0,-2px,0)}
		</style>
		<div class="dscenter">
			<div class="dslist">
				<div class="dstitle"><hr><span>为您推荐</span><hr></div>
				<div class="dsdiv" id="dsdiv">
				</div>
				<div style="height:0; clear:both;"></div>
				<!--<div style="text-align:right; padding-right:10px;"><a href="javascript:dscart()">换一批&gt;&gt;</a></div>-->
			</div>
		</div>
	</div>
</div>

<?php
include_once("footer.php");
?>


</div>



<script type="text/javascript">
	var cart_display = "none";
	var pro_array = Array();
	function opcart(){
			pro_array = Array();
			var cart = $.cookie("cart");
			var trs = "";
			var count = 0;
			if(cart!=null){
				var obj =  eval("(" + cart + ")");
				var pid,pnum,pprice,purl,pname,prl,pintro;
				trs +='<table border="0" cellpadding="0" cellspacing="0" width="100%"><p style="height:40px; line-height:40px">我的购物车</p><tr class="jstitle"><td width="138"></td><td width="450">商品名称</td><td width="135">单价（元）</td><td width="147" align="center">数量</td><td width="185" align="center">小计（元）</td><td style="padding-left:20px;">操作</td></tr>';
				for(var i = 0;i < obj.length;i++){
					pid = obj[i]["proX"];
					pnum = parseInt(obj[i]["proS"]);
					pname = product_array[""+pid][1];
					pprice = parseInt(product_array[""+pid][2]);
					purl = product_array[""+pid][5];
					prl = product_array[""+pid][3];
					pintro = product_array[""+pid][7];
					count += (pnum*pprice);
					pro_array.push(""+pid);

					
					

					trs += '<tr class="jslistc"><td align="center"><a href="product.php-pid='+pid+'.htm" target="_blank"><img src="'+purl+'" height="90"></a></td><td style="font-size:18px; color:#000" id="panme">'+pname+' '+prl+'</td><td>'+pprice+'.00</td><td align="center"><div  style="border:1px solid #e0e0e0; height:38px; line-height:38px"><a href="#" name="jssubt" pro="proname_'+pid+'" pid="'+pid+'">-</a><input type="text" value="'+pnum+'" name="proname_'+pid+'" id="proname_'+pid+'" class="jstxt" /><a href="#" name="jsplus" pro="proname_'+pid+'" pid="'+pid+'">+</a></div></td><td align="center">'+(pnum*pprice)+'.00</td><td style="padding-left:20px;"><a href="#" name="jsdel" pid="'+pid+'"><i class="iconfont">&#xe617;</i></a></td></tr>';
				}
				trs +='<tr ><td colspan="6" class="jsend"><table border="0" cellpadding="0" cellspacing="0" width="100%"  style="background:#fff; margin-top:20px; height:50px"><tr><td><a href="index.php"  style="margin-left:30px; color:#757575">继续购物</a></td><td align="right" style="color:#010e80">总价（不含运费）：<span class="jscount">'+count+'.00</span> 元</td><td width="116" align="right"><a href="order.php" class="jsbtn">去结算</a></td></tr></table></td></tr></table>';
			}
			if(trs==""){
				$("#cartlist").html('<div style="height:400px; color:#b0b0b0; font-size:36px; text-align:center;; padding-top:150px">			您的购物车还是空的！去看看吧~ <br><br><a href="index.php" style="display:block; width:175px; height:51px; line-height:51px; color:#fff; background:#010e80; font-size:14px; text-align:center; margin:0 auto">马上去逛逛</a></div>');
			}else{
				$("#cartlist").html(trs);
			}
			$("a[name='jsplus']").click(function(){
				var ppid = $(this).attr("pid");
				var obj = "#"+$(this).attr("pro");					  
				$(obj).val(parseInt($(obj).val())+1);
				ckItem(ppid,1,"+");
				opcart();
				return false
			});
			$("a[name='jssubt']").click(function(){
				var ppid = $(this).attr("pid");
				var obj = "#"+$(this).attr("pro");
				if(parseInt($(obj).val())>1){
					$(obj).val(parseInt($(obj).val())-1);
					ckItem(ppid,1,"-");
					opcart();
				}
				return false;
			});
			$("a[name='jsdel']").click(function(){
				var ppid = $(this).attr("pid");
				ckItem(ppid,0,"c");	
				opcart();
				return false;
			});
			/*$("#price").html(count+".00");
			$("#cart_num").html(cartn);
			$("a[name='r_p']").click(function(){
				ckItem($(this).attr("pro"),0,"c");
				if($.cookie("cart")!=null){
					$("div[plist='"+$(this).attr("pid")+"']").remove();
				}else{
					c_cart();
					c_s_list();	
				}
				return false;
			})*/
		
	}
	function random(min,max){
		return Math.floor(min+Math.random()*(max-min));
	}
	function dscart(){
		var ds_array = Array();
		var show_array = Array();
		for(var i in product_array){
			var proin = $.inArray(product_array[i][0], pro_array)
			if(proin<0){
				ds_array.push(product_array[i][0]);
			}
		}
		var ds_len = ds_array.length;
		var z=0;
		for(var j=0;j<10;j++){
			z = 0;
			while(z==0){
				var pro_id = ds_array[random(0,ds_len)];
				if($.inArray(pro_id,show_array)<0){
					show_array.push(pro_id);
					z = 1;
				}
			}
		}
		var dsdiv_str = "<ul>";
						
		for(var i=0;i<show_array.length;i++){
			dsdiv_str += '<li><a href="product.php-pid='+product_array[show_array[i]][0]+'.php" target="_blank"><img src="'+product_array[show_array[i]][5]+'" height="160"></a><br><div style=" line-height:30px;word-wrap:break-word; word-break:break-all; font-size:14px; text-align:center; width:235px;">								'+product_array[show_array[i]][1]+'<br>								￥'+product_array[show_array[i]][2]+'.00<br>								<a href="#" name="dstocart" pid="'+product_array[show_array[i]][0]+'"><img src="image/jiaru.jpg" width="122" height="30"></a>							</div>						</li>'; 
		}
		dsdiv_str += "</ul>";
		$("#dsdiv").html(dsdiv_str);
		$("a[name='dstocart']").click(function(){
			var ppid = $(this).attr("pid");
			ckItem(ppid,1,"+");
			opcart();
			return false;
		});
	}
	$(function(){
		opcart();
		dscart();
	});
	//var cartn_display = "none";//购物车显示购物车数量
</script>




<script>
	
	
	
	
$('.scroll-top').hide();
	$(window).scroll(function(){
		var windowHeight = $(this).height();
		var scrollTop = $(window).scrollTop();
		if(scrollTop > windowHeight / 2){
			$('.scroll-top').show();
		}else{
			$('.scroll-top').hide();
		}
	});
$(function(){
$('.scroll-top').hover(function(){
	$(this).addClass('scroll-hover');
},function(){
	$(this).removeClass('scroll-hover');
});
})

</script>


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-88166597-1', 'auto');
  ga('send', 'pageview');

</script>



</body>
</html>
