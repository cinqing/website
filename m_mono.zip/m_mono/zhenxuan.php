<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>zhenxuan全球甄选</title>
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>全球甄选</title>
        <link rel="stylesheet" type="text/css" href="dist/css/css.css-v=2.css" >
		 <link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
		<script src="dist/js/zepto.min.js" ></script>
<script src="dist/js/main.js" ></script>
</head>
<body>
    <!--header-->
<div class="main">

   
<?php
include_once("top.php");
?>

    
 
	<div class="main">
			<div class="gs-youknow">	
				<!--<div class="gs-bgimg">
					<img src="zhuanti/zhenxuan/images/img_07.jpg" alt="" />
				</div>-->
				<div class="gs-youknow gs-youknowd">
					<!--<div class="gs-youknow-txt">
						<div class="gs-youknow-txt-title">
							<h1>你知道吗?</h1>
							<h2>美百颜的卓效奥秘，在于配方</h2>
							<p>第一份产品的配方，源于诺贝尔奖早就盖过章的护肤成分——EGF(表皮生长因子)</p>
						</div>
						
						<ul class="gs-EGF-con">
							<li>
								<img src="zhuanti/zhenxuan/images/img_08.jpg" alt="" />
							</li>
							<li>
								<p>环境的污染、紫外线的伤害等外部环境因素使人们的肌肤变得更加脆弱，美百颜的创始团队深研护肤品行业多年，深谙现代人们的肌肤渴求，以多元化护肤理念，突破概念护肤的方式开始了对脆弱肌肤所适用的产品成分和配方知识进行钻研。</p>
							</li>
							<div class="clearfix"></div>
						</ul>
					</div>-->
					<div class="gs-youknow-txt">
						<!--<div class="gs-youknow-txt-title">
							<p>经过一线资料的多次查阅和反复的科研试验，我们选定了这种成分</p>
						</div>-->
						
						<!--<ul class="gs-EGF-con gs-EGF-cont">
							<li>
								<img src="zhuanti/zhenxuan/images/img_09.jpg" alt="" />
							</li>
							<li>
								<p>EGF（即表皮生长因子，寡肽）由Dr. Stanley Cohen于1962年发现，1986年获得诺贝尔生理学及医学奖。美百颜以“科研力·鲜活肌”为诉求，研发了明星产品聚能修护精华液，产品中加入了EGF能减轻肌肤红肿痛痒绷的症状，可以提高肌肤的防护力，收到赞誉无数！</p>
							</li>
							<div class="clearfix"></div>
						</ul>-->
					</div>
				</div>
				<div class="gs-youknow gs-youknowx">
					<div class="gs-youknow-txt">
						<div class="gs-youknow-txt-title">
							<h1>你知道吗?</h1>
							<h2>美百颜的卓效奥秘，在于配方</h2>
							<p>第一份产品的配方，源于诺贝尔奖早就盖过章的护肤成分——EGF(表皮生长因子)</p>
						</div>
						
						<div class="gs-EGF-con">
							<p class="gs-EGF-con-txt">
								<img src="zhuanti/zhenxuan/images/img_08.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_08.jpg" alt="" />
								环境的污染、紫外线的辐射等外部环境因素使人们的肌肤变得更加敏感脆弱，美百颜的创始团队深研护肤品行业多年，深谙现代人们的肌肤渴求，以多元化护肤理念，突破概念护肤的方式开始了对红血丝肌肤产品成分和配方知识的钻研。
								<div class="clearfix"></div>
							</p>
						</div>
					</div>
					<div class="gs-youknow-txt">
						<div class="gs-youknow-txt-title">
							<p>经过一线资料的多次查阅和反复的科研试验，我们选定了这种成分</p>
						</div>
						
						<div class="gs-EGF-con gs-EGF-cont">
							<p class="gs-EGF-con-txt gs-EGF-con-txtr">
								<img src="zhuanti/zhenxuan/images/img_09.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_09.jpg" alt="" />
								EGF（即表皮生长因子，寡肽）由Dr. Stanley Cohen于1962年发现，1986年获得诺贝尔生理学及医学奖。美百颜以“科研力·鲜活肌”为诉求，研发了红色密码柔皙舒缓系列，产品中加入了EGF能减轻肌肤红肿痛痒绷的症状，可以提高肌肤的防护力，收到赞誉无数!
								<div class="clearfix"></div>
							</p>
						</div>
					</div>	
				</div>
				<div class="gs-youknow">
					<div class="gs-natural-science-title">
						<h1>全球合作企业</h1>
						<h4>|&nbsp;&nbsp;美肤之旅无国界</h4>
						<div class="clearfix"></div>
					</div>
					<div class="gs-national-boundaries-bgimg">
						<img src="zhuanti/zhenxuan/images/img_16.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_16.jpg" alt="" />
					</div>
					<ul>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_17.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_17.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>科丝美诗（韩国）</h4>
								<div class="gs-nationalflag"></div>
								<div class="clearfix"></div>
							</div>
							<p>21项国际研发专利；1266项功效型化妆品许可23年生产研发经验；4大生产基地辐射亚洲。</p>
						</li>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_18.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_18.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>苏州科玛（日本）</h4>
								<div class="gs-nationalflag" style="background-position:-50px"></div>
								<div class="clearfix"></div>
							</div>
							<p>强大的研发和生产技术体系日本3个综合性研发机构；100名研发工程师；严格按照日本生产标准。</p>
						</li>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_19.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_19.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>新田明胶（日本）</h4>
								<div class="gs-nationalflag" style="background-position:-50px"></div>
								<div class="clearfix"></div>
							</div>
							<p>百年明胶生产研发经验；胶原蛋白领域龙头企业；拥有整套权威临床数据库。</p>
						</li>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_20.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_20.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>澳思美（澳洲）</h4>
								<div class="gs-nationalflag" style="background-position:-100px"></div>
								<div class="clearfix"></div>
							</div>
							<p>澳、亚洲两大生产基地；一万级标准生产车间；通过美国/欧洲/东盟GMPC认证及ISO22716生产规范认证。</p>
						</li>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_21.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_21.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>露丝贝儿（中国）</h4>
								<div class="gs-nationalflag" style="background-position:-150px"></div>
								<div class="clearfix"></div>
							</div>
							<p>国内知名的化妆品研发制造企业，24年生产研发经验；拥有马来西亚、新加坡、台湾、杭州等多个生产基地。</p>
						</li>
						<li class="gs-countryimg">
							<img src="zhuanti/zhenxuan/images/img_22.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_22.jpg" alt="" />
							<div class="gs-countryimg-title">
								<h4>苏州安特（美国）</h4>
								<div class="gs-nationalflag" style="background-position:-200px"></div>
								<div class="clearfix"></div>
							</div>
							<p>专注白领女性的时尚化妆技术的研究，隶属美国安特国际集团，美洲、欧洲和亚洲均有生产基地。</p>
						</li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="gs-youknow">
					<div class="gs-natural-science-title">
						<h1>从配方到专属肌肤护理</h1>
						<h4>|&nbsp;&nbsp;5大系列针对性解决</h4>
						<div class="clearfix"></div>
					</div>
					<div class="gs-bgimg">
					<img src="zhuanti/zhenxuan/images/img_24.jpg" tppabs="http://m.vense.cn/zhuanti/zhenxuan/images/img_24.jpg" alt="" />
				</div>
				</div>
			</div>
		</div>
        
             	
   
   
 
<!--tanchu-->
   
<?php
include_once("foot.php");
?>

  
 


         <script src="js/api.js"></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js"  ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" ></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6"/*tpa=https://tb.53kf.com/code/code/10159345/6*/;var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>				<script>
				 $(document).ready(function(){
					$(".kb-nav>li").click( function(){
					var index=$(this).index();
					$(this).addClass("kb-navon").siblings().removeClass("kb-navon");
					$(".kb-con-product").eq(index).addClass('kb-con-product-on').siblings().removeClass('kb-con-product-on');
				});
				})
			</script>
	</body>
</html>