<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>order</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<title>在线填写订单</title>
<script type="text/javascript" src="js/jquery2.1.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script>
<script type="text/javascript" src="js/aui-dialog.js"></script>
<link href="./css/aui.css" type="text/css" rel="stylesheet">
<link href="./css/cart.css" type="text/css" rel="stylesheet">
<link href="./css/style.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="empty_cart" id="empty_cart" style="display:none;">
	<div>购物车还是空的<a href="index.php" target="__self">去看看</a></div>
</div>

	<div class="cart" id="cart_mark" style="">
		<div class="cart_head">
			<ul>
				<li class="w33"><label><input class="selectall_y" type="checkbox" checked=""><i class="aui-iconfont aui-icon-correct"></i>全选</label></li>
				<li class="w57">单价/数量</li>
				<li class="w10">操作</li>
			</ul>
		</div>
		<div class="cart_cont" id="cartprolist"><!-- <ul><li class="w33 left"><label><input type="checkbox" name="prolist[]" value="94" checked=""><i class="aui-iconfont aui-icon-correct"></i></label><a href="http://m.vense.cn/product.php?id=94"><img src="./pinpai/vense/images/201906281827576188.png"></a></li>
			<li class="w57"><h6>植物源性花青素固体饮料</h6><p>单价：580元</p><div class="num_select" pid="94" data-num="1"><span class="reduce left">-</span> <span class="num left"><input type="text" value="1"></span> <span class="add left">+</span><div class="clear"></div></div></li><li class="w10"><div class="del" data-id="94"><i class="aui-iconfont aui-icon-close"></i></div></li></ul> --></div>
		<div class="count_price">
			<ul>
				<li>总价<span>(不包含运费)</span>:</li>
				<li><span id="count">580</span>元</li>
			</ul>
		</div>
		<div class="go_shopping">
			<a href="index.php" target="__self">继续购物&gt;&gt;</a>
		</div>
		<div style="height: 2.5em;margin-bottom: 0.75em">
    </div>
    <footer class="aui-bar aui-bar-tab" id="footer">
    <div class="aui-bar-tab-item" tapmode="">
        <div class="aui-bar-tab-label" id="goacount">去结算</div>
    </div>
</footer>
	</div>
	
<!--<div  class="commend">
	<dt>为您推荐</dt>
	<dl>
		<dd>
			<a href="#" title="安护倍润鲜肌肤水"><img src="./img/a.png"></a>
			<div>
				<h4>安护倍润鲜肌肤水</h4>
				<p class="color-011afb">￥138</p>
			</div>
		</dd>
	</dl>
</div> -->

	<!--<div id="order" class="o">
		<div class="oc">
		<a name="cart"></a>			
		<div class="o-c-list" id="o_c_list">
				<div class="op" id="plist">
					<div class="opl">
						<ul ids="prolist">
							<li></li>
						</ul>
						<div class="empty_cart" id="empty_cart">当前购物车是空的，请点击上方快速添加单品按钮可添加产品到购物车</div>
						<div class="clear"></div>
					</div>
					<div class="clear"></div>
				</div>
		</div>
		<!--<div class="dgprice"></div>
		<div class="form">
			<div class="o-l">
					<div class="oct oct_bg">
						<h3>填写订单</h3>
						<div class="clear"></div>
					</div>
			</div>
			<div class="o-r">
				<form action="http://order.vense.cn/index.php?action=savecontent&ph=2" enctype="multipart/form-data" id="myform" method="post" name="myform" onsubmit="return checkForm();">
				<input type="hidden" value="69" name="fid">
				<input type="hidden" name="content[0]" id="proselect" value="" />
                <input type="hidden" name="content[2]" value="女"〉/>
				<ul>
					<li><span class="tit">姓名：</span><span class="red">*</span><br><input class="form-control" name="content[1]" value="" type="text">  </li>
					<li><span class="tit">联系电话：</span><span class="red">*</span><input class="form-control" name="content[3]" value="" type="text"> </li>
				
					<li><span class="tit">详细地址：</span><span class="red">*</span><br>
					<input class="form-control" name="content[5]" value="" type="text"></li>
					<li><span class="tit txt">备注说明：</span><br><textarea name="content[6]" class="form-control" style="height:60px;"></textarea></li>
						<li><span class="tit red">支付方式</span>
						<div class="zft">
						<span>
							<a class="active" rote="货到付款(安心有保障)"><img src="dist/images/hd.jpg"></a>
						</span>
						<span>
							<a rote="支付宝"><img src="dist/images/zf.jpg"></a>
						</span>
						<input type="hidden" id="zifufs" name="content[4]" value="货到付款(安心有保障)">
						</li>
				</ul>
				<div class="subbtn">
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td width="40%"></td>
							<td width="120" align="left"><input type="submit" name="sub" class="subtj" id="sub" value="提交订单" /></td>
							<td></td>
						</tr>
					</table>
				</div>
				<input type="hidden" name="extend_referer" id="extend_referer" value="" />
                <input type="hidden" name="site_referer" id="site_referer" value="" />
				</form>
			</div>	
		</div>
	</div>	-->
	<script type="text/javascript">
	$(function(){
			var parr = Array();

			parr["8"] = Array("8",
				"美百颜焕肌精华液",
				  "../mono/mono/images/2017091816514310395.png",
				  "590",
				  "4ml",
				  "quzhou1.php?id=8",
				  "../mono/mono/images/2017091816514310395.png",
				  "8"
				  );

			parr["12"] = Array("12",
				"美百颜玛瑞安美白祛斑霜",
				  "../mono/mono/images/201801231551266532.png",
				  "920",
				  "20g",
				  "quban.php?id=12",
				  "../mono/mono/images/201801231551266532.png",
				  "12"
				  );

			parr["13"] = Array("13",
				"美百颜燕窝胶原蛋白肽果饮",
				  "../mono/mono/images/2018071313360210203.png",
				  "398",
				  "500ml",
				  "jiaoyuandanbai.php?id=13",
				  "../mono/mono/images/2018071313360210203.png",
				  "13"
				  );

			parr["14"] = Array("14",
				"美百颜弹润紧致修护霜",
				  "../mono/mono/images/201709181650336813.png",
				  "920",
				  "25g",
				  "quzhou.php?id=8",
				  "../mono/mono/images/201709181650336813.png",
				  "8"
				  );

			parr["21"] = Array("21",
				"美百颜莹润紧致多肽面膜",
				  "../mono/mono/images/2019112815352619149.png",
				  "135",
				  "25gX5片",
				  "bushuimask.php?id=21",
				  "../mono/mono/images/2019112815352619149.png",
				  "21"
				  );

			parr["22"] = Array("22",
				"氨基酸温和洁面乳",
				  "../mono/mono/images/201911151139436401.png",
				  "138",
				  "80g",
				  "jiemian.php?id=22",
				  "../mono/mono/images/201911151139436401.png",
				  "22"
				  );

			parr["23"] = Array("23",
				"人参护肤甘油",
				  "../mono/mono/images/201801231552237628.png",
				  "99",
				  "120ml",
				  "ganyou.php?id=23",
				  "../mono/mono/images/201801231552237628.png",
				  "23"
				  );

			parr["24"] = Array("24",
				"美百颜玻尿酸水润护肤套盒",
				  "../mono/mono/images/2019062818275717146.png",
				  "404",
				  "100ml+50ml",
				  "roufushui.php?id=24",
				  "../mono/mono/images/2019062818275717146.png",
				  "24"
				  );

			parr["26"] = Array("26",
				"舒润柔肤水（大）",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "238",
				  "300ml",
				  "product.php?id=26",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "26"
				  );

			parr["27"] = Array("27",
				"毛孔细致精华液",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "108",
				  "50ml",
				  "product.php?id=27",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "27"
				  );

			parr["28"] = Array("28",
				"美百颜黑头导出液",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "108",
				  "50ml",
				  "product.php?id=28",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "28"
				  );

			parr["29"] = Array("29",
				"美百颜黑头吸附面膜",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "80",
				  "50g",
				  "product.php?id=29",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "29"
				  );

			parr["32"] = Array("32",
				"复合益生菌固体饮料",
				  "pinpai/vense/images/20160827160102.gif",
				  "560",
				  "90g",
				  "product.php?id=32",
				  "pinpai/vense/images/20160827160102.gif",
				  "32"
				  );

			parr["35"] = Array("35",
				"美百颜舒润系列",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "510",
				  "150g+300ml+100ml+25ml*5",
				  "product.php?id=35",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "35"
				  );

			parr["39"] = Array("39",
				"智研光肌系列",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "864",
				  "30ml+30g+30ml+ 50g",
				  "product.php?id=39",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "39"
				  );

			parr["44"] = Array("44",
				"卓研晶透祛斑精华液",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "330",
				  "30ml",
				  "product.php?id=44",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "44"
				  );

			parr["45"] = Array("45",
				"肌源净澈赋活霜",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "360",
				  "50g",
				  "product.php?id=45",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "45"
				  );

			parr["46"] = Array("46",
				"美百颜肌源净澈系列",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "690",
				  "30ml+50g",
				  "product.php?id=46",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "46"
				  );

			parr["47"] = Array("47",
				"活氧冰肌水冻膜",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "178",
				  "100g",
				  "product.php?id=47",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "47"
				  );

			parr["49"] = Array("49",
				"安护鲜肌水养面膜",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=49",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "49"
				  );

			parr["50"] = Array("50",
				"安护氨基酸植萃洁面乳",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "86",
				  "80g",
				  "product.php?id=50",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "50"
				  );

			parr["51"] = Array("51",
				"安护倍润鲜肌水",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "138",
				  "100ml",
				  "product.php?id=51",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "51"
				  );

			parr["52"] = Array("52",
				"美百颜安护植润滋养霜",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "260",
				  "30g",
				  "product.php?id=52",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "52"
				  );

			parr["53"] = Array("53",
				"安护倍润修护乳",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "198",
				  "45g",
				  "product.php?id=53",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "53"
				  );

			parr["54"] = Array("54",
				"美百颜安护植润系列",
				  "pinpai/vense/images/202003230943113170.png",
				  "810",
				  "5件套",
				  "product.php?id=54",
				  "pinpai/vense/images/202003230943113170.png",
				  "54"
				  );

			parr["56"] = Array("56",
				"肌妍新生美眼霜",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "280",
				  "15g",
				  "product.php?id=56",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "56"
				  );

			parr["57"] = Array("57",
				"肌妍新生滋养霜",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "360",
				  "50g",
				  "product.php?id=57",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "57"
				  );

			parr["58"] = Array("58",
				"肌妍新生系列",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "960",
				  "精华液30ml+滋养霜50g+眼霜15g",
				  "product.php?id=58",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "58"
				  );

			parr["59"] = Array("59",
				"肌妍新生精华液",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "320",
				  "30ml",
				  "product.php?id=59",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "59"
				  );

			parr["60"] = Array("60",
				"琉晶莹彩唇膏",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "189",
				  "3.8g",
				  "product.php?id=60",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "60"
				  );

			parr["61"] = Array("61",
				"炫黑纤长修护睫毛膏",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "126",
				  "7ml",
				  "product.php?id=61",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "61"
				  );

			parr["62"] = Array("62",
				"精致塑形眉彩笔",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "98",
				  "0.24g",
				  "product.php?id=62",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "62"
				  );

			parr["63"] = Array("63",
				"炫黑速干眼线液笔",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "108",
				  "0.5ml",
				  "product.php?id=63",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "63"
				  );

			parr["64"] = Array("64",
				"智研光肌精华液",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "218",
				  "30ml",
				  "product.php?id=64",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "64"
				  );

			parr["65"] = Array("65",
				"智研光肌霜",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "260",
				  "50g",
				  "product.php?id=65",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "65"
				  );

			parr["66"] = Array("66",
				"美百颜彩妆系列",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "521",
				  "唇膏3.8g 睫毛膏7ml 眼线液笔0.5ml 眉彩笔0.2",
				  "product.php?id=66",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "66"
				  );

			parr["68"] = Array("68",
				"炫黑浓翘修护睫毛膏",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "126",
				  "7ml",
				  "product.php?id=68",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "68"
				  );

			parr["69"] = Array("69",
				"凝光沁亮肌活霜",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "360",
				  "50g",
				  "product.php?id=69",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "69"
				  );

			parr["70"] = Array("70",
				"凝光沁亮肌活精华液",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "330",
				  "50ml",
				  "product.php?id=70",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "70"
				  );

			parr["71"] = Array("71",
				"凝光沁亮系列",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "690",
				  "50ml、50g",
				  "product.php?id=71",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "71"
				  );

			parr["72"] = Array("72",
				"智研光肌祛痘膏",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "168",
				  "30g",
				  "product.php?id=72",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "72"
				  );

			parr["73"] = Array("73",
				"智研光肌祛痘精华液",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "218",
				  "30ml",
				  "product.php?id=73",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "73"
				  );

			parr["74"] = Array("74",
				"聚能修护精华液",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "420",
				  "0.35ml*15粒",
				  "product.php?id=74",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "74"
				  );

			parr["75"] = Array("75",
				"梦幻柔光气垫BB霜送替换装",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "188",
				  "13g*2",
				  "product.php?id=75",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "75"
				  );

			parr["76"] = Array("76",
				"净润舒缓卸妆液",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "168",
				  "200ml",
				  "product.php?id=76",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "76"
				  );

			parr["77"] = Array("77",
				"凝光沁亮修颜霜",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "168",
				  "37ml",
				  "product.php?id=77",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "77"
				  );

			parr["84"] = Array("84",
				"户外隔离防护霜",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "128",
				  "50g",
				  "product.php?id=84",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "84"
				  );

			parr["88"] = Array("88",
				"臻妍纯皙-焕能活颜面膜",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "288",
				  "25ml/片*5",
				  "product.php?id=88",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "88"
				  );

			parr["89"] = Array("89",
				"臻妍纯皙-密活亮采面膜",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=89",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "89"
				  );

			parr["90"] = Array("90",
				"臻妍纯皙-冰肌盈耀面膜",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=90",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "90"
				  );

			parr["92"] = Array("92",
				"鱼胶原蛋白肽粉30支装",
				  "pinpai/vense/images/2017102412232311313.png",
				  "1680",
				  "150克（5克X 30瓶）",
				  "product.php?id=92",
				  "pinpai/vense/images/2017102412232311313.png",
				  "92"
				  );

			parr["93"] = Array("93",
				"鱼胶原蛋白肽粉10支装",
				  "pinpai/vense/images/201711061800143549.png",
				  "580",
				  "50克（5克X 10瓶）",
				  "product.php?id=93",
				  "pinpai/vense/images/201711061800143549.png",
				  "93"
				  );

			parr["94"] = Array("94",
				"植物源性花青素固体饮料",
				  "pinpai/vense/images/201906281827576188.png",
				  "580",
				  "2克*20袋",
				  "product.php?id=94",
				  "pinpai/vense/images/201906281827576188.png",
				  "94"
				  );

			parr["95"] = Array("95",
				"蔓越莓维生素C固体饮料",
				  "pinpai/vense/images/2017112709114214835.png",
				  "298",
				  "3g*30袋/盒",
				  "product.php?id=95",
				  "pinpai/vense/images/2017112709114214835.png",
				  "95"
				  );

			parr["96"] = Array("96",
				"青果肌滢润洁面乳",
				  "pinpai/vense/images/2017113018050315284.png",
				  "79",
				  "120g",
				  "product.php?id=96",
				  "pinpai/vense/images/2017113018050315284.png",
				  "96"
				  );

			parr["97"] = Array("97",
				"青果肌滢润精粹水",
				  "pinpai/vense/images/2017113017551118264.png",
				  "109",
				  "150ml",
				  "product.php?id=97",
				  "pinpai/vense/images/2017113017551118264.png",
				  "97"
				  );

			parr["98"] = Array("98",
				"青果肌滢润保湿乳",
				  "pinpai/vense/images/201711301817469051.png",
				  "119",
				  "100ml",
				  "product.php?id=98",
				  "pinpai/vense/images/201711301817469051.png",
				  "98"
				  );

			parr["99"] = Array("99",
				"青果肌滢润补水面膜",
				  "pinpai/vense/images/201711301833591400.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=99",
				  "pinpai/vense/images/201711301833591400.png",
				  "99"
				  );

			parr["100"] = Array("100",
				"青果肌净爽控油面膜",
				  "pinpai/vense/images/2017113018393711530.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=100",
				  "pinpai/vense/images/2017113018393711530.png",
				  "100"
				  );

			parr["102"] = Array("102",
				"鲜肌酵母精华水",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "218",
				  "120ml",
				  "product.php?id=102",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "102"
				  );

			parr["103"] = Array("103",
				"美百颜净润卸妆乳",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "168",
				  "120g",
				  "product.php?id=103",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "103"
				  );

			parr["105"] = Array("105",
				"晶彩胶原寡肽眼膜",
				  "pinpai/vense/images/201905071131456858.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=105",
				  "pinpai/vense/images/201905071131456858.png",
				  "105"
				  );

			parr["106"] = Array("106",
				"美百颜角鲨烷舒缓鲜肌喷雾",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "128",
				  "150ml",
				  "product.php?id=106",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "106"
				  );

			parr["108"] = Array("108",
				"晶彩松露胜肽眼膜",
				  "pinpai/vense/images/2019092917513914239.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=108",
				  "pinpai/vense/images/2019092917513914239.png",
				  "108"
				  );

			parr["109"] = Array("109",
				"VENSE美百颜 美百颜卓研晶透系列",
				  "pinpai/vense/images/201909301115234803.png",
				  "690",
				  "30ml+50g",
				  "product.php?id=109",
				  "pinpai/vense/images/201909301115234803.png",
				  "109"
				  );

			parr["110"] = Array("110",
				"保加利亚玫瑰花水面膜",
				  "pinpai/vense/images/201910291820001217.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=110",
				  "pinpai/vense/images/201910291820001217.png",
				  "110"
				  );

			parr["111"] = Array("111",
				"四重玻尿酸水库面膜",
				  "pinpai/vense/images/2019102918243214736.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=111",
				  "pinpai/vense/images/2019102918243214736.png",
				  "111"
				  );

			parr["112"] = Array("112",
				"城市霓虹丝悦唇膏口红",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "99",
				  "3.4g",
				  "product.php?id=112",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "112"
				  );

			parr["113"] = Array("113",
				"卓研晶透祛斑滋养霜",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "360",
				  "50g",
				  "product.php?id=113",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "113"
				  );

			parr["114"] = Array("114",
				"美百颜安护植润鲜肌水",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "138",
				  "100ml",
				  "product.php?id=114",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "114"
				  );

			parr["115"] = Array("115",
				"美百颜安护植润修护乳",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "198",
				  "45g",
				  "product.php?id=115",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "115"
				  );

			parr["116"] = Array("116",
				"美百颜安护鲜肌水养植萃面膜",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=116",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "116"
				  );

			parr["117"] = Array("117",
				"美百颜清透亮采防晒霜",
				  "pinpai/vense/images/202003271311538925.png",
				  "128",
				  "50g",
				  "product.php?id=117",
				  "pinpai/vense/images/202003271311538925.png",
				  "117"
				  );

			parr["118"] = Array("118",
				"美百颜净润舒缓卸妆液 养肤级卸妆",
				  "pinpai/vense/images/202003301121288441.png",
				  "168",
				  "200ml",
				  "product.php?id=118",
				  "pinpai/vense/images/202003301121288441.png",
				  "118"
				  );

		var cur_cart = JSON.parse($.cookie("cart"));
		var dialog = new auiDialog();
		show_cart(cur_cart);
		function show_cart(obj){
			if(obj){
				$("#empty_cart").hide();
				$("#cart_mark").show();
				$("#cartprolist").html("");
				var count=0;
				var pstring='';
				for(var i in obj){
					pstring+='<ul><li class="w33 left"><label><input type="checkbox" name="prolist[]" value="'+parr[obj[i]["pId"]][0]+'" checked><i class="aui-iconfont aui-icon-correct"></i></label><a href="'
				+parr[obj[i]["pId"]][5]+'"><img src="'+parr[obj[i]["pId"]][6]+'"></a></li><li class="w57"><h6>'+parr[obj[i]["pId"]][1]+'</h6><p>单价：'+parseFloat(parr[obj[i]["pId"]][3])
				+'元</p><div class="num_select" pid="'+parr[obj[i]["pId"]][0]+'" data-num="'+parseInt(obj[i]["proS"])+'"><span class="reduce left">-</span> <span class="num left"><input type="text" value="'+parseInt(obj[i]["proS"])+'"></span> <span class="add left">+</span><div class="clear"></div></div></li><li class="w10"><div class="del" data-id="'+parr[obj[i]["pId"]][0]+'"><i class="aui-iconfont aui-icon-close"></i></div></li></ul>';
					count+=parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]);
				}
				$("#cartprolist").html(pstring);
				$('#count').html(count);
			}else{
				$("#empty_cart").show();
				$("#cart_mark").hide();
			}
		}
		function changecount(obj){
			var count=0;
			$('[name="prolist[]"]:checked').each(function(){
				var id=$(this).val();
				for(var i in obj){
					if(id==obj[i]["pId"]){
						count+=parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]);
					}
				}
			});
			$('#count').html(count);
		}
		$('.selectall_y').click(function(){
			if(this.checked){
				$('[name="prolist[]"]').prop("checked",true);
			  /*$('[name="prolist[]"]').each(function(){
				  $(this).attr("checked","true");  
			  })*/
			}else{   
			$('[name="prolist[]"]').prop("checked",false);
			/*
				$('[name="prolist[]"]').each(function(){
				  $(this).attr("checked","false");  
			  })*/
			}
			changecount(cur_cart);
		});
		function allchk(){
			var chknum = $('[name="prolist[]"]').size();//选项总个数
			var chk = 0;
			$('[name="prolist[]"]').each(function () {  
			if(this.checked){
				chk++;
			}
			});
			if(chknum==chk){//全选
				$('.selectall_y').prop("checked",true);
			}else{//不全选
				$('.selectall_y').prop("checked",false);
			}
			changecount(cur_cart);
		}
		$('#cartprolist').on('click','[name="prolist[]"]',function(){
			allchk();
		});
		$('#cartprolist').on('click','.del',function(){
			var id=$(this).data('id');
			dialog.alert({
			title:"温馨提示",
			msg:'是否确认删除',
			buttons:['取消','确定']
			},function(ret){
				if(ret.buttonIndex==2){
					changecart(id,'del');
				}
			})
		});
		$('#cartprolist').on('click','.add',function(i,e){
			changecart($(this).parent().attr('pid'),'+',1);
			var oldnum=$(this).parents('.num_select').data('num');
			$(this).parents('.num_select').data('num',parseInt(oldnum)+1);
		});
		$('#cartprolist').on('click','.reduce',function(){
			changecart($(this).parent().attr('pid'),'-',1);
			var oldnum=$(this).parents('.num_select').data('num');
			$(this).parents('.num_select').data('num',parseInt(oldnum)-1);
		});
		$('#cartprolist').on('change','.num input',function(){
			var oldnum=$(this).parents('.num_select').data('num');
			var num=parseInt($(this).val());
			if(num<1||num!=$(this).val()){
				num=oldnum;
				$(this).val(num);
				return false;
			}
				changecart($(this).parents('.num_select').attr('pid'),'=',num);
				$(this).parents('.num_select').data('num',num);
		});
		function changecart(id,type,num){
			for(var i in cur_cart){
				if(cur_cart[i].pId==id){
					switch(type){
					case '-':
						cur_cart[i].proS=parseInt(cur_cart[i].proS)-parseInt(num);
					break;
					case '+':
						cur_cart[i].proS=parseInt(cur_cart[i].proS)+parseInt(num);
					break;
					case '=':
						cur_cart[i].proS=parseInt(num);
					break;
					case 'del':
						cur_cart.splice(i, 1);
						continue;
					break;
					}
					if(cur_cart[i].proS<1){
						cur_cart[i].proS=0;
					}
				}
			}
			$.cookie("cart",JSON.stringify(cur_cart));
			show_cart(cur_cart);
		}
		$('#goacount').click(function(){
			 var pid_array=[];
			 $('[name="prolist[]"]:checked').each(function(){
				 pid_array.push($(this).val());
			 });
			 var pid_str=pid_array.join(',');
			  console.log(pid_str);
			 if(pid_str){
				 window.location.href="account.php?pid="+pid_str;
			 }else{
				 dialog.alert({
				title:"温馨提示",
				msg:'请选择要结算的商品',
				buttons:['确定']
				},function(ret){
				})
				return false;
			 }
		});
		
	})
	
	
	
	</script>


</body>
</html>