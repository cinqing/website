
		<!--header-->

	<div style=" max-width:640px; position:static">
    <header class="aui-bar aui-bar-nav ttop">
    <div class="logo"><a href="index.php" ><img src="newimg/index_03.jpg"  alt="美百颜官网"/></a></div>
    <a class="aui-pull-left aui-btn hd-btn" id="openMenu" href="javascript:;">
            <i class="icon icon-list"></i>
     </a>
       
        <div class="aui-tab aui-border-t headnew" id="tab">
        <div class="aui-tab-item aui-active"><a href="index.php" >首页</a></div>
        <div class="aui-tab-item  "><a href="team.php" >护肤导师</a></div>
        <div class="aui-tab-item "><a href="zhenxuan.php" >全球甄选</a></div>
        <div class="aui-tab-item "><a href="bushuimask.php" >新品上市</a></div>
       
 </div>
    </header>
</div>

    <div class="menu_tc" style="width:100%; height:100%; position:fixed; top:0; background:#000; display:none">
        <a id="openMenu" href="javascript:;" class="hd-btn1"><i class="icon icon-exit"></i></a>
    </div>
  <ul id="menu">
    <li><a href="index.php" >首页</a></li>
	<li><a href="listn.php"  >品牌商城</a></li>
    <li><a href="pphuodong.php"  >护理方案</a></li>
    <li><a href="zhenxuan.php" >全球甄选</a></li>
    <li><a href="anli.php"  >客户案例</a></li>
    <li><a href="pinpai.php"  >关于我们</a></li>
    <li><a href="team.php"  rel="nofollow">品牌荣誉</a></li>
    <li><a href="dinggou.php#order"  rel="nofollow">在线订购</a></li>
 
  </ul>

