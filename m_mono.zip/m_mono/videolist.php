<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>vidio视频</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>VENSE_video</title>
		<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
        <link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >

<script src="js/jquery.js" ></script>
	
</head>
<body>	<!--header-->
<div class="main">

<?php
include_once("top.php");
?>
 		
			<div class="kb-con">	
							<div class="pp-video">
					<div class="pp-con-title">
						<p>彩妆搞事情！不怕你不爱！</p>
						<!--<ul class="pp-like">
							<li></li>
							<li><a href="#">138</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					<div class="pp-video-img" href="#">
						<a href="videoshow.php-id=5.htm" ><img src="pinpai/vense/images/201708111805583721.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201708111805583721.jpg" alt="" /></a>
						<input class="videoplay-btn" type="button" name="" id="" value="" />
					</div>
					<div class="pp-con-time">
						<p>138</p>
						<h3>2017-06-18</h3>
						<div class="clearfix"></div>
					</div>
				</div>
							<div class="pp-video">
					<div class="pp-con-title">
						<p>护肤大讲堂 | 解读痘痘肌及油性肌肤</p>
						<!--<ul class="pp-like">
							<li></li>
							<li><a href="#">251</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					<div class="pp-video-img" href="#">
						<a href="videoshow.php-id=4.htm" tppabs="http://m.vense.cn/videoshow.php?id=4"><img src="pinpai/vense/images/201706220923567305.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201706220923567305.jpg" alt="" /></a>
						<input class="videoplay-btn" type="button" name="" id="" value="" />
					</div>
					<div class="pp-con-time">
						<p>251</p>
						<h3>2017-06-30</h3>
						<div class="clearfix"></div>
					</div>
				</div>
							<div class="pp-video">
					<div class="pp-con-title">
						<p>听日本专家讲讲鱼胶原蛋白肽的故事</p>
						<!--<ul class="pp-like">
							<li></li>
							<li><a href="#">361</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					<div class="pp-video-img" href="#">
						<a href="videoshow.php-id=3.htm" tppabs="http://m.vense.cn/videoshow.php?id=3"><img src="pinpai/vense/images/2017062209230716236.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017062209230716236.jpg" alt="" /></a>
						<input class="videoplay-btn" type="button" name="" id="" value="" />
					</div>
					<div class="pp-con-time">
						<p>361</p>
						<h3>2017-06-23</h3>
						<div class="clearfix"></div>
					</div>
				</div>
							<div class="pp-video">
					<div class="pp-con-title">
						<p>唯电影 |  520 爱就在一起</p>
						<!--<ul class="pp-like">
							<li></li>
							<li><a href="#">511</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					<div class="pp-video-img" href="#">
						<a href="videoshow.php-id=2.htm" tppabs="http://m.vense.cn/videoshow.php?id=2"><img src="pinpai/vense/images/201706220919143904.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201706220919143904.jpg" alt="" /></a>
						<input class="videoplay-btn" type="button" name="" id="" value="" />
					</div>
					<div class="pp-con-time">
						<p>511</p>
						<h3>2017-07-01</h3>
						<div class="clearfix"></div>
					</div>
				</div>
							<div class="pp-video">
					<div class="pp-con-title">
						<p>唯能量 | 科研力 鲜活肌</p>
						<!--<ul class="pp-like">
							<li></li>
							<li><a href="#">573</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					<div class="pp-video-img" href="#">
						<a href="videoshow.php-id=1.htm" tppabs="http://m.vense.cn/videoshow.php?id=1"><img src="pinpai/vense/images/2017062209173216009.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017062209173216009.jpg" alt="" /></a>
						<input class="videoplay-btn" type="button" name="" id="" value="" />
					</div>
					<div class="pp-con-time">
						<p>573</p>
						<h3>2017-07-29</h3>
						<div class="clearfix"></div>
					</div>
				</div>
							
				
			</div>
            
            		
   
   
   
<?php
include_once("foot.php");
?>




<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js"  ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" ></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
					
	<script>
				 $(document).ready(function(){
					$(".kb-nav>li").click( function(){
					var index=$(this).index();
					$(this).addClass("kb-navon").siblings().removeClass("kb-navon");
					$(".kb-con-product").eq(index).addClass('kb-con-product-on').siblings().removeClass('kb-con-product-on');
				});
				})
	</script>
	</body>
</html>