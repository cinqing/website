<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>shouhou售货服务</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>vense美百颜,重塑自然之美_美百颜官方网站  </title>
<meta name="keywords" content="美百颜,美百颜效果怎么样,美百颜官方网站,美百颜多少一套,美百颜官网,美百颜价钱,美百颜怎么样"/>
<meta name="description" content="美百颜以创新科技重组古老配方，塑造国际潮流的东方护肤美学，采用针对性护理方式应对不同年龄阶段肌肤问题，美百颜专业护肤老师为每一位肌肤问题用户提供完美的解决方案，塑造自然美肤。" />
<link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
</head>
<body>
<div class="main">

<div class="vv">
<div class="v_head">
<a href="javascript:void(0)" onclick="javascript:history.go(-1)"><img src="newimg/vs_03.png" ></a>
<span>售后服务</span>
</div>
</div>

<div class="shouhou_1">
<h2>联系客服</h2>
<div class="w100 shouh_l"><img src="newimg/fuwu_03.jpg" ></div>
</div>

<div class="shouhou_2">
<h2>售后服务</h2>


<section class="aui-content-padded">
        <ul class="aui-list aui-collapse aui-border">
		    <li>
	
	</li>
			
		
	
           
            <div class="aui-collapse-item">
                <li class="aui-list-item aui-collapse-header" tapmode>
                    <div class="aui-list-item-inner">
                        <div class="aui-list-item-title">退换货政策</div>
                        <div class="aui-list-item-right">
                            <i class="aui-iconfont aui-icon-down aui-collapse-arrow"></i>
                        </div>
                    </div>
                </li>
               <div class="aui-collapse-content aui-padded-15 aui-border-b">
                    <p style="font-family:Simsun;background-color:#FFFFFF;">
	<span> </span> 
</p>
<p class="MsoNormal">
	<b>退换货规定<span></span></b> 
</p>
<p class="MsoNormal">
	本网站订购产品，凡收到货物后发现以下情形的，可以在签收之日起的<span>7</span>天内无条件退换货：
</p>
<p class="MsoNormal">
	<br />
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">1) </span></b><b><span style="color:#666666;">收到货物时即发现产品破损； </span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">2) </span></b><b><span style="color:#666666;">与顾客在网站上订购的产品不同； </span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">3) </span></b><b><span style="color:#666666;">收到货物时即发现产品已过期；</span></b> 
</p>
<p class="MsoNormal">
	<b><br />
</b> 
</p>
<p class="MsoNormal">
	注：凡出现上述情形，我们将退还相应的货款并承担因退换货而产生的运费。顾客在本网站订购产品，在收到货物后发现不喜欢，订错了，或想换其他的产品，可以在签收之日起的<span>7</span>天内申请退换货，但必须满足以下条件：
</p>
<p class="MsoNormal">
	<br />
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">*退货产品的原包装未经拆开也未经使用；</span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">*退还的商品务必需跟收货时的原盒包装一样；</span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><br />
</b> 
</p>
<p class="MsoNormal">
	注：凡出现上述情形，我们将退还相应的货款，但顾客需自行承担因退换货而产生的运费。
</p>
<p class="MsoNormal">
	<br />
</p>
<p class="MsoNormal">
	顾客在本网站订购产品，使用后如出现不适，可以随时申请退换货，但必须满足以下条件：
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">*提供由中国大陆地区二级以上医院皮肤科出具的诊断报告；</span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">*诊断报告的出具日期系顾客签收货物之后；</span><span></span></b> 
</p>
<p class="MsoNormal">
	<b><span style="color:#666666;">*诊断报告上明确指出该不适现象系由化妆品引起；</span><span></span></b> 
</p>
<p class="MsoNormal">
	凡出现上述情形，我们将退还相应的货款并承担因退换货而产生的运费。
</p>
<p class="MsoNormal">
	我们只受理从本网站销售的产品的退换货。凡是从本网站以外渠道购买的产品，请联系原购买地协商退换货。
</p>
<p>
	<br />
</p>                </div>
            </div>
					
		
	
           
            <div class="aui-collapse-item">
                <li class="aui-list-item aui-collapse-header" tapmode>
                    <div class="aui-list-item-inner">
                        <div class="aui-list-item-title">退换货流程</div>
                        <div class="aui-list-item-right">
                            <i class="aui-iconfont aui-icon-down aui-collapse-arrow"></i>
                        </div>
                    </div>
                </li>
               <div class="aui-collapse-content aui-padded-15 aui-border-b">
                    <p>
	<br />
</p>
<p class="MsoNormal" style="text-indent:5.5pt;">
	<b><span>Q</span></b><b>：退换货规定<span></span></b> 
</p>
<p class="MsoNormal" style="text-indent:5.5pt;">
	<b><br />
</b> 
</p>
<p class="MsoNormal" style="text-indent:5.5pt;">
	<span>A</span>：请务必首先致电我们的客户服务部门（<span>400-679-9300</span>），告知所遇到的问题，然后根据我们客户服务代表的指示进行退换货；
</p>
<p class="MsoNormal" style="text-indent:5.5pt;">
	<br />
</p>
<p class="MsoNormal">
	<span style="color:#666666;">*退换货时请提供所有需要退换的产品，哪怕其已经破损或被打开；</span><span></span> 
</p>
<p class="MsoNormal">
	<br />
</p>
<p class="MsoNormal">
	<span style="color:#666666;">*退换货时请附上随产品一起送达的销售单据及售后服务卡</span><span></span> 
</p>
<p class="MsoNormal">
	<br />
</p>
<p class="MsoNormal">
	<span style="color:#666666;">*为了您的便利，请在致电我们客户服务部门时，告知您购买产品的订单号；</span> 
</p>
<p class="MsoNormal">
	<span style="color:#666666;"><br />
</span> 
</p>
<p class="MsoNormal">
	<b><span> </span></b> 
</p>
<p class="MsoNormal">
	<img src="../up.yiqiaitao.com/pinpai/vense/images/2017061715523090367.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017061715523090367.png" alt="" /> 
</p>
<p>
	<br />
</p>
<p>
	<br />
</p>                </div>
            </div>
					
		
	
           
            <div class="aui-collapse-item">
                <li class="aui-list-item aui-collapse-header" tapmode>
                    <div class="aui-list-item-inner">
                        <div class="aui-list-item-title">退款方式及时效</div>
                        <div class="aui-list-item-right">
                            <i class="aui-iconfont aui-icon-down aui-collapse-arrow"></i>
                        </div>
                    </div>
                </li>
               <div class="aui-collapse-content aui-padded-15 aui-border-b">
                    <p class="MsoNormal">
	收到退货并验明无误后，我们将在<span>24</span>小时之内完成退款。如果您当初是通过网上银行支付的，那么款项将退入您当时支付的银行卡中； 如果您当初是选用货到付款的，那么款项将通过邮政汇款的形式退还给您。<span></span>
</p>                </div>
            </div>
			           
        </ul>
    </section>

</div>


</div>
	
   
   
   
<?php
include_once("foot.php");
?>



<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js"  ></script>
	<script type="text/javascript" src="js/jquery.cookie.js"></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" ></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
<!-- 	<script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script> -->	

    <script type="text/javascript" src="dist/js/aui-collapse.js" ></script>
<script type="text/javascript">
    apiready = function () {
        api.parseTapmode();
    }
    var collapse = new auiCollapse({
        autoHide:true //是否自动隐藏已经展开的容器
    });
</script>

</body>
</html>