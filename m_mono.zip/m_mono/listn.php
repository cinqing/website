<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>list全部产品</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>美百颜产品价格_美百颜产品价目表_美百颜官方网站</title>
<meta name="keywords" content="美百颜,美百颜效果怎么样,美百颜官方网站,美百颜多少一套,美百颜官网,美百颜价钱,美百颜怎么样"/>
<meta name="description" content="美百颜产品价目表，提供美百颜所有的产品价格，给唯粉们做参考" />
<link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
<script src="dist/js/jquery.min.js"  type="text/javascript"></script>
</head>

<body>
<!--header-->
<div class="main">
<?php
include_once("top.php");
?>


<div class="l_c">
    <div class="l_c_l">
    <ul>
    <li>
        <a class='select'>去皱焕颜</a>
	    <a >祛斑修复</a>
	    <a >护肤保养</a>
	    <a >美容食品</a>
	    <!-- <a >品牌故事</a>
	    <a >在线订购</a> -->
	    <!-- <a >凝光沁亮系列</a>
	    <a >美容食品</a>
	    <a >通用系列</a>
	    <a >卓研晶透系列</a> -->
	    </li>
    </ul>
    </div>
    
    <div class="l_c_r">
		     	<div class="l_rm" id="cp1" style="display:block">
        <span><img src="mianmo_files/poster1.gif"  alt="美百颜舒润系列护肤品效果怎么样、适合什么年龄_美百颜官方网站"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="quzhou.php" ><img src="../mono/mono/images/201709181650336813.png"  alt="美百颜弹润紧致修护霜"></a></div>
			<div class="im_r"><p><a  href="quzhou.php"  >美百颜弹润紧致修护霜</a></p>
			<span>多效修护 击退暗沉细纹</span>
			<p class="pr_l">￥920</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="quzhou1.php" ><img src="../mono/mono/images/2017091816514310395.png"  alt="美百颜焕肌精华液"></a></div>
			<div class="im_r"><p><a  href="quzhou1.php">美百颜焕肌精华液</a></p>
			<span>水感透白 奢华成分自愈肌础</span>
			<p class="pr_l">￥590</p>
			</div>
			</li>
			
						<!-- <li>
			<div class="im_l"><a href="product.php-id=23.htm" tppabs="http://m.vense.cn/product.php?id=23"><img src="pinpai/vense/images/2017091509405117373.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017091509405117373.jpg" alt="舒润柔肤乳"></a></div>
			<div class="im_r"><p><a  href="product.php-id=23.htm" tppabs="http://m.vense.cn/product.php?id=23" >舒润柔肤乳</a></p>
			<span>补水再锁水，水分加持保湿亮采</span>
			<p class="pr_l">￥168</p>
			</div>
			</li> -->
			
						
        </div>
		     	<div class="l_rm" id="cp2" style="display:block">
        <span><img src="mianmo_files/poster2.gif" t alt="美百颜安护倍润系列护肤品效果怎么样、适合什么年龄_美百颜官方"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="quban.php" ><img src="../mono/mono/images/201801231551266532.png" ></a></div>
			<div class="im_r"><p><a  href="quban.php" >美百颜玛瑞安美白祛斑霜</a></p>
			<span>直击斑源 锻造无暇美肌</span>
			<p class="pr_l">￥920</p>
			</div>
			</li>
			
						<!-- <li>
			<div class="im_l"><a href="product.php-id=52.htm" tppabs="http://m.vense.cn/product.php?id=52"><img src="pinpai/vense/images/202003161420146720.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202003161420146720.jpg" alt="美百颜安护植润滋养霜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=52.htm" tppabs="http://m.vense.cn/product.php?id=52" >美百颜安护植润滋养霜</a></p>
			<span>舒柔修护，见证脆弱肌强韧新生</span>
			<p class="pr_l">￥260</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=54.htm" tppabs="http://m.vense.cn/product.php?id=54"><img src="pinpai/vense/images/202003230943113170.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202003230943113170.png" alt="美百颜安护植润系列"></a></div>
			<div class="im_r"><p><a  href="product.php-id=54.htm" tppabs="http://m.vense.cn/product.php?id=54" >美百颜安护植润系列</a></p>
			<span>近零刺激，舒柔呵护脆弱肌肤</span>
			<p class="pr_l">￥810</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=114.htm" tppabs="http://m.vense.cn/product.php?id=114"><img src="pinpai/vense/images/2020022419092617370.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2020022419092617370.jpg" alt="美百颜安护植润鲜肌水"></a></div>
			<div class="im_r"><p><a  href="product.php-id=114.htm" tppabs="http://m.vense.cn/product.php?id=114" >美百颜安护植润鲜肌水</a></p>
			<span>修护平衡柔肤水女收缩毛孔保湿</span>
			<p class="pr_l">￥138</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=115.htm" tppabs="http://m.vense.cn/product.php?id=115"><img src="pinpai/vense/images/2020022422353215330.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2020022422353215330.jpg" alt="美百颜安护植润修护乳"></a></div>
			<div class="im_r"><p><a  href="product.php-id=115.htm" tppabs="http://m.vense.cn/product.php?id=115" >美百颜安护植润修护乳</a></p>
			<span>滴滴鲜萃， 舒柔修护，强韧美肌</span>
			<p class="pr_l">￥198</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=116.htm" tppabs="http://m.vense.cn/product.php?id=116"><img src="pinpai/vense/images/202002242244575491.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202002242244575491.jpg" alt="美百颜安护鲜肌水养植萃面膜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=116.htm" tppabs="http://m.vense.cn/product.php?id=116" >美百颜安护鲜肌水养植萃面膜</a></p>
			<span>脆弱肌肤的隐形“保护衣”</span>
			<p class="pr_l">￥128</p>
			</div>
			</li> -->
			
						
        </div>
		     	<div class="l_rm" id="cp3" style="display:block">
        <span><img src="mianmo_files/poster3.jpg"  alt="美百颜智研光肌系列护肤品效果怎么样、适合什么年龄_美百颜官方"></span>
        <h2>产品列表</h2>
            <li>
				<div class="im_l"><a href="roufushui.php" ><img src="../mono/mono/images/2019062818275717146.png"  alt="美百颜玻尿酸水润护肤套盒"></a></div>
				<div class="im_r"><p><a  href="roufushui.php"  >美百颜玻尿酸水润护肤套盒</a></p>
				<span>快渗肌底 给肌肤满分水润</span>
				<p class="pr_l">￥404</p>
				</div>
			</li>
			<li>
				<div class="im_l"><a href="jiemian.php" ><img src="../mono/mono/images/201911151139436401.png"  alt="氨基酸温和洁面乳"></a></div>
				<div class="im_r"><p><a  href="jiemian.php"  >氨基酸温和洁面乳</a></p>
				<span>快渗肌底 给肌肤满分水润</span>
				<p class="pr_l">￥138</p>
				</div>
			</li>
						<li>
			<div class="im_l"><a href="bushuimask.php" ><img src="../mono/mono/images/2019112815352619149.png"  alt="美百颜莹润紧致多肽面膜"></a></div>
			<div class="im_r"><p><a  href="bushuimask.php"  >美百颜莹润紧致多肽面膜</a></p>
			<span>时光“膜”法 绽现无龄少女肌</span>
			<p class="pr_l">￥135</p>
			</div>
			</li>
			

			
			<li>
				<div class="im_l"><a href="ganyou.php" ><img src="../mono/mono/images/201801231552237628.png"  alt="人参护肤甘油"></a></div>
				<div class="im_r"><p><a  href="ganyou.php"  >人参护肤甘油</a></p>
				<span>加倍滋润 抗干燥的“守护器”</span>
				<p class="pr_l">￥99</p>
				</div>
			</li>
			
						
        </div>
		     	<div class="l_rm" id="cp4" style="display:block">
        <span><img src="mianmo_files/poster5.gif"  alt="美百颜肌源净澈系列护肤品效果怎么样、适合什么年龄_美百颜官方"></span>
        <h2>产品列表</h2>
        <li>
			<div class="im_l"><a href="jiaoyuandanbai.php" ><img src="../mono/mono/images/2018071313360210203.png" ></a></div>
			<div class="im_r"><p><a  href="jiaoyuandanbai.php" >美百颜燕窝胶原蛋白肽果饮</a></p>
			<span>每天一瓶 维稳肌肤年轻态</span>
			<p class="pr_l">￥398</p>
			</div>
			</li>
						
        </div>
		     	<!-- <div class="l_rm" id="cp5" style="display:block">
        <span><img src="pinpai/vense/images/2019010215485615447.jpg"  alt="美百颜肌妍新生系列护肤品效果怎么样、适合什么年龄_美百颜官方"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="product.php-id=56.htm" ><img src="../mono/mono/images/2018071313360210203.png" ></a></div>
			<div class="im_r"><p><a  href="product.php-id=56.htm" >美百颜燕窝胶原蛋白肽果饮</a></p>
			<span>每天一瓶 维稳肌肤年轻态</span>
			<p class="pr_l">￥398</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=57.htm" tppabs="http://m.vense.cn/product.php?id=57"><img src="pinpai/vense/images/2017091509571313567.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017091509571313567.jpg" alt="肌妍新生滋养霜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=57.htm" tppabs="http://m.vense.cn/product.php?id=57" >肌妍新生滋养霜</a></p>
			<span>由脸部到颈部，让青春成为你的囊中物</span>
			<p class="pr_l">￥360</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=58.htm" tppabs="http://m.vense.cn/product.php?id=58"><img src="pinpai/vense/images/201709150957539033.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709150957539033.jpg" alt="肌妍新生系列"></a></div>
			<div class="im_r"><p><a  href="product.php-id=58.htm" tppabs="http://m.vense.cn/product.php?id=58" >肌妍新生系列</a></p>
			<span>新生抗皱，改写时光剧本</span>
			<p class="pr_l">￥960</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=59.htm" tppabs="http://m.vense.cn/product.php?id=59"><img src="pinpai/vense/images/2017091509581617045.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017091509581617045.jpg" alt="肌妍新生精华液"></a></div>
			<div class="im_r"><p><a  href="product.php-id=59.htm" tppabs="http://m.vense.cn/product.php?id=59" >肌妍新生精华液</a></p>
			<span>多倍吸收，为肌肤注入年轻能量</span>
			<p class="pr_l">￥320</p>
			</div>
			</li>
			
						
        </div>
		     	<div class="l_rm" id="cp6" style="display:block">
        <span><img src="pinpai/vense/images/201901021549215963.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201901021549215963.jpg" alt="美百颜去黑头套装怎么样有效吗、多少钱_美百颜官方网站"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="product.php-id=22.htm" tppabs="http://m.vense.cn/product.php?id=22"><img src="pinpai/vense/images/201709151429425828.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709151429425828.jpg" alt="毛孔紧致护理套装"></a></div>
			<div class="im_r"><p><a  href="product.php-id=22.htm" tppabs="http://m.vense.cn/product.php?id=22" >毛孔紧致护理套装</a></p>
			<span> 打开+吸出+收缩，轻松去除难缠黑头</span>
			<p class="pr_l">￥296</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=24.htm" tppabs="http://m.vense.cn/product.php?id=24"><img src="pinpai/vense/images/201709150941375066.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709150941375066.jpg" alt="赋活毛孔细致精华液"></a></div>
			<div class="im_r"><p><a  href="product.php-id=24.htm" tppabs="http://m.vense.cn/product.php?id=24" >赋活毛孔细致精华液</a></p>
			<span>隐匿毛孔，宛若蛋白</span>
			<p class="pr_l">￥320</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=27.htm" tppabs="http://m.vense.cn/product.php?id=27"><img src="pinpai/vense/images/201709150943335779.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709150943335779.jpg" alt="毛孔细致精华液"></a></div>
			<div class="im_r"><p><a  href="product.php-id=27.htm" tppabs="http://m.vense.cn/product.php?id=27" >毛孔细致精华液</a></p>
			<span>强劲收敛，肌肤的毛孔“隐形术”</span>
			<p class="pr_l">￥108</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=28.htm" tppabs="http://m.vense.cn/product.php?id=28"><img src="pinpai/vense/images/201709150945177323.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709150945177323.jpg" alt="美百颜黑头导出液"></a></div>
			<div class="im_r"><p><a  href="product.php-id=28.htm" tppabs="http://m.vense.cn/product.php?id=28" >美百颜黑头导出液</a></p>
			<span>导出黑头，还毛孔一个“清”白</span>
			<p class="pr_l">￥108</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=29.htm" tppabs="http://m.vense.cn/product.php?id=29"><img src="pinpai/vense/images/201709150945494493.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709150945494493.jpg" alt="美百颜黑头吸附面膜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=29.htm" tppabs="http://m.vense.cn/product.php?id=29" >美百颜黑头吸附面膜</a></p>
			<span>深拔净透，清理T区难缠黑头</span>
			<p class="pr_l">￥80</p>
			</div>
			</li>
			
						
        </div>
		     	<div class="l_rm" id="cp7" style="display:block">
        <span><img src="pinpai/vense/images/201901021549093834.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201901021549093834.jpg" alt="美百颜凝光沁亮系列护肤品效果怎么样、适合什么年龄_美百颜官方"></span>
        <h2>产品列表</h2>
						
        </div>
		     	<div class="l_rm" id="cp8" style="display:block">
        <span><img src="" alt=""></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="product.php-id=92.htm" tppabs="http://m.vense.cn/product.php?id=92"><img src="pinpai/vense/images/2017102412232311313.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017102412232311313.png" alt="鱼胶原蛋白肽粉30支装"></a></div>
			<div class="im_r"><p><a  href="product.php-id=92.htm" tppabs="http://m.vense.cn/product.php?id=92" >鱼胶原蛋白肽粉30支装</a></p>
			<span>每天一杯，喝出逆龄年轻态  </span>
			<p class="pr_l">￥1680</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=93.htm" tppabs="http://m.vense.cn/product.php?id=93"><img src="pinpai/vense/images/201711061800143549.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201711061800143549.png" alt="鱼胶原蛋白肽粉10支装"></a></div>
			<div class="im_r"><p><a  href="product.php-id=93.htm" tppabs="http://m.vense.cn/product.php?id=93" >鱼胶原蛋白肽粉10支装</a></p>
			<span>每天喝一杯，喝出逆龄年轻态</span>
			<p class="pr_l">￥580</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=94.htm" tppabs="http://m.vense.cn/product.php?id=94"><img src="pinpai/vense/images/201906281827576188.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201906281827576188.png" alt="植物源性花青素固体饮料"></a></div>
			<div class="im_r"><p><a  href="product.php-id=94.htm" tppabs="http://m.vense.cn/product.php?id=94" >植物源性花青素固体饮料</a></p>
			<span>一扫肌肤疲惫，再现奕奕光彩</span>
			<p class="pr_l">￥580</p>
			</div>
			</li>
			
						
        </div>
		     	<div class="l_rm" id="cp9" style="display:block">
        <span><img src="pinpai/vense/images/201709151608313442.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201709151608313442.jpg" alt="美百颜通用系列护肤品效果怎么样、适合什么年龄_美百颜官方网站"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="javascript:if(confirm('http://m.vense.cn/product.php?id=74  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=74'" tppabs="http://m.vense.cn/product.php?id=74"><img src="pinpai/vense/images/2017091510051717615.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2017091510051717615.jpg" alt="聚能修护精华液"></a></div>
			<div class="im_r"><p><a  href="javascript:if(confirm('http://m.vense.cn/product.php?id=74  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=74'" tppabs="http://m.vense.cn/product.php?id=74" >聚能修护精华液</a></p>
			<span>祛红实力派，奢华成分自愈肌础</span>
			<p class="pr_l">￥420</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=102.htm" tppabs="http://m.vense.cn/product.php?id=102"><img src="pinpai/vense/images/201807131336024298.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201807131336024298.jpg" alt="鲜肌酵母精华水"></a></div>
			<div class="im_r"><p><a  href="product.php-id=102.htm" tppabs="http://m.vense.cn/product.php?id=102" >鲜肌酵母精华水</a></p>
			<span>一瓶多效的平价“神仙水”</span>
			<p class="pr_l">￥218</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=103.htm" tppabs="http://m.vense.cn/product.php?id=103"><img src="pinpai/vense/images/2018073017031712381.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2018073017031712381.jpg" alt="美百颜净润卸妆乳"></a></div>
			<div class="im_r"><p><a  href="product.php-id=103.htm" tppabs="http://m.vense.cn/product.php?id=103" >美百颜净润卸妆乳</a></p>
			<span>净爽卸妆力，清透润活肌</span>
			<p class="pr_l">￥168</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=106.htm" tppabs="http://m.vense.cn/product.php?id=106"><img src="pinpai/vense/images/2019062917593510153.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2019062917593510153.jpg" alt="美百颜角鲨烷舒缓鲜肌喷雾"></a></div>
			<div class="im_r"><p><a  href="product.php-id=106.htm" tppabs="http://m.vense.cn/product.php?id=106" >美百颜角鲨烷舒缓鲜肌喷雾</a></p>
			<span>保湿补水，舒缓，修护屏障</span>
			<p class="pr_l">￥128</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=108.htm" tppabs="http://m.vense.cn/product.php?id=108"><img src="pinpai/vense/images/2019092917513914239.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2019092917513914239.png" alt="晶彩松露胜肽眼膜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=108.htm" tppabs="http://m.vense.cn/product.php?id=108" >晶彩松露胜肽眼膜</a></p>
			<span>亮眼美眸，减龄加颜值</span>
			<p class="pr_l">￥168</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=110.htm" tppabs="http://m.vense.cn/product.php?id=110"><img src="pinpai/vense/images/201910291820001217.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201910291820001217.png" alt="保加利亚玫瑰花水面膜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=110.htm" tppabs="http://m.vense.cn/product.php?id=110" >保加利亚玫瑰花水面膜</a></p>
			<span>100%玫瑰花水，可以天天敷的面膜</span>
			<p class="pr_l">￥138</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=111.htm" tppabs="http://m.vense.cn/product.php?id=111"><img src="pinpai/vense/images/2019102918243214736.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2019102918243214736.png" alt="四重玻尿酸水库面膜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=111.htm" tppabs="http://m.vense.cn/product.php?id=111" >四重玻尿酸水库面膜</a></p>
			<span>4D立体补水，锁水修护，打造爆水透亮肌肤</span>
			<p class="pr_l">￥138</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=112.htm" tppabs="http://m.vense.cn/product.php?id=112"><img src="pinpai/vense/images/2019112815352811331.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/2019112815352811331.jpg" alt="城市霓虹丝悦唇膏口红"></a></div>
			<div class="im_r"><p><a  href="product.php-id=112.htm" tppabs="http://m.vense.cn/product.php?id=112" >城市霓虹丝悦唇膏口红</a></p>
			<span>持久显色，上演红唇诱惑。</span>
			<p class="pr_l">￥99</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=117.htm" tppabs="http://m.vense.cn/product.php?id=117"><img src="pinpai/vense/images/202003271311538925.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202003271311538925.png" alt="美百颜清透亮采防晒霜"></a></div>
			<div class="im_r"><p><a  href="product.php-id=117.htm" tppabs="http://m.vense.cn/product.php?id=117" >美百颜清透亮采防晒霜</a></p>
			<span>7种防晒剂，复合防晒体系，有效防护UVA和UVB紫外线损伤；</span>
			<p class="pr_l">￥128</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=118.htm" tppabs="http://m.vense.cn/product.php?id=118"><img src="pinpai/vense/images/202003301121288441.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202003301121288441.png" alt="美百颜净润舒缓卸妆液 养肤级卸妆"></a></div>
			<div class="im_r"><p><a  href="product.php-id=118.htm" tppabs="http://m.vense.cn/product.php?id=118" >美百颜净润舒缓卸妆液 养肤级卸妆</a></p>
			<span>养肤级卸妆液，有效清除脸部多种杂质</span>
			<p class="pr_l">￥168</p>
			</div>
			</li>
			
						
        </div>
		     	<div class="l_rm" id="cp10" style="display:block">
        <span><img src="" alt="卓研晶透系列"></span>
        <h2>产品列表</h2>
						<li>
			<div class="im_l"><a href="product.php-id=44.htm" tppabs="http://m.vense.cn/product.php?id=44"><img src="pinpai/vense/images/201911151620211488.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201911151620211488.jpg" alt="卓研晶透祛斑精华液"></a></div>
			<div class="im_r"><p><a  href="product.php-id=44.htm" tppabs="http://m.vense.cn/product.php?id=44" >卓研晶透祛斑精华液</a></p>
			<span>快速渗透，层层瓦解沉积浊质</span>
			<p class="pr_l">￥330</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="product.php-id=109.htm" tppabs="http://m.vense.cn/product.php?id=109"><img src="pinpai/vense/images/201909301115234803.png" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201909301115234803.png" alt="VENSE美百颜 美百颜卓研晶透系列"></a></div>
			<div class="im_r"><p><a  href="product.php-id=109.htm" tppabs="http://m.vense.cn/product.php?id=109" >VENSE美百颜 美百颜卓研晶透系列</a></p>
			<span>净澈肌底环境，从肌底层亮澈净透肌肤，再现匀净透亮光彩。</span>
			<p class="pr_l">￥690</p>
			</div>
			</li>
			
						<li>
			<div class="im_l"><a href="javascript:if(confirm('http://m.vense.cn/product.php?id=113  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=113'" tppabs="http://m.vense.cn/product.php?id=113"><img src="pinpai/vense/images/202001131800338079.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/202001131800338079.jpg" alt="卓研晶透祛斑滋养霜"></a></div>
			<div class="im_r"><p><a  href="javascript:if(confirm('http://m.vense.cn/product.php?id=113  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=113'" tppabs="http://m.vense.cn/product.php?id=113" >卓研晶透祛斑滋养霜</a></p>
			<span>净澈肌底环境，从肌底层亮澈净透肌肤，再现匀净透亮光彩。</span>
			<p class="pr_l">￥360</p>
			</div>
			</li>
			
						
        </div> -->
		        
        
        
        
    </div>
</div>


</div>
	
  
   
   
  
   
   
  
		
<?php
include_once("foot.php");
?>

<br><br><br>

<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js" ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" ></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
<!-- 	<script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>	 -->

	<script>

	$(".l_c_l li >a").click(function(){
		index = $(this).index();
		$(".l_c_l li >a").removeClass('select').eq(index).addClass('select');
		$(".l_c_r").children(".l_rm").hide().eq(index).show();
	})
	$(".l_c_r").children(".l_rm").hide();
	$("#cp1").show();
	
	
	var drop = $('.l_c_l').offset().top
window.onscroll = function () {
				if ($(document).scrollTop() >  (0)) {
					$(".l_c_l").addClass('abx1');
				}
				else {
					$(".l_c_l").removeClass('abx1');
				}
			}



</script>

</body>
</html>