<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>VENSE_video</title>
        <link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
        <link rel="stylesheet" href="css/aui.css" >
        <link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
        <!-- Bootstrap -->
<link href="css/bootstrap.min.css"  rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.js" ></script>
</head>
<body>
    <div class="qrcode" style="position:relative">
    <!-- <p><img src="dist/images/qrcode.jpg" ></p> -->
    <!-- <div style="position:absolute; z-index:10; bottom:4.3em; left:58%;">
        <span style="background:#553097;color:#fff; padding:0 1em;">qq19301</span>
    </div> -->
  </div>
   <div class="footnew">
       <div class="w100"><img src="newimg/footnew_01.jpg" ></div>
       <!-- <div class="w100"><img src="newimg/sss.jpg" > -->
       <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-top:1em">美百颜护肤导师在线：020-83620466</p>
       <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem">地址：广东省广州市花都区新华街</p>
       <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-bottom:1em">2020 美百颜官网 www.monobeau.com 版权所有</p>
       </div>
   </div>
    <footer class="aui-bar aui-bar-tab aui-border-t" id="footer" >
            <div class="aui-bar-tab-item" tapmode>
                <i class="fa fa-home"></i>
                <div class="aui-bar-tab-label"><a href="index.php" >首页</a></div>
            </div>
            <div class="aui-bar-tab-item" tapmode><a href="listn.php" >
                <i class="fa fa-bars"></i>
                <div class="aui-bar-tab-label">分类</div></a>
            </div>
           <!--  <div class="aui-bar-tab-item" tapmode >
            <a href="pinpai.php" >
                    <div class="aui-badge">...</div>
                    <img src="newimg/i_3.png"  width="25" style="margin: 0 auto; display: inline; position: relative;top:3px"> 
                    <div class="aui-bar-tab-label" style="margin-top: -2px">关于</div>
                    </a>
            </div>  -->
             <div class="aui-bar-tab-item" tapmode>
            <a href="pinpai.php" >
                <!-- <div class="aui-dot"></div> -->
                <i class="fa fa-user"></i>
                <div class="aui-bar-tab-label">关于</div>
                </a>
            </div>
            
            <div class="aui-bar-tab-item" tapmode>
            <a href="dinggou.php" >
                <div class="aui-badge cart_count">0</div>
                <i class="fa fa-shopping-bag"></i>
                <div class="aui-bar-tab-label">购物车</div>
            </a>
            </div>
             
    </footer>
    <div class="fx_main">
        <div class="fx_vm">
        <div class="fenxiang bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1505366263498">
                       
                            <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                            <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                            <a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
                            <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                        </div>
        <span class="fx_close">取消</span>
        </div>
    </div>
</body>
</html>
  

