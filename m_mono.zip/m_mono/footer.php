<div class="qrcode" style="position:relative">
    <!-- <p><img src="dist/images/qrcode.jpg" ></p> -->
    <!-- <div style="position:absolute; z-index:10; bottom:4.3em; left:58%;">
    	<span style="background:#553097;color:#fff; padding:0 1em;">qq19301</span>
    </div> -->
  </div>
   <div class="footnew">
	   <div class="w100"><img src="newimg/footnew_01.jpg" ></div>
	  <!--  <div class="w100"><img src="newimg/sss.jpg" > -->
	   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-top:1em">美百颜护肤导师在线：020-83620466</p>
	   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem">地址：广东省广州市花都区新华街</p>
	   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-bottom:1em">2020 美百颜官网 www.vense.cn 版权所有</p>
	   </div>
   </div>