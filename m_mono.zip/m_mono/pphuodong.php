<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>pphuodong品牌活动</title>
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
        <link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<script src="dist/js/zepto.min.js" ></script>
<script src="dist/js/main.js" ></script>
<script src="dist/js/tool.js" ></script>
<script src="dist/js/swipe.js" ></script>
<script src="js/jquery.js" ></script>
</head>
<body>	<!--header-->
<div class="main">


<?php
include_once("top.php");
?>
 		
        

<div class="w100"><img src="zhuanti/pphuodong/images/pc1_01.jpg" ></div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_02.jpg" >
</div>

<div class="w100"><img src="zhuanti/pphuodong/images/pc1_03.jpg" ></div>

<div class="w100"><img src="zhuanti/pphuodong/images/pc1_05.jpg" ></div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_06.jpg" ></div>
<div class="w100" style="position:relative">
<img src="zhuanti/pphuodong/images/pc1_07.jpg" t>
<!-- <a href="product.php-id=39.htm"  style="display:block; width:24%; height:35px; position:absolute; top:20%; right:18%"></a> -->
</div>
<!-- <div class="w100"><img src="zhuanti/pphuodong/images/pc1_08.jpg" ></div>

<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_09.jpg" >
<a href="product.php-id=46.htm"  style="display:block; width:29%; height:35px; position:absolute; top:73%; right:7%"></a>
</div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_10.jpg" ></div>

<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_11.jpg" >

<a href="product.php-id=13.htm"  style="display:block; width:29%; height:35px; position:absolute; top:51%; left:11%"></a>
<a href="product.php-id=14.htm"  style="display:block; width:29%; height:35px; position:absolute; top:51%; right:12%"></a>
</div>

<div class="w100"><img src="zhuanti/pphuodong/images/pc1_12.jpg" ></div>
<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_13.jpg" >
<a href="product.php-id=12.htm"  style="display:block; width:29%; height:35px; position:absolute; top:42%; left:11%"></a>
<a href="product.php-id=49.htm"  style="display:block; width:29%; height:35px; position:absolute; top:42%; right:12%"></a>
</div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_14.jpg" ></div>

<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_15.jpg" >
<a href="product.php-id=26.htm"  style="display:block; width:29%; height:35px; position:absolute; top:73%; right:7%"></a>
</div>

<div class="w100"><img src="zhuanti/pphuodong/images/pc1_16.jpg" ></div>
<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_17.jpg" >
<a href="product.php-id=51.htm"  style="display:block; width:29%; height:35px; position:absolute; top:25%; right:15%"></a>
</div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_18.jpg" ></div>
<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_19.jpg" >
<a href="product.php-id=23.htm"  style="display:block; width:29%; height:35px; position:absolute; top:57%; left:9%"></a>
<a href="javascript:if(confirm('http://m.vense.cn/product.php?id=74  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=74'"  style="display:block; width:29%; height:35px; position:absolute; top:57%; right:9%"></a>
</div>
<div class="w100"><img src="zhuanti/pphuodong/images/pc1_20.jpg" ></div>
<div class="w100" style="position:relative"><img src="zhuanti/pphuodong/images/pc1_21.jpg" >
<a href="product.php-id=53.htm"  style="display:block; width:29%; height:35px; position:absolute; top:65%; left:9%"></a>
<a href="product.php-id=27.htm"  style="display:block; width:29%; height:35px; position:absolute; top:65%; right:9%"></a>
</div> -->
     
        
            
            		
 <?php
include_once("foot.php");
?>



<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js"  ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" tppabs="http://m.vense.cn/js/ZeroClipboard.js"></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6"/*tpa=https://tb.53kf.com/code/code/10159345/6*/;var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>				<script>
				 $(document).ready(function(){
					$(".kb-nav>li").click( function(){
					var index=$(this).index();
					$(this).addClass("kb-navon").siblings().removeClass("kb-navon");
					$(".kb-con-product").eq(index).addClass('kb-con-product-on').siblings().removeClass('kb-con-product-on');
				});
				})
			</script>
	</body>
</html>