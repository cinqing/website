
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>客户案例</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>美白颜官网-客户案例</title>
		<link rel="icon" href="image/ico.ico">
		<!-- 轮播 -->
		<link rel="stylesheet" type="text/css" href="images/swiper.min.css">
		<!-- 动画css -->
		<link rel="stylesheet" type="text/css" href="images/animate.css">
		<!-- css样式重置 -->
		<link rel="stylesheet" type="text/css" href="images/reset.css">
		<!-- 公共css -->
		<!-- <link rel="stylesheet" type="text/css" href="images/base.css">
		<link rel="stylesheet" type="text/css" href="images/index.css"> -->
		<!-- 畅销热榜 -->
		<link rel="stylesheet" type="text/css" href="images/bestseller_list.css">
		<script type="text/javascript" src="images/jquery-1.7.2.min.js"></script>
</head>
<body>
		<!-- 头部开始 -->
<?php
include_once("top.php");
?>

		
		<!-- 头部结束 -->
		<!-- 悬浮头部开始 -->
		
		
		<!-- 在线咨询 -->
			
			
		<!-- /在线咨询 -->
		<!-- 回到顶部 -->
		<div class="goTop" style="display: block;">
			<img src="images/goTop_icon.png" alt="回到顶部" title="回到顶部">
		</div>
<!-- 全局js -->
<script type="text/javascript" src="images/swiper.js"></script>
<script type="text/javascript" src="images/wow.min.js"></script>
<!-- 公共js -->
<script type="text/javascript" src="images/base.js"></script>
<!-- 单页面引用 -->
<script type="text/javascript" src="images/index.js"></script>
<script>
	
	$(".ico_off").on('click', function() {
		$('.Online_win').hide()
	})
	
	
	$(window).scroll(function(){
		var toTop = $(window).scrollTop();
		if(toTop > 400){
			$(".goTop").fadeIn(500)
		}else{
			$(".goTop").fadeOut(500);
		}
	});
	$(".goTop").click(function(){
		$("html,body").animate({"scrollTop":0},500);	
	})
</script>

		<!-- 悬浮头部结束 -->
		<style>
			.hot_pro_img_box {
			    background-image: none;
				height: auto;
			   
			}
		</style>
		<!-- 畅销banner -->
		<!-- <div class="cx_banner">
			<img src="images/cx_banner.png">
		</div> -->
		<!-- /畅销banner -->
		<!-- 热榜 -->
		<div class="hot_list" style="margin-top: 20px;">
			<div class="content_wrapper">

				<!-- 产品1 -->
				<div class="hot_team wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num1.png">
						<img class="anli" src="images/005.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>35岁</div>
							<div><span>肌肤问题：</span>法令纹、皮肤松弛</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除法令纹后，颜值爆表</h3>
							<p class="series">—— 用时：2个月 ——</p>
							<!-- <div class="price">￥810 元</div> -->
							<!-- <a href="http://www.vense.cn/good_info.php?pid=54" class="buy_btn">立即购买</a> -->
						</div>
					</div>
				</div>
				<!-- /产品1 -->
				<!-- 产品2 -->
				<div class="hot_team  team_row-reverse wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">			
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num2.png">
						<img class="anli" src="images/006.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>42岁</div>
							<div><span>肌肤问题：</span>眼纹、法令纹</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">眼纹、法令纹都去掉了!美如少女！</h3>
							<p class="series">—— 用时：2个半月——</p>
						</div>
					</div>
					
				</div>
				<!-- /产品2 -->
                <!-- 产品3 -->
				<div class="hot_team  wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num3.png">
						<img class="anli" src="images/007.png">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>28岁</div>
							<div><span>肌肤问题：</span>眼角皱纹、黄褐斑</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除了鱼尾纹、黄褐斑，肤质水润！减龄！</h3>
							<p class="series">—— 用时：1个半月——</p>
						</div>
					</div>
				</div>
				<!-- /产品3 -->
				<!-- 产品4 -->
				<div class="hot_team  team_row-reverse wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num4.png">
						<img class="anli" src="images/008.png">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>42岁</div>
							<div><span>肌肤问题：</span>鱼尾纹、皮肤干燥</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除了鱼尾纹，皮肤变得弹嫩！</h3>
							<p class="series">—— 用时：2个月——</p>
						</div>
					</div>
					
					
				</div>
				<!-- /产品4 -->
				<!-- 产品5 -->
				<div class="hot_team wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num5.png">
						<img class="anli" src="images/009.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>27岁</div>
							<div><span>肌肤问题：</span>鱼尾纹</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除了鱼尾纹，年轻而赋有活力！</h3>
							<p class="series">—— 用时：1个半月——</p>
						</div>
					</div>

				</div>
				<!-- /产品5 -->
				<!-- 产品6 -->
				<div class="hot_team  team_row-reverse wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">

					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num6.png">
						<img class="anli" src="images/001.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>30岁</div>
							<div><span>肌肤问题：</span>颈纹、皮肤松弛</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除颈纹，更显年轻</h3>
							<p class="series">—— 用时：1个月——</p>
						</div>
					</div>

				</div>
				<!-- /产品6 -->
				<!-- 产品7 -->
				<div class="hot_team  wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num7.png">
						<img class="anli" src="images/002.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>29岁</div>
							<div><span>肌肤问题：</span>额头纹</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除额头纹，皮肤水润，尽显年轻！</h3>
							<p class="series">—— 用时：2个月——</p>
						</div>
					</div>

				</div>
				<!-- /产品7 -->
				<!-- 产品8 -->
				<div class="hot_team  team_row-reverse wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num8.png">
						<img class="anli" src="images/003.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>41岁</div>
							<div><span>肌肤问题：</span>皮肤松弛、法令纹</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除法令纹，皮肤弹嫩，年轻活力！</h3>
							<p class="series">—— 用时：2个半月——</p>
						</div>
					</div>
					
					
				</div>
				<!-- /产品8 -->
				<!-- 产品9 -->
				<div class="hot_team   wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num9.png">
						<img class="anli" src="images/004.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>53岁</div>
							<div><span>肌肤问题：</span>法令纹、黄褐斑</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除 法令纹和黄褐斑，年轻十岁！</h3>
							<p class="series">—— 用时：3个月——</p>
						</div>
					</div>

					
				</div>
				<!-- /产品9 -->
				<!-- 产品10 -->
				<div class="hot_team  team_row-reverse wow fadeInUp animated animated" data-wow-duration="0.5" data-wow-delay="0.5" style="visibility: visible;">
					<div class="hot_team_top clearfix">
						<img class="nums" src="images/num10.png">
						<img class="anli" src="images/000.jpg">
						
					</div>
					<div class="hot_team_bottom">
						<div class="hot_pro_slogan ">
							<div><span >年龄：</span>28岁</div>
							<div><span>肌肤问题：</span>川字纹、皮肤干燥</div>	
						</div>
						<div class="hot_tit">
							<h3 class="effect">去除川字纹，皮肤水润、年轻甜美！</h3>
							<p class="series">—— 用时：2个月——</p>
						</div>
					</div>
					
					
				</div>
				<!-- /产品10 -->
			</div>
		</div>
		<!-- /热榜 -->

		
		<!-- <div class="Online">
			<a class="line_btn"><span class="yuan">&nbsp;&nbsp;</span><span>在线咨询</span></a>
		</div>
		<div class="Online_win">
			<div class="Online_win_tit"><span>扫码在线咨询</span><img src="images/up_icon.png" class="ico_off"></div>
			<img src="images/wechat.jpg" class="online_erweima" >
			<p class="Online_win_weixin">
				微信扫一扫获取护肤<br>
				老师一对一指导方案
			</p>
		</div> -->
		<!-- 底部 -->

		<!-- /底部结束 -->
<?php
include_once("foot.php");
?>
	

<!-- 单页面引用 -->

<!-- 全局js -->
<script type="text/javascript" src="images/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="images/swiper.js"></script>
<script type="text/javascript" src="images/wow.min.js"></script>
<!-- 公共js -->
<script type="text/javascript" src="images/base.js"></script>
<!-- 单页面引用 -->
<script type="text/javascript">
	// 执行滚动动画
		if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {
			new WOW().init();
		};
</script>
</body>
</html>
