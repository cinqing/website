
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>index主页</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>VENSE美百颜一个提供专属肌肤护理方案的商城_美百颜官方商城</title>
<meta name="keywords" content="美百颜,美百颜效果怎么样,美百颜官方网站,美百颜多少一套,美百颜官网,美百颜价钱,美百颜怎么样"/>
<meta name="description" content="美百颜以创新科技重组古老配方，塑造国际潮流的东方护肤美学，采用针对性护理方式应对不同年龄阶段肌肤问题，美百颜专业护肤老师为每一位肌肤问题用户提供完美的解决方案，塑造自然美肤。" />
<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
<link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="css/aui-slide.css"  />
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
<script src="dist/js/jquery-1.10.2.min.js"  type="text/javascript"></script>

<script type="text/javascript" src="js/spread_header.js" ></script>  

<script src="dist/js/main.js" ></script>
<script type="text/javascript" src="dist/js/aui-slide.js" ></script>
<script type="js/html5shiv.js"></script>
<script type="js/respond.min.js"></script>

</head>
<body>
	<!--header-->
<div class="main">

<?php
include_once("top.php");
?>
<style type="text/css">
  /* 轮播广告 */
     .carousel {
        max-width: 640px;
        width: 100%;
            height: 17rem;
           /* margin-bottom: 60px;*/
        }

        .carousel .item {
            height: 340px;
            /*background-color: #000;*/
        }

        .carousel .item img {
            width: 100%;
        }     
</style>
 <div id="carousel-ad" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carousel-ad" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-ad" data-slide-to="1"></li>
            <li data-target="#carousel-ad" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
            <div class="item active"><img class="img-responsive" src="pinpai/vense/images/201801050919051150.jpg"></div>
            <div class="item"><img class="img-responsive" src="pinpai/vense/images/201802231043296503.jpg"></div>
            <div class="item"><img class="img-responsive" src="pinpai/vense/images/201802231048458789.jpg"></div>
        </div>
    </div>
 

  <!-- <div class="banner">
   <div id="aui-slide2">
        <div class="aui-slide-wrap" >
		            <div class="aui-slide-node aui-slide-node-middle aui-slide-node-center">
                <div class="aui-content aui-padded-15">
		<a href="zhenxuan.php.htm" ><img src="pinpai/vense/images/201801050919051150.jpg"  alt="美百颜肌肤护理网站"></a>
                </div>
            </div>
		            <div class="aui-slide-node aui-slide-node-middle aui-slide-node-center">
                <div class="aui-content aui-padded-15">
		<a href="product.php-id=92.htm" tppabs="http://m.vense.cn/product.php?id=92"><img src="pinpai/vense/images/201802231043296503.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201802231043296503.jpg" alt=""></a>
                </div>
            </div>
		            <div class="aui-slide-node aui-slide-node-middle aui-slide-node-center">
                <div class="aui-content aui-padded-15">
		<a href="product.php-id=35.htm" tppabs="http://m.vense.cn/product.php?id=35"><img src="pinpai/vense/images/201802231048458789.jpg" tppabs="http://up.yiqiaitao.com/pinpai/vense/images/201802231048458789.jpg" alt=""></a>
                </div>
            </div>
		
        </div>
        <div class="aui-slide-page-wrap"></div>
    </div>
   
 </div> -->

  <!--indexblock-->

<div class="ic_ne">
<ul>
<li><a href="pphuodong.php"  class="w100"><img src="newimg/i_1.png"  alt="护肤top"></a><p>护肤top</p></li>
<a href="javascript:if(confirm('https://h5.youzan.com/v2/feature/8yivcm0h  \n\n该文件无法用 Teleport Ultra 下载, 因为 它是一个域或路径外部被设置为它的启始地址的地址。  \n\n你想在服务器上打开它?'))window.location='https://h5.youzan.com/v2/feature/8yivcm0h'" ><li style="position:relative"><a class="w100" href="javascript:if(confirm('https://h5.youzan.com/v2/feature/8yivcm0h  \n\n该文件无法用 Teleport Ultra 下载, 因为 它是一个域或路径外部被设置为它的启始地址的地址。  \n\n你想在服务器上打开它?'))window.location='https://h5.youzan.com/v2/feature/8yivcm0h'" ><img src="newimg/i_2.png"  alt="品牌活动"></a><p  style="color:#c82126">品牌活动</p>
<!--<img src="newimg/yuandan.jpg">-->
</li></a>
<!--<li><a class="w100" href="jxuan.php"><img src="newimg/i_5.png" alt="唯粉圈"></a><p>唯粉圈</p></li>-->
<li><a class="w100" href="shouhou.php" tppabs="http://m.vense.cn/shouhou.php"><img src="newimg/i_4.png"  alt="售后服务"></a><p>售后服务</p></li>
</ul>
</div>


<div class="banner_l1">
<a href="javascript:if(confirm('https://tb.53kf.com/code/client/10159345/6  \n\n该文件无法用 Teleport Ultra 下载, 因为 它是一个域或路径外部被设置为它的启始地址的地址。  \n\n你想在服务器上打开它?'))window.location='https://tb.53kf.com/code/client/10159345/6'" ><img src="pinpai/vense/images/201905211559347945.jpg" ></a>
</div>



<!--<div class="n_1 kong mar">
<div id="auto-scroll" class="wrap" style="padding:0 10px">
	<ul>
			<li><a href="findart.php?id=44">热荐：不了解肤质还谈什么护肤？</a><i class="aui-iconfont aui-icon-right"></i></li>
				<li><a href="findart.php?id=42">美妆干货：拯救眉毛大作战！</a><i class="aui-iconfont aui-icon-right"></i></li>
				
	</ul>
	
</div>

</div>-->
<!--<div class="n_2"><span>护肤老师在线</span><p>【问题肌肤】解决方案发现之旅</p></div>-->

<div class="n_3">
	<ul>
		
	<li><a href=""><img src="pinpai/vense/images/201905211619245299.jpg"  alt="VENSE美百颜乐乐护肤老师"></a></li>
		
	<li><a href=""><img src="pinpai/vense/images/201905211620183621.jpg" ></a></li>
		
	<li><a href=""><img src="pinpai/vense/images/2020032317195110061.jpg"  alt=""></a></li>
		</ul>
    <ul>
		
	<li><a href=""><img src="pinpai/vense/images/201905211620379498.jpg"  alt="美百颜抗皱冻龄罗伊老师"></a></li>
		
	<li><a href=""><img src="pinpai/vense/images/2019052116194510676.jpg"  alt="美百颜祛斑美白薇妮老师"></a></li>
		</ul>

</div>

<div class="n_4 w100 kong"><a href="javascript:void()" click-53kf><img src="newimg/index_19.gif"  alt="职业护肤导师在线分析 一对一免费分析肤质"></a></div>

<!--<div class="n_5 n"><span>品牌活动</span><p>BRAND ACTIVITIES</p></div>-->
<!--<div class="n_6">
	<ul>
		<li class="w100"><a href="product.php?id=88"><img src="http://up.yiqiaitao.com/pinpai/vense/images/2017091811505614099.jpg" alt="美百颜品牌活动"></a></li>
		</ul>
	<ul>
		<li class="w100"  ><a href=""><img src="http://up.yiqiaitao.com/pinpai/vense/images/2017091811504312335.jpg" alt="美百颜品牌活动"></a></li>
		<li class="w100"  style="margin-top:4px"  ><a href="vip.php"><img src="http://up.yiqiaitao.com/pinpai/vense/images/2017091811503017212.jpg" alt="美百颜品牌活动"></a></li>
		
	</ul>
    
</div>-->

<!--<div class="n_2 n"><span>V粉口碑评测</span><p>这些你不能错过的真实评测好物！</p></div>-->

<!--<div class="n_7">
    <ul>
	   
  
    </ul>
    <div class="w100 kong"><a href="vflist.php"><img src="newimg/vf_index.jpg"> </a></div>
    </div>-->
<!--<div class="n_4 kong w100"><a href="product.php?id=76"><img src="newimg/index_30.jpg" alt="美百颜净润舒缓卸妆液"></a></div>-->
<div class="n_2 n"><span>热销TOP榜</span><p>防晒补水不趁早，小心提前老！</p></div>

<div class="n8">

	<ul>
	    <li class="w100 fl"><a href="product.php-id=14.htm" ><img src="../mono/mono/images/201801231551266532.png" alt="美百颜玛瑞安美白祛斑霜" class="index_cp_img"></a><div class="p_x"><p>美百颜玛瑞安美白祛斑霜</p><p>直击斑源 锻造无暇美肌</p><p>￥920.00<font>129人参与评价</font></p></div></li>
	    <li class="w100 fr"><a href="product.php-id=54.htm"><img src="../mono/mono/images/2017091816514310395.png"  alt="美百颜焕肌精华液" class="index_cp_img"></a><div class="p_x"><p>美百颜焕肌精华液</p><p>水感透白 奢华成分自愈肌础</p><p>￥590<font>0人参与评价</font></p></div></li>
	    <li class="w100 fl"><a href="javascript:if(confirm('http://m.vense.cn/product.php?id=74  \n\n该文件无法用 Teleport Ultra 下载, 因为 不可用, 或放弃了下载, 或项目即将停止。  \n\n你想在服务器上打开它?'))window.location='http://m.vense.cn/product.php?id=74'" ><img src="../mono/mono/images/2018071313360210203.png" alt="美百颜燕窝胶原蛋白肽果饮" class="index_cp_img"></a><div class="p_x"><p>美百颜燕窝胶原蛋白肽果饮</p><p>每天一瓶 维稳肌肤年轻态</p><p>￥398<font>126人参与评价</font></p></div></li>
	    <li class="w100 fr"><a href="product.php-id=92.htm" ><img src="../mono/mono/images/2019112815352619149.png"  alt="美百颜莹润紧致多肽面膜" class="index_cp_img"></a><div class="p_x"><p>美百颜莹润紧致多肽面膜</p><p>时光“膜”法 绽现无龄少女肌  </p><p>￥135<font>0人参与评价</font></p></div></li>
	    </ul>
</div>
<div class="n_4 kong w100"><a href="product.php-id=54.htm" ><img src="mianmo_files/poster1.gif"  alt="美百颜去皱系列"></a></div>
<div class="n_4 kong w100"><a href="product.php-id=35.htm" ><img src="mianmo_files/poster2.gif"  alt="美百颜修复祛斑系列"></a></div>
<div class="n_4 kong w100"><a href="product.php-id=22.htm" ><img src="mianmo_files/poster3.jpg"  alt="美百颜护肤保湿系列"></a></div>

	
   
   
   
   
<?php
include_once("foot.php");
?>
    
		




<!--tanchu-->

  
 
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

   <script src="js/api.js" ></script>
   <script src="js/jquery.min.js"  type="text/javascript"></script>
   <script type="text/javascript" src="js/aui-tab.js"  ></script>
   <script type="text/javascript" src="js/jquery.cookie.js" ></script>
   <script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
  <!--   <script src="js/ZeroClipboard.js" ></script> -->
	
	



	
        <script>
            
            $('#myCarousel').carousel({
       interval:3000 , /* 设置自动轮播时间*/
        pause:'hover',/*设置暂停事件，默认就是鼠标移入轮播图就暂停，移出继续，所以可以不用写*/
        /*wrap:false*/   /*只播一次，默认true，循环一直轮播*/
    });
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<!-- <script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6"/*tpa=https://tb.53kf.com/code/code/10159345/6*/;var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>	 -->
    

    
      
	  
    <style>
    #iconDiv1,
    #mobile_ivt_div,
    #mobile_icon_div,
    #kfivtwin,
    #iconDiv2,
    #iconDiv3 {
        display: none!important;
    }
    /***隐藏53快服****/
</style>
    <script>
         window.kf_show_time = 5000;
         function show_kf(){
              setTimeout(function() {
                    var data = $('[ widget-name="kf"]').data('value');
                    rand = Math.ceil(Math.random()*data.length)-1;
                    if(is_view !=1) $('.view-show').show().addClass('animated bounceInUp');
                    if(data) $('[ widget-name="kf"]').find('[data-content]').text(data[rand].value); 
                console.log(window.kf_show_time);
                    window.kf_show_time = window.kf_show_time + 18000;
              }, window.kf_show_time);
         }
        show_kf();
</script>
 
<script>
	

	function moveTo(obj) {
		$(obj).find("ul:first").animate({
		    marginTop: "-25px"
		}, 2000, function (){
		    $(this).css({ marginTop: "0px" }).find("li:first").appendTo(this);
		});
	}
	var timer;
	$('#auto-scroll').hover(function(){
		clearInterval(timer); 
	}, function(){ 
		timer = setInterval('moveTo("#auto-scroll")', 3000) ;
	}).trigger('mouseleave'); 


var slide2 = new auiSlide({
        container:document.getElementById("aui-slide2"),
        // "width":300,
        "height":240,
        "speed":300,
        "autoPlay": 0, //自动播放
        "pageShow":true,
        "loop":true,
        "pageStyle":'dot',
        'dotPosition':'center'
    })

</script> 
</body>
</html>