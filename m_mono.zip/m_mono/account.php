<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>account</title>
	<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0">
<meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>填写订单</title>
<script type="text/javascript" src="./js/jquery2.1.js"></script>
<script type="text/javascript" src="./js/jquery.cookie.js"></script>
<script type="text/javascript" src="./js/aui-dialog.js"></script>
<link href="./css/aui.css" type="text/css" rel="stylesheet">

 <link href="orderqz/css/css1.css" type="text/css" rel="stylesheet" />
 <script type="text/javascript" src="orderqz/js/diqu.js" charset="gb2312" ></script>
 <script type="text/javascript" src="orderqz/js/jquery.params.js" charset="gb2312" ></script>
<style type="text/css">
.pay_type .huo{background: #f1b844;color: #fff;border: none;padding: 0.1em 0.3rem}
.pay_type .alipay{background: #3c98e3;color: #fff;border: none;padding: 0.1em 0.3rem}
.pay_goods ul li{text-align: center;}
.pay_goods .aui-list-item-inner span:first-child{padding: 0.1em}
.pay_goods .aui-list .aui-list-item,.pay_type .aui-list .aui-list-item{border-bottom: 1px solid #dddddd}

.pay_allcount .aui-list-item-inner{padding-top: 0.5em;padding-bottom: 0.5em}
#footer{border-top: 1px solid #ddd;}
#footer .aui-bar-tab-item:first-child .aui-bar-tab-label{color:#19258f;font-size: 0.8em}
#footer .aui-bar-tab-item:last-child{background: #8cd0de}
#footer .aui-bar-tab-item:last-child .aui-bar-tab-label{font-size: 1em;color: #fff;}
</style>
<script type="text/javascript">
	$(function(){
			var parr = Array();
			var pid='8,12,13,14,21,22,23,24';

			parr["8"] = Array("8",
				"美百颜焕肌精华液",
				  "../mono/mono/images/2017091816514310395.png",
				  "590",
				  "4ml",
				  "quzhou1.php?id=8",
				  "../mono/mono/images/2017091816514310395.png",
				  "8"
				  );

			parr["12"] = Array("12",
				"美百颜玛瑞安美白祛斑霜",
				  "../mono/mono/images/201801231551266532.png",
				  "920",
				  "20g",
				  "quban.php?id=12",
				  "../mono/mono/images/201801231551266532.png",
				  "12"
				  );

			parr["13"] = Array("13",
				"美百颜燕窝胶原蛋白肽果饮",
				  "../mono/mono/images/2018071313360210203.png",
				  "398",
				  "500ml",
				  "jiaoyuandanbai.php?id=13",
				  "../mono/mono/images/2018071313360210203.png",
				  "13"
				  );

			parr["14"] = Array("14",
				"美百颜弹润紧致修护霜",
				  "../mono/mono/images/201709181650336813.png",
				  "920",
				  "25g",
				  "quzhou.php?id=8",
				  "../mono/mono/images/201709181650336813.png",
				  "8"
				  );

			parr["21"] = Array("21",
				"美百颜莹润紧致多肽面膜",
				  "../mono/mono/images/2019112815352619149.png",
				  "135",
				  "25gX5片",
				  "bushuimask.php?id=21",
				  "../mono/mono/images/2019112815352619149.png",
				  "21"
				  );

			parr["22"] = Array("22",
				"氨基酸温和洁面乳",
				  "../mono/mono/images/201911151139436401.png",
				  "138",
				  "80g",
				  "jiemian.php?id=22",
				  "../mono/mono/images/201911151139436401.png",
				  "22"
				  );

			parr["23"] = Array("23",
				"人参护肤甘油",
				  "../mono/mono/images/201801231552237628.png",
				  "99",
				  "120ml",
				  "ganyou.php?id=23",
				  "../mono/mono/images/201801231552237628.png",
				  "23"
				  );

			parr["24"] = Array("24",
				"美百颜玻尿酸水润护肤套盒",
				  "../mono/mono/images/2019062818275717146.png",
				  "404",
				  "100ml+50ml",
				  "roufushui.php?id=24",
				  "../mono/mono/images/2019062818275717146.png",
				  "24"
				  );

			parr["26"] = Array("26",
				"舒润柔肤水（大）",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "238",
				  "300ml",
				  "product.php?id=26",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "26"
				  );

			parr["27"] = Array("27",
				"毛孔细致精华液",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "108",
				  "50ml",
				  "product.php?id=27",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "27"
				  );

			parr["28"] = Array("28",
				"美百颜黑头导出液",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "108",
				  "50ml",
				  "product.php?id=28",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "28"
				  );

			parr["29"] = Array("29",
				"美百颜黑头吸附面膜",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "80",
				  "50g",
				  "product.php?id=29",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "29"
				  );

			parr["32"] = Array("32",
				"复合益生菌固体饮料",
				  "pinpai/vense/images/20160827160102.gif",
				  "560",
				  "90g",
				  "product.php?id=32",
				  "pinpai/vense/images/20160827160102.gif",
				  "32"
				  );

			parr["35"] = Array("35",
				"美百颜舒润系列",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "510",
				  "150g+300ml+100ml+25ml*5",
				  "product.php?id=35",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "35"
				  );

			parr["39"] = Array("39",
				"智研光肌系列",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "864",
				  "30ml+30g+30ml+ 50g",
				  "product.php?id=39",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "39"
				  );

			parr["44"] = Array("44",
				"卓研晶透祛斑精华液",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "330",
				  "30ml",
				  "product.php?id=44",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "44"
				  );

			parr["45"] = Array("45",
				"肌源净澈赋活霜",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "360",
				  "50g",
				  "product.php?id=45",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "45"
				  );

			parr["46"] = Array("46",
				"美百颜肌源净澈系列",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "690",
				  "30ml+50g",
				  "product.php?id=46",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "46"
				  );

			parr["47"] = Array("47",
				"活氧冰肌水冻膜",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "178",
				  "100g",
				  "product.php?id=47",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "47"
				  );

			parr["49"] = Array("49",
				"安护鲜肌水养面膜",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=49",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "49"
				  );

			parr["50"] = Array("50",
				"安护氨基酸植萃洁面乳",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "86",
				  "80g",
				  "product.php?id=50",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "50"
				  );

			parr["51"] = Array("51",
				"安护倍润鲜肌水",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "138",
				  "100ml",
				  "product.php?id=51",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "51"
				  );

			parr["52"] = Array("52",
				"美百颜安护植润滋养霜",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "260",
				  "30g",
				  "product.php?id=52",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "52"
				  );

			parr["53"] = Array("53",
				"安护倍润修护乳",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "198",
				  "45g",
				  "product.php?id=53",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "53"
				  );

			parr["54"] = Array("54",
				"美百颜安护植润系列",
				  "pinpai/vense/images/202003230943113170.png",
				  "810",
				  "5件套",
				  "product.php?id=54",
				  "pinpai/vense/images/202003230943113170.png",
				  "54"
				  );

			parr["56"] = Array("56",
				"肌妍新生美眼霜",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "280",
				  "15g",
				  "product.php?id=56",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "56"
				  );

			parr["57"] = Array("57",
				"肌妍新生滋养霜",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "360",
				  "50g",
				  "product.php?id=57",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "57"
				  );

			parr["58"] = Array("58",
				"肌妍新生系列",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "960",
				  "精华液30ml+滋养霜50g+眼霜15g",
				  "product.php?id=58",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "58"
				  );

			parr["59"] = Array("59",
				"肌妍新生精华液",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "320",
				  "30ml",
				  "product.php?id=59",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "59"
				  );

			parr["60"] = Array("60",
				"琉晶莹彩唇膏",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "189",
				  "3.8g",
				  "product.php?id=60",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "60"
				  );

			parr["61"] = Array("61",
				"炫黑纤长修护睫毛膏",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "126",
				  "7ml",
				  "product.php?id=61",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "61"
				  );

			parr["62"] = Array("62",
				"精致塑形眉彩笔",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "98",
				  "0.24g",
				  "product.php?id=62",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "62"
				  );

			parr["63"] = Array("63",
				"炫黑速干眼线液笔",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "108",
				  "0.5ml",
				  "product.php?id=63",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "63"
				  );

			parr["64"] = Array("64",
				"智研光肌精华液",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "218",
				  "30ml",
				  "product.php?id=64",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "64"
				  );

			parr["65"] = Array("65",
				"智研光肌霜",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "260",
				  "50g",
				  "product.php?id=65",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "65"
				  );

			parr["66"] = Array("66",
				"美百颜彩妆系列",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "521",
				  "唇膏3.8g 睫毛膏7ml 眼线液笔0.5ml 眉彩笔0.2",
				  "product.php?id=66",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "66"
				  );

			parr["68"] = Array("68",
				"炫黑浓翘修护睫毛膏",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "126",
				  "7ml",
				  "product.php?id=68",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "68"
				  );

			parr["69"] = Array("69",
				"凝光沁亮肌活霜",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "360",
				  "50g",
				  "product.php?id=69",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "69"
				  );

			parr["70"] = Array("70",
				"凝光沁亮肌活精华液",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "330",
				  "50ml",
				  "product.php?id=70",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "70"
				  );

			parr["71"] = Array("71",
				"凝光沁亮系列",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "690",
				  "50ml、50g",
				  "product.php?id=71",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "71"
				  );

			parr["72"] = Array("72",
				"智研光肌祛痘膏",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "168",
				  "30g",
				  "product.php?id=72",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "72"
				  );

			parr["73"] = Array("73",
				"智研光肌祛痘精华液",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "218",
				  "30ml",
				  "product.php?id=73",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "73"
				  );

			parr["74"] = Array("74",
				"聚能修护精华液",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "420",
				  "0.35ml*15粒",
				  "product.php?id=74",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "74"
				  );

			parr["75"] = Array("75",
				"梦幻柔光气垫BB霜送替换装",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "188",
				  "13g*2",
				  "product.php?id=75",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "75"
				  );

			parr["76"] = Array("76",
				"净润舒缓卸妆液",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "168",
				  "200ml",
				  "product.php?id=76",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "76"
				  );

			parr["77"] = Array("77",
				"凝光沁亮修颜霜",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "168",
				  "37ml",
				  "product.php?id=77",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "77"
				  );

			parr["84"] = Array("84",
				"户外隔离防护霜",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "128",
				  "50g",
				  "product.php?id=84",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "84"
				  );

			parr["88"] = Array("88",
				"臻妍纯皙-焕能活颜面膜",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "288",
				  "25ml/片*5",
				  "product.php?id=88",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "88"
				  );

			parr["89"] = Array("89",
				"臻妍纯皙-密活亮采面膜",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=89",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "89"
				  );

			parr["90"] = Array("90",
				"臻妍纯皙-冰肌盈耀面膜",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=90",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "90"
				  );

			parr["92"] = Array("92",
				"鱼胶原蛋白肽粉30支装",
				  "pinpai/vense/images/2017102412232311313.png",
				  "1680",
				  "150克（5克X 30瓶）",
				  "product.php?id=92",
				  "pinpai/vense/images/2017102412232311313.png",
				  "92"
				  );

			parr["93"] = Array("93",
				"鱼胶原蛋白肽粉10支装",
				  "pinpai/vense/images/201711061800143549.png",
				  "580",
				  "50克（5克X 10瓶）",
				  "product.php?id=93",
				  "pinpai/vense/images/201711061800143549.png",
				  "93"
				  );

			parr["94"] = Array("94",
				"植物源性花青素固体饮料",
				  "pinpai/vense/images/201906281827576188.png",
				  "580",
				  "2克*20袋",
				  "product.php?id=94",
				  "pinpai/vense/images/201906281827576188.png",
				  "94"
				  );

			parr["95"] = Array("95",
				"蔓越莓维生素C固体饮料",
				  "pinpai/vense/images/2017112709114214835.png",
				  "298",
				  "3g*30袋/盒",
				  "product.php?id=95",
				  "pinpai/vense/images/2017112709114214835.png",
				  "95"
				  );

			parr["96"] = Array("96",
				"青果肌滢润洁面乳",
				  "pinpai/vense/images/2017113018050315284.png",
				  "79",
				  "120g",
				  "product.php?id=96",
				  "pinpai/vense/images/2017113018050315284.png",
				  "96"
				  );

			parr["97"] = Array("97",
				"青果肌滢润精粹水",
				  "pinpai/vense/images/2017113017551118264.png",
				  "109",
				  "150ml",
				  "product.php?id=97",
				  "pinpai/vense/images/2017113017551118264.png",
				  "97"
				  );

			parr["98"] = Array("98",
				"青果肌滢润保湿乳",
				  "pinpai/vense/images/201711301817469051.png",
				  "119",
				  "100ml",
				  "product.php?id=98",
				  "pinpai/vense/images/201711301817469051.png",
				  "98"
				  );

			parr["99"] = Array("99",
				"青果肌滢润补水面膜",
				  "pinpai/vense/images/201711301833591400.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=99",
				  "pinpai/vense/images/201711301833591400.png",
				  "99"
				  );

			parr["100"] = Array("100",
				"青果肌净爽控油面膜",
				  "pinpai/vense/images/2017113018393711530.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=100",
				  "pinpai/vense/images/2017113018393711530.png",
				  "100"
				  );

			parr["102"] = Array("102",
				"鲜肌酵母精华水",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "218",
				  "120ml",
				  "product.php?id=102",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "102"
				  );

			parr["103"] = Array("103",
				"美百颜净润卸妆乳",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "168",
				  "120g",
				  "product.php?id=103",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "103"
				  );

			parr["105"] = Array("105",
				"晶彩胶原寡肽眼膜",
				  "pinpai/vense/images/201905071131456858.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=105",
				  "pinpai/vense/images/201905071131456858.png",
				  "105"
				  );

			parr["106"] = Array("106",
				"美百颜角鲨烷舒缓鲜肌喷雾",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "128",
				  "150ml",
				  "product.php?id=106",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "106"
				  );

			parr["108"] = Array("108",
				"晶彩松露胜肽眼膜",
				  "pinpai/vense/images/2019092917513914239.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=108",
				  "pinpai/vense/images/2019092917513914239.png",
				  "108"
				  );

			parr["109"] = Array("109",
				"VENSE美百颜 美百颜卓研晶透系列",
				  "pinpai/vense/images/201909301115234803.png",
				  "690",
				  "30ml+50g",
				  "product.php?id=109",
				  "pinpai/vense/images/201909301115234803.png",
				  "109"
				  );

			parr["110"] = Array("110",
				"保加利亚玫瑰花水面膜",
				  "pinpai/vense/images/201910291820001217.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=110",
				  "pinpai/vense/images/201910291820001217.png",
				  "110"
				  );

			parr["111"] = Array("111",
				"四重玻尿酸水库面膜",
				  "pinpai/vense/images/2019102918243214736.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=111",
				  "pinpai/vense/images/2019102918243214736.png",
				  "111"
				  );

			parr["112"] = Array("112",
				"城市霓虹丝悦唇膏口红",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "99",
				  "3.4g",
				  "product.php?id=112",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "112"
				  );

			parr["113"] = Array("113",
				"卓研晶透祛斑滋养霜",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "360",
				  "50g",
				  "product.php?id=113",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "113"
				  );

			parr["114"] = Array("114",
				"美百颜安护植润鲜肌水",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "138",
				  "100ml",
				  "product.php?id=114",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "114"
				  );

			parr["115"] = Array("115",
				"美百颜安护植润修护乳",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "198",
				  "45g",
				  "product.php?id=115",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "115"
				  );

			parr["116"] = Array("116",
				"美百颜安护鲜肌水养植萃面膜",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=116",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "116"
				  );

			parr["117"] = Array("117",
				"美百颜清透亮采防晒霜",
				  "pinpai/vense/images/202003271311538925.png",
				  "128",
				  "50g",
				  "product.php?id=117",
				  "pinpai/vense/images/202003271311538925.png",
				  "117"
				  );

			parr["118"] = Array("118",
				"美百颜净润舒缓卸妆液 养肤级卸妆",
				  "pinpai/vense/images/202003301121288441.png",
				  "168",
				  "200ml",
				  "product.php?id=118",
				  "pinpai/vense/images/202003301121288441.png",
				  "118"
				  );


		var cur_cart = JSON.parse($.cookie("cart"));
		var dialog = new auiDialog();
		var sub_product='';
		var pid_array=pid.split(',');
		show_cart(cur_cart);
		//sub_product += "订单金额: "+dgprice+"元 不满300元，需付邮费10元（实付金额）"+(dgprice+10)+"元";
		//sub_product += "（实付金额）"+dgprice+"元";


		
		function show_cart(obj){
			
			if(obj){
				$("#order_list").html("");
				
				var pstring='';
				var yunfei='0.00';
				var count=0;
				
				for(var i in obj){
					if($.inArray(obj[i]['pId'],pid_array)!=-1){
						count+=parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]);
						if(count>=300){
										yunfei='0.00';
							}else{
								yunfei='10.00';
							}
						sub_product += parr[obj[i]["pId"]][1]+"["+obj[i]["proS"]+"X"+parr[obj[i]["pId"]][3]+"]="+(parseInt(obj[i]["proS"])*parseFloat(parr[obj[i]["pId"]][3]))+"元 ";	
						pstring=pstring+'<li class="aui-list-item"><div class="aui-list-item-inner"><span style="width: 15%"><img src="'+parr[obj[i]["pId"]][6]+'"  style="width:75%; margin:0 auto"></span><span style="width: 45%; font-size:13px;    display: inherit" class="name"><input name="productname" style="display:none;" value="'+parr[obj[i]["pId"]][1]+'">'+parr[obj[i]["pId"]][1]+'</span><span style="width: 10%">x<input type="text" name="productnum" style="display:none;" value="'+parseInt(obj[i]["proS"])+'">'+parseInt(obj[i]["proS"])+'</span><span style="width: 20%">'+( parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]))+'元</span></div><input name="productcount" type="text" style="display:none;" value="'+( (parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]))+parseFloat(yunfei))+'"></li>';
						
					}
					
				}
				$("#order_list").html(pstring);
				$('#count').html(count);
				$("#productname").val(parr[obj[i]["pId"]][1]);
				$("#productnum").val(parseInt(obj[i]["proS"]));
				$("#productcount").val(count+parseFloat(yunfei));
				
				 var yunfei='10.00';
				if(count>300){
					yunfei='0.00';
					$('#proselect').val(sub_product+"（实付金额）"+parseFloat(count)+"元");
				}else{
					$('#proselect').val(sub_product+"订单金额: "+parseFloat(count)+"元 不满300元，需付邮费10元（实付金额）"+((parseFloat(count)+parseFloat(yunfei)))+"元");
				}
				$('#yunfei').html(yunfei);
				$('#pay_count').html((parseFloat(count)+parseFloat(yunfei)));
			}
		}
	// $('#submit').click(function(){
	// 	submit();
	// });
	function delcart(obj){
		for(var i in obj){
			if($.inArray(obj[i]['pId'],pid_array)!=-1){
				obj.splice(i,1);
			}
		}
		$.cookie("cart",JSON.stringify(obj));
	}
	function submit(){
		$("#site_referer").val(window.location.href);
		$("#extend_referer").val(document.referrer);
		var url='';
		var _j=false;
		$('#myform input').each(function(){
			if($(this).val().length==0){
				_j=true;
				return false;
			}
		});
		if(_j){
			dialog.alert({
					title:"温馨提示",
					msg:'收货地址信息不全',
					buttons:['确定']
				},function(ret){
					
				})
				return false;
		}
		
		if($('[name="pay_type"]:checked').val()==1){
			$('[name="content[4]"]').val('支付宝');
			url='http://order.yiqiaitao.com/order/create_order.php';
		}else{
			$('[name="content[4]"]').val('货到付款(安心有保障)');
			url='http://order.yiqiaitao.com/index.php?action=savecontent&ph=2';	
		}
		$('#myform').attr('action',url);
		//move cart
		delcart(cur_cart);
		$('#myform').submit();
		/*
		$.post(url,$('#myform').serialize(),function(back){
			if($('[name="content[4]"]').val()==1){
				window.location.href="pay.php";
			}else{
				window.location.href="pay.php";
			}
			
		},'html');*/
		
	}
	$('#huo').click(function(){
		$('#myform').removeAttr('target');
	});
	$('#zhi').click(function(){
		$('#myform').attr('target','_blank');
	});
	});
		</script>
</head>
<body>

<div class="aui-content aui-margin-b-15 cart_address">
<form id="wfform" name="wfform" method="post" action="orderqz/data/index.php" onsubmit="return postcheck()" enctype="multipart/form-data" target="_parent" >
    <ul class="aui-list aui-form-list">
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    收货人姓名:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="dgname" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    手机号码:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="mob" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    所在地区:
                </div>
                <div class="aui-list-item-input ">
                     <span class="bdr "><select name="province" onchange="diqu()"  class="selectb fontsm"></select><select name="city" onchange="diqu()" class="selectb fontsm"></select><select name="area" onchange="diqu()" class="selectb fontsm"></select></span>
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    详细地址:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="address" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                   备注说明:
                </div>
                <div class="aui-list-item-input">
                    <input  type="text" name="beizhu" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    验证码:
                </div>
                <div class="aui-list-item-input fontsm">
                    <span class="bdr"><input type="text" name="usercode" class="txt txt2" /><img src="orderqz/data/wfcode.php" alt="看不清，请点击刷新" title="看不清，请点击刷新" onClick="this.src=this.src+'?'" /></span>
                </div>
            </div>
        </li>
         <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    支付方式:
                </div>
                <div class="aui-list-item-input" style="padding-right: 0;">
                     <span class="bdr">
                          <div class="payaa">
                              <input type="radio" checked="checked" name="paytype" id="paytypea" value="货到付款" onclick="opay(); return changeItem(0);" class="dxk" /> <label for="paytypea">货到付款</label>
                                <input type="radio" name="paytype" id="paytypec" value="银行汇款" onclick="opay();return changeItem(2);" class="dxk" /><label for="paytypec">其它方式</label>
                            </div>
                            
                            <div id="paydiv0" class="paybb kda">
                              <p>温馨提示：货物送到开箱验货，确认商品无误后再付款！</p>
                              <p>有任何疑问请咨询我们的客服</p>
                            </div>
                            <div id="paydiv1" class="paybb kda" style="display:none;">          
				                <p>温馨提示：支付宝付款可享受8折优惠哦！</p>
				                <p>全球领先的第三方支付平台，在线支付，安全可靠！</p>              
                            </div>
			              <div id="paydiv2" class="paybb kda" style="display:none;">
			                <p>其它付款方式：</p>
			                <p>银行汇款、微信支付、支付宝支付等请联系我们的客服！</p>
			              </div>
                    </span>
                </div>
            </div>
        </li>

        </ul>
		<input type="hidden" name="content[4]" value="支付宝">
		<input type="hidden" value="69" name="fid">
		<input type="hidden" name="content[0]" id="proselect" value="舒润滋养面膜[1X128]=128元 舒润洁面乳[1X86]=86元 订单金额: 214元 不满300元，需付邮费10元（实付金额）224元">
		<input type="hidden" name="extend_referer" id="extend_referer" value="">
         <input type="hidden" name="site_referer" id="site_referer" value="">
		<!-- form -->

</div>

<!-- <div class="aui-content aui-margin-b-15 pay_type">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-label-icon">
                   <button type="button" class="huo" value="货">货</button>
                </div>
                <div class="aui-list-item-inner">
                    货到付款<span>安心有保障</span><input type="radio" name="paytype" id="huo" value="货到付款" class="aui-radio">
                </div>
            </li>
             <li class="aui-list-item">
                <div class="aui-list-item-label-icon">
                   <button type="button" class="alipay" value="支">支</button>
                </div>
                <div class="aui-list-item-inner">
                    支付宝&nbsp;&nbsp;&nbsp;<span>安心有保障</span><input type="radio" id="zhi" class="aui-radio" name="paytype" checked="" value="支付宝">
                </div>

            </li>
        </ul>
    </div> -->
    <div class="aui-content aui-margin-b-15 pay_type">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-inner">
                    快递配送 (满300元免运费)
                </div>
            </li>
        </ul>
    </div>
    
    <div class="aui-content aui-margin-b-15 pay_goods">
        <ul class="aui-list aui-list-in" id="order_list"><li class="aui-list-item"><div class="aui-list-item-inner"><span style="width: 15%"><img src="./account_files/201709150940027584.jpg" style="width:75%; margin:0 auto"></span><span style="width: 45%; font-size:13px;    display: inherit">舒润滋养面膜</span><span style="width: 10%">x1</span><span style="width: 20%">128元</span></div></li><li class="aui-list-item"><div class="aui-list-item-inner"><span style="width: 15%"><img src="./account_files/201709150939217135.jpg" style="width:75%; margin:0 auto"></span><span style="width: 45%; font-size:13px;    display: inherit">舒润洁面乳</span><span style="width: 10%">x1</span><span style="width: 20%">86元</span></div></li></ul>
    </div>
    <div class="aui-content aui-margin-b-15 pay_allcount">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-inner">
                  <ul><li>商品价格:<span id="count">214</span>元</li><li>配送费用：<span id="yunfei">10.00</span>元</li></ul>
                  
                </div>
            </li>
        </ul>
    </div>
    <div style="height: 2.5em;margin-bottom: 0.75em">
    </div>
    <footer class="aui-bar aui-bar-tab" id="footer">
    <div class="aui-bar-tab-item aui-active" tapmode="">
        <div class="aui-bar-tab-label">实付金额:<span id="pay_count" >224</span>元</div>
    </div>
    <div style="display: none;">
    	<input type="text" name="productname" id="productname">
    	<input type="text" name="productnum" id="productnum">
    	<input type="text" name="productcount" id="productcount">
    </div>
    <div class="aui-bar-tab-item" tapmode="">
        <a class="aui-bar-tab-label" id="submit" ><input type="submit" name="submit" value="提交" class="obtn" style="background: transparent;color: #fff; "></a>

    </div>
    </footer>
    </form>
	

		<script type="text/javascript">
  function postcheck(){
    if(document.wfform.dgname.value==""){
      alert('请填写姓名！');
      document.wfform.dgname.focus();
      return false;
    }
    var reg1=/^[\u4e00-\u9fa5]{2,4}$/;
    if(!reg1.test(document.wfform.dgname.value)){
      alert('姓名格式不正确，请填写真实姓名！');
      document.wfform.dgname.focus();
      return false;
    }
    if(document.wfform.mob.value==""){
      alert('请填写手机号码！');
      document.wfform.mob.focus();
      return false;
    }
    var reg2= /^1[3,4,5,8]\d{9}$/;
    if(!reg2.test(document.wfform.mob.value)){
      alert('手机号码格式不正确。请填写正确的手机号码！');
      document.wfform.mob.focus();
      return false;
    }
    if(document.wfform.province.value==""){
      alert('请选择所在的地区！');
      document.wfform.province.focus();
      return false;
    }
    if(document.wfform.address.value==""){
      alert('请填写详细的地址！');
      document.wfform.address.focus();
      return false;
    }
    if(document.wfform.usercode.value==""||document.wfform.usercode.value.length<4){
      alert('请填写验证码！');
      document.wfform.usercode.focus();
      return false;
    }
    document.wfform.wfsubmit.disabled=ture;
    document.wfform.wfsubmit.style.backgroundImage="url(orderqz/images/sub2.gif)";
    return true;
    }
</script>
<script type="text/javascript" src="orderqz/js/subxl.js"></script>


</body>
</html>