var is_view = 0;
var clickNoCount = 0;
var system =
{
	win : false,
	mac : false,
	xll : false
};
var p = navigator.platform;
system.win = p.indexOf("Win") == 0;
system.mac = p.indexOf("Mac") == 0;
system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);
if(system.win || system.mac || system.xll){
	$(document).ready(function(){
		$('.box-element-close').remove();
	})
}else{
	//window.location.href = "#initialize_point";
}

$('#loading').remove();
window.onload = function() {
	$('#loading').remove();
}
setTimeout(function() {
	$('#loading').remove();
}, 1000);

var close_kf = 0;

$(document).ready(function(){
	if($('.get_province').length > 0 || $('.get_city').length > 0){
		$.ajax({
			type: "get",
			url: "http://api.sdbairun.com/api/ip/get.json",
			dataType: 'jsonp', 
			jsonp:'callback',
			success: function (res, msg) { 
				$('.get_province').text(res.province);
				$('.get_city').text(res.city);
			}
		})
	}
});