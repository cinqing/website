var extend_url = window.parent.document.referrer;
var site_referer_url = window.parent.location.href;
extend_url = decodeURI(extend_url);
if(extend_url.indexOf("../nopage.html")>0&&extend_url.indexOf("wd=")>0){
	var keyword_str = extend_url.split("wd=")[1];
	if(keyword_str.indexOf("&")>0){
		keyword_str = keyword_str.split("&")[0];
	}
	var keyword = keyword_str;
	extend_url = "Baidu("+keyword+")";
}
