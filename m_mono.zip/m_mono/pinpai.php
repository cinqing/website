<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>pinpai品牌故事</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="美百颜官网品牌故事频道给大家讲述美百颜产品从哪里来、美百颜产品介绍，让用户更加了解美百颜。" />
<meta name="keywords" content="美百颜产品从哪里来、美百颜产品介绍"/>
<title>美百颜产品从哪里来_美百颜产品介绍_品牌故事_美百颜官网</title>
<link rel="stylesheet" type="text/css" href="dist/css/css.css" >
<link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<script src="dist/js/zepto.min.js" ></script>
<script src="dist/js/main.js" ></script>
<script src="dist/js/tool.js" ></script>
<script src="dist/js/swipe.js" ></script>
</head>
<body>
<!--header-->
<div class="main">

<?php
include_once("top.php");
?>
    

 
<div class="art">
  <div class="con">
  	<p>
	<img src="pinpai/vense/images/2019022018545053170.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545083583.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545031033.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545122771.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545149449.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545113142.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545149976.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545164645.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545132126.jpg"  alt="" />
    <img src="pinpai/vense/images/2019022018545171570.jpg"  alt="" /> 
</p>  </div>
</div>

    <script>var cart_display = "none";</script>
	
  
   
   
   
   
    
		
<?php
include_once("foot.php");
?>


<!--tanchu-->

  
 


        <script src="js/api.js" ></script>
		<script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js"  ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js"></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<!-- <script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>	 -->


</body>
</html>