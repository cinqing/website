<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>美百颜焕肌精华液</title>
	
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">	
<title>美百颜焕肌精华液效果怎么样、多少钱、哪里有卖__美百颜官方网站</title>
<meta name="keywords" content="美百颜焕肌精华液密集补水，密集滋养,要想知道效果怎么样，多少钱，哪里有卖请点击美百颜官网">
<meta name="description" content="美百颜焕肌精华液怎么样、美百颜焕肌精华液多少钱">
<link rel="Shortcut Icon" href="../mono/image/ico.ico">
<link rel="stylesheet" type="text/css" href="./mianmo_files/css.css">
<link rel="stylesheet" href="./mianmo_files/aui.css">
<link rel="stylesheet" type="text/css" href="./css/style.css">
<script src="./mianmo_files/zepto.min.js"></script>
<script src="./mianmo_files/main.js"></script>
<script src="./mianmo_files/tool.js"></script>
<script src="./mianmo_files/swipe.js"></script>
<script src="./mianmo_files/share.js"></script>
<link rel="stylesheet" href="./mianmo_files/share_style1_32.css">
<!-- Bootstrap -->
<link href="css/bootstrap.min.css"  rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
</head>
</head>
<body>
<!--header-->
<div class="main">

<!--banner-->
   <div class="ui-banner">
   <div class="pro_new_t"><li><a href="javascript:void(0)" onclick="javascript:history.go(-1)"><img src="./mianmo_files/back.png"></a></li><li><!-- <a href="javascript:void()" class="fx_v"><img src="./mianmo_files/fx.png"></a> --></li></div>
    <div id="slider" class="swipe" style="visibility: visible;">
		<ul class="swipe-wrap" style="width: 3200px;">
            <li data-index="0" style="width: 640px; left: 0px; transition-duration: 300ms; transform: translate(0px, 0px) translateZ(0px);"><a href="javascript:;"><img src="../mono/mono/images/21.jpg"></a></li><li data-index="1" style="width: 640px; left: -640px; transition-duration: 0ms; transform: translate(640px, 0px) translateZ(0px);"><a href="javascript:;"><img src="../mono/mono/images/22.jpg"></a></li><li data-index="2" style="width: 640px; left: -1280px; transition-duration: 300ms; transform: translate(-640px, 0px) translateZ(0px);"><a href="javascript:;"><img src="../mono/mono/images/20"></a></li>       
  	</ul>
      <div id="slider_on">
          <ul>
		   <li class="on"></li> <li class=""></li> <li class=""></li>    
         </ul>
      </div>
  </div>
  </div>
  <script>  window.$$=window.Zepto = Zepto;   $$(function(){        $$('#slider').mBanner('slider');    });</script>
  <script type="text/javascript" src="./mianmo_files/jquery.js"></script>
  <script type="text/javascript" src="./mianmo_files/jquery.cookie.js"></script>
  <script type="text/javascript" src="./mianmo_files/cart.php"></script>
<div class="product_text">
<p class="info">美百颜焕肌精华液<!-- <span>(25ML*5片)</span> --><font>手机专享</font></p>
<!-- <p class="n_p_j">密集补水，密集滋养</p> -->
<p class="n_p_s">水感透白 奢华成分自愈肌础</p>
<p class="price">￥590<!-- <font>品牌指导价：￥920</font> --></p>

</div>
<!-- <div class="pir">
	<img src="./mianmo_files/cp_n.jpg">
</div> -->
<!-- <div class="n_p_pc"><a href="http://m.vense.cn/vshow.php?id=16">查看评测报告</a></div> -->
<!-- <ul class="aui-list aui-list-in aui-list-noborder ">
<a href="http://m.vense.cn/allpingjia.php?code=55NX2LD684"><li class="aui-list-item n_p_pj">
                <div class="aui-list-item-inner aui-list-item-arrow">
                    用户评价(129)
                    <div class="aui-list-item-right">
                        <div style="position:relative;top:0; right:0">98.0% 满意</div>
                    </div>
                </div>
            </li>
</a>
</ul> -->
<!-- <div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                        会员<br>像***风                        
                    </div>
                    <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud"></i> 397</div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                刚买这个面膜时觉得有点贵，但敷了之后才发现贵有贵的道理，质地柔软，精华也多，敷着好舒服的，坚持敷了一盒，老公都夸我肌肤水润了                <ul class="n_pl_img">
				                <li><img src="http://m.vense.cn/product.php?id=14"></li>
				                </ul>
            </div>
            <div class="findart_sj">2018-08-21</div>
           
        </div> -->
	



<div class="droplist1">
	<a class="btn active" style="font-size: 1.2rem;">商品详情</a>
	<!-- <a class="btn" href="http://m.vense.cn/allpingjia.php?code=55NX2LD684">用户评价</a> -->
</div>
<div class="art" style="padding:0" id="con">
	<div class="con" style="border:none;">
		<p>
  <img src="../mono/mono/images/23.jpg" alt="" /><img src="../mono/mono/images/24.jpg" alt="" /><img src="../mono/mono/images/25.png" alt="" /><img src="../mono/mono/images/26.jpg" alt="" /><img src="../mono/mono/images/27.jpg" alt="" /><img src="../mono/mono/images/28.jpg" alt="" /><img src="../mono/mono/images/29.jpg" alt="" /><img src="../mono/mono/images/30.jpg" alt="" />
</p>  </div>
	
</div>

<?php
include_once("footer.php");
?>
	
  <!--  <div class="qrcode" style="position:relative">
    <p><img src="./mianmo_files/qrcode.jpg"></p>
    <div style="position:absolute; z-index:10; bottom:4.3em; left:58%;">
    	<span style="background:#553097;color:#fff; padding:0 1em;">weienshihufu</span>
    </div>
  </div> -->
   
   
   <!-- <div class="footnew">
   <div class="w100"><img src="./mianmo_files/footnew_01.jpg"></div>
   <div class="w100"><img src="./mianmo_files/sss.jpg">
   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-top:1em">美百颜护肤导师在线：020-83620466</p>
   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem">地址：山东济南高新技术开发区 汉峪金谷互联网大厦</p>
   <p class="foot_p" style=" text-align:center; font-size:0.6rem; line-height:1.2rem; padding-bottom:1em">2020 美百颜官网 www.monobeau.com 版权所有</p>
   </div>
   </div> -->
   
   
  <!--   <footer class="aui-bar aui-bar-tab aui-border-t" id="footer">
            <div class="aui-bar-tab-item" tapmode="">
                <i class="aui-iconfont aui-icon-home"></i>
                <div class="aui-bar-tab-label"><a href="index.php">首页</a></div>
            </div>
            <div class="aui-bar-tab-item" tapmode=""><a href="listn.php">
                <i class="aui-iconfont aui-iconfont aui-icon-menu"></i>
                <div class="aui-bar-tab-label">分类</div></a>
            </div>
            <div class="aui-bar-tab-item" tapmode="" style="text-align: center">
            <a href="pinpai.php">
                   <div class="aui-badge">...</div>
                    <img src="./mianmo_files/i_3.png" width="25" style="margin: 0 auto; display: inline; position: relative;top:3px"> 
                    <div class="aui-bar-tab-label" style="margin-top: -2px">关于</div>
                    </a>
                </div>
                
            <div class="aui-bar-tab-item" tapmode="">
			<a href="dinggou.php">
                <div class="aui-badge cart_count">1</div>
                <i class="aui-iconfont aui-icon-cart"></i>
                <div class="aui-bar-tab-label">购物车</div>
				</a>
            </div>
            <div class="aui-bar-tab-item" tapmode="">
			<a href="http://m.vense.cn/dinggou.php?go=cart">
                <div class="aui-dot"></div>
                <i class="aui-iconfont aui-icon-my"></i>
                <div class="aui-bar-tab-label">我的</div>
				</a>
            </div>
    </footer> -->
		
<!-- <div class="fx_main">
<div class="fx_vm">
<div class="fenxiang bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1587793096441">
               
					<a href="http://m.vense.cn/product.php?id=14#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                </div>
<span class="fx_close">取消</span>
</div>
</div> -->



<!--tanchu-->

  
 


         <script src="./mianmo_files/api.js"></script>
		 <script src="./mianmo_files/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="./mianmo_files/aui-tab.js"></script>
	<script type="text/javascript" src="./mianmo_files/jquery.cookie.js"></script>
<script type="text/javascript" src="./mianmo_files/aui-dialog.js"></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="./mianmo_files/ZeroClipboard.js"></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	
<a data-click="悬浮顶部" class="scroll-top" href="javascript:scrollTo(0,0);" style="display: none;"></a></div>

<script>
	$(function(){
		$('.droplist1 .btn').click(function(){
			$('.droplist1 .btn').removeClass('active');
			$('.art .con').hide();
			$(this).addClass('active');
			var l = $('.droplist1 .btn').index($(this));
			$('.art .con').eq(l).show();
			window.location.href="#con";
		})
	})
	
	 		
			
</script>



 <footer class="aui-bar aui-bar-tab aui-margin-t-15">
 
        <div class="aui-bar-tab-item aui-border-r mask" tapmode="" style="width: 3rem;">
		<a href="javascript:void(0)">
            <i class="fa fa-commenting-o "></i>
            <div class="aui-bar-tab-label ">在线咨询</div>
			</a>
        </div>
        <div class="aui-bar-tab-item" tapmode="" style="width: 3rem;">
		<a href="tel:4006679930">
            <i class="fa fa-phone"></i>
            <div class="aui-bar-tab-label ">订购电话</div>
		</a>
        </div>
        <div class="aui-bar-tab-item aui-bg-danger aui-text-white" tapmode="" style="width: auto;"><a href="dinggou.php?go=cart" onclick="ptocart(&#39;8&#39;,&#39;590&#39;)" class="buybtn">官方商城购买</a></div>
    </footer>
	
	<!-- <div class="fx_main">
<div class="fx_vm">
<div class="fenxiang bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1587793096441">
               
                 <a href="http://m.vense.cn/product.php?id=14#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
                    <a href="http://m.vense.cn/product.php?id=14#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                </div>
<span class="fx_close">取消</span>
</div>
</div> -->
	
<!-- 	<script>
	  $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 	
	
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>
 -->
  
    <script src="./mianmo_files/ZeroClipboard.js"></script>

<style>.cart-div{display:none;}</style>
<script>
var drop = $('.droplist1').offset().top
window.onscroll = function () {
				if ($(document).scrollTop() >  (drop/2-80)) {
					$(".droplist1").addClass('abx');
				}
				else {
					$(".droplist1").removeClass('abx');
				}
			}


</script>
<!-- <div id="maskWebChat" style="display: none;">
	<div id="mask">
		<p id="txtWebChat">vnshufu</p>
		<p id="txt_tips">请长按复制微信号<br>进行关注咨询</p>
		<a id="closeWebChat">X</a>
	</div>
</div>
<script>
$('#wxid').click(function(){
	if($('#maskWebChat').css('display')=='none'){
		$('#maskWebChat').css('display','block');
	}
})
$('#closeWebChat').click(function(){
	
		$('#maskWebChat').css('display','none');

})
</script> -->



<div class="cart-div"></div>

<!-- 弹出在线咨询 -->
<div class="tcmack" style="display: none;">
		<div class="neitc">
		   <a href="javascript:void(0);"  class="mackclose">
		   <img src="images/tclose.png" ></a><img src="images/tanchuew.png" >
	    </div>
  </div>
  <script>
   	$(".mask").click(function(){
                $(".tcmack").fadeIn(400);
                $(".tcmack").css('display','block'); 

            });

            $(".mackclose").click(function(){
                $(".tcmack").fadeOut(400);
            }); 	
   </script>

</body>
</html>