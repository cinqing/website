<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>allpingjia所有评论</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<script type="text/javascript" src="js/jquery.min.js" ></script>
	<script type="text/javascript" src="js/toastr.js" ></script>
    <link rel="stylesheet" href="css/aui.css" >
     <link rel="stylesheet" href="dist/css/style.css" >
    
    <title>评论列表</title>
    <style>
	       .allpingjia_cp {
            position: static;
        }
        .search-input {
            height: 1.6rem !important;
            line-height: 1.6rem;
            background: #f5f5f5;
            border-radius: 30px;
            position: relative;
            font-family:"aui_iconfont" !important;
            text-align: left;
            padding-left: 1.5rem;
            color: #999999;
        }
        .search-input:after {
            position: absolute;
            left: 0;
            padding-left: 0.5rem;
            content: "\e615";
			top:-2%
        }
		.tosubmit{ position:absolute; top:0; right:20px; color:#595959}
		.aui-input, input[type="search"]{ font-size:0.7rem}
	</style>
</head>
<body>

<div class="main" >

 <header class="aui-bar-nav cp_n">
        <a class="aui-pull-left aui-btn aui-btn-outlined " href="javascript:void(0)" onclick="javascript:history.go(-1)">
           <span class="aui-iconfont aui-icon-left" style="color:#fff"></span>
        </a>
        <div class="aui-title">商品评价</div>
        
        <a class="aui-pull-right aui-btn aui-btn-outlined fx_v" href="javascript:void()">
            <span class="aui-iconfont aui-icon-more" style="color:#fff"></span>
        </a>
        <div class="n_cp_du">98%满意</div>
  </header>


<div class="findart_bt">最有帮助的评论</div>
<div class="allpinglun">
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>清***柔                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7767','1')"  ></i> <span id='click_number_num'>191</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                物流很快，前天买的，今天就到了。打开包装，产品的颜色就很清新，一看就有一种清爽感，效果应该不错。                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-08-06</div>
            			<div style="background:#f5f5f5"> </div>
			 <!--  <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7767"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>天***眼                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7766','1')"  ></i> <span id='click_number_num'>362</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                保湿效果非常好，用完没有紧绷感，用完，脸上滑滑的感觉。                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-08-06</div>
            			<div style="background:#f5f5f5"> </div>
			  <!-- <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7766"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>苏***吉                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7692','1')"  ></i> <span id='click_number_num'>357</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                这个洗面奶我已经买了三支了，还介绍同学买的，实惠又好用，我很喜欢，准备买了还要买                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-02-24</div>
            			<div style="background:#f5f5f5"> </div>
			  <!-- <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7692"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>小***谷                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7691','1')"  ></i> <span id='click_number_num'>339</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                产品用一段时间了，感觉清洁皮肤挺干净，美百颜家的老顾客了，现在在老师的指导下皮肤变的好很多了，真的谢谢你们的指导，赞赞                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-02-24</div>
            			<div style="background:#f5f5f5"> </div>
			  <!-- <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7691"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>多***8                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7690','1')"  ></i> <span id='click_number_num'>412</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                宝贝收到了 速度真的很快 东西还没有用 看起来挺不错的 是朋友推荐的  棒棒哒 过年快递恢复那么快， 在这个特殊的时期为快递点个赞 真心的满意满意 好评好评 下次有需要了肯定会回购的                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-02-24</div>
            			<div style="background:#f5f5f5"> </div>
			  <!-- <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7690"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
<div class="aui-card-list">
            <div class="userinfo-header">
                <div class="aui-info findart_tx">
                    <div class="aui-info-item tx_allpj">
                       <!-- <img src="images/4.jpg" style="width:2.4rem"/>-->
                        会员<br>从***大                    </div>
                     <div class="aui-info-item"><i class="aui-iconfont aui-icon-laud" onclick="zan_num_fun(this,'comment','click_number','comment_id=7689','1')"  ></i> <span id='click_number_num'>458</span></div>
                </div>
            </div>
            <div class="aui-card-list-content-padded">
                老客户了，一直在用这款产品，非常好用补水效果超级好，冬天肌肤也没有干燥，毛孔也变小了，很好用的，推荐有需要的亲们购买哦                <ul class="n_pl_img">
				                <li><img src=""></li>
				                </ul>
            </div>
            <div class="findart_sj">2019-02-24</div>
            			<div style="background:#f5f5f5"> </div>
			  <!-- <div class="aui-bar aui-bar-tab aui-margin-t-15 aui-margin-b-15 allpingjia_cp">
        <div class="aui-bar-tab-item aui-padded-l-15 aui-padded-r-15" tapmode style="width: auto;">
            <div class="search-input aui-font-size-14">
			<input type="search" placeholder="回复楼主" class="search-input">
			<input type="hidden" class='id_value'  value="IF3ZTNOBDH"/>
			<input type="hidden" class='ip_value'  value="reply"/>
			<input type="hidden" class='reply_val'  value="7689"/>
			<a class='tosubmit'>提交</a>
		</div>
        </div>
        </div> -->
        </div>
	
 		</div>
       
    </div>
       
    </div>
    
   
   
    
   	
   
  
   
    
		
<?php
include_once("foot.php");
?>


<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js"  type="text/javascript"></script>
    <script type="text/javascript" src="js/aui-tab.js" ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js" ></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <!-- <script src="js/ZeroClipboard.js" ></script> -->
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
 
</div>

<script>

$(".tosubmit").click(function(){
	var this_con = $(this).parent().find($(".search-input")).val();
	var this_con = $.trim(this_con);
	var this_val = $(this).parent().find($(".reply_val")).val();
	var id_value = $(this).parent().find($(".id_value")).val();
	var reply = $(this).parent().find($(".ip_value")).val();
	
	if(this_con == ''){
		//getMsg('error','内容不允许为空');
		return false;
	}else{
		if(this_con.indexOf("http")>=0 || this_con.indexOf("com")>=0 || this_con.indexOf("cn")>=0 || this_con.indexOf("www")>=0){
			//getMsg('error','内容非法');
			return false;
		}else{
			$.ajax({
				 type: "POST",
				 url: "allpingjia.php.htm",
				 data: {
					 'reply':reply,
					 'replyval' : this_val,
					 'replycon' : this_con,
					 'id_value' : id_value
					 },
				 dataType: "json",
				 success: function(data){
					if(data.status == '1') {
						// $(".tosubmit").prop('disabled',true);
						alert("回复成功");
						setTimeout("window.location.reload()",2000);
					}
	
				 },
				 error: function(data){
					if(data.status == '0') {
						alert("回复失败");
					}
				  }	
			});
		}
	}
	
})
</script>
<!-- <script>
	function zan_num_fun(obj,table,field,where,num=0){
		console.log($(obj))
		num=$(obj).siblings("#click_number_num").html();
		$.ajax({
				 type: "post",
				 url: "findsp.php.htm",
				 data: {'table':table,'field':field,'where':where,'num':num},
				 dataType: "text",
				 success: function(number){
				 $(obj).siblings("#click_number_num").html(number);
				 },
				 
			});
	}
$(function(){ 
    var winH = $(window).height(); //椤甸潰鍙鍖哄煙楂樺害 
    var i = 2; //璁剧疆褰撳墠椤垫暟 
    $(window).scroll(function () { 
        var pageH = $(document.body).height(); 
        var scrollT = $(window).scrollTop(); //婊氬姩鏉op 
        var aa = (pageH-winH-scrollT)/winH; 
		console.log(aa);
        if(aa==0){ 
          	$.ajax({
				 type: "get",
				 url: "",
				 data: {'page':i,'ajax':'list'},
				 dataType: "html",
				 success: function(data){
					console.log(data);
					$('.allpinglun').append(data);
				i++;
				 },
				 
			});
        } 
    }); 
}); 
</script> -->
</body>
</html>