<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>team护肤老师</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>护肤导师</title>
		<link rel="stylesheet" type="text/css" href="dist/css/css.css--v=1.css" >
        <link rel="stylesheet" href="css/aui.css" >
<link rel="stylesheet" type="text/css" href="dist/css/style.css-v=2.css" >
<script src="dist/js/zepto.min.js" ></script>
<script src="dist/js/main.js" ></script>
</head>
<body>	<!--header-->
<div class="main">


   
<?php
include_once("top.php");
?>


<div class="teamzt">
<div  class="w100"><img src="zhuanti/hufu/images/hufu_02.jpg" ></div>
<div  class="w100"><img src="zhuanti/hufu/images/hufu_03.jpg" ></div>
<div  class="w100"><img src="zhuanti/hufu/images/hufu_04.jpg"></div>
<div  class="w100"><img src="zhuanti/hufu/images/hufu_05.jpg" ></div>
<h2>客户服务体系</h2>
<ul class="t_kehu">
<li class="fl t_k"><p>一对一护肤咨询服务</p><span>科学解析肌肤问题，根据每个人的肌肤情况制定个性化、有效的护肤方案！</span></li>
<li class="fr"><img src="zhuanti/hufu/images/hufu_08.jpg" ></li>
</ul>
<ul class="t_kehu">
<li class="fl"><img src="zhuanti/hufu/images/hufu_09.jpg" ></li>
<li class="fr t_k"><p>定期护肤大讲堂</p><span>力求品质至上，为顾客讲解正确、有效的护肤方法，多维塑造美丽状态！</span></li>
</ul>
<ul class="t_kehu">
<li class="fl t_k"><p>专业护肤团队</p><span>6年以上服务经历，组建专业、全面、细致服务的护肤指导团队！</span></li>
<li class="fr"><img src="zhuanti/hufu/images/hufu_12.jpg" ></li>
</ul>
<ul class="t_kehu">
<li class="fl"><img src="zhuanti/hufu/images/hufu_13.jpg" ></li>
<li class="fr t_k"><p>愉悦护肤体验</p><span>金牌售后不定期回访顾客，跟进肌肤状态，业内星级护肤指导服务！</span></li>
</ul>
<h2 class="mar">提供专属肌肤护理方案</h2>
<ul class="t_fan mar">
<li><a><img src="zhuanti/hufu/images/hufu_17.jpg" ></a></li>
<li><a><img src="zhuanti/hufu/images/hufu_19.jpg" ></a></li>
<li><a><img src="zhuanti/hufu/images/hufu_23.jpg" ></a></li>
<li><a><img src="zhuanti/hufu/images/hufu_24.jpg" ></a></li>
<li><a><img src="zhuanti/hufu/images/hufu_27.jpg" ></a></li>
</ul>
<div  class="w100 mar"><img src="zhuanti/hufu/images/hufu_29.jpg" ></div>

<ul class="t_daoshi">
<li class="w100"><img src="zhuanti/hufu/images/hufu_31.jpg" ></li>
<li class="t_daoshine"><p class="w100"><img src="zhuanti/hufu/images/hufu_34.jpg" ></p>
<p>从业时间：<font>9年</font></p>
<p>美丽格言：</p>
<p>赋予我一个美好的灵魂，我的外表也将一同美丽。</p>
<p>主攻方向：</p>
<p>美百颜官方高级护肤老师，主攻红敏肌、角质层薄、肌肤发红、干痒等脆弱肌肤的护理方向。</p>
<!--<p><a href="hufuzt.php?id=1">进入专题 >> </a></p>-->
</li>
</ul>
<ul class="t_daoshi">
<li class="w100"><img src="zhuanti/hufu/images/hufu_38.jpg" ></li>
<li class="t_daoshine"><p class="w100"><img src="zhuanti/hufu/images/hufu_39.jpg" ></p>
<p>从业时间：<font>11年</font></p>
<p>美丽格言：</p>
<p>美的形象是丰富多彩的，而美也是到处出现的。人类本性中就有普遍的爱美的要求。</p>
<p>主攻方向：</p>
<p>美百颜官方高级护肤老师，主张内外兼修的护理方式，致力于从根源上解决肌肤黯淡瑕点、发黄粗糙、发红脆弱、干痒灼热等多种问题，还原肌肤亮泽与强韧。</p>
<!--<p><a href="qubanzt.php?id=2">进入专题 >> </a></p>-->
</li>
</ul>
<ul class="t_daoshi">
<li class="w100"><img src="zhuanti/hufu/images/hufu_46.jpg" ></li>
<li class="t_daoshine"><p class="w100"><img src="zhuanti/hufu/images/hufu_43.jpg" ></p>
<p>从业时间：<font>13年</font></p>
<p>美丽格言：</p>
<p>美的事物应该干干净净，清清白白，在形象上如此，在内心中更是如此。</p>
<p>主攻方向：</p>
<p>美百颜官方高级护肤老师，擅长对丘疹痘、闭口痘、囊肿痘、红肿痘、粉刺痘等各类痘痘的修护。擅于根据不同类型痘痘的不同生长阶段，搭配不同的祛痘成分进行针对性的分阶祛痘，同时对祛痘后的肤色不均、毛孔粗大、肌肤凹凸不平等问题也具有丰富的修护经验。</p>
<!--<p><a href="qudouzt__3.php?id=3">进入专题 >> </a></p>-->
</li>
</ul>
<ul class="t_daoshi">
<li class="w100"><img src="zhuanti/hufu/images/hufu_50.jpg" ></li>
<li class="t_daoshine"><p class="w100"><img src="zhuanti/hufu/images/hufu_51.jpg" tppabs="http://m.vense.cn/zhuanti/hufu/images/hufu_51.jpg"></p>
<p>从业时间：<font>9年</font></p>
<p>美丽格言：</p>
<p>要创造出真正的美必须具备巨匠的技艺。</p>
<p>主攻方向：</p>
<p>美百颜官方高级护肤老师，主攻面部和颈部皱纹、眼部细纹、松弛下垂等衰老肌肤，脆弱发红、发热发痛等问题肌肤的一对一专业指导和修护，获得大量消费者的认可与推荐。</p>
<!--<p><a>进入专题 >> </a></p>-->
</li>
</ul>

<ul class="t_daoshi">
<li class="w100"><img src="zhuanti/hufu/images/hufu_54.jpg" tppabs="http://m.vense.cn/zhuanti/hufu/images/hufu_54.jpg"></li>
<li class="t_daoshine"><p class="w100"><img src="zhuanti/hufu/images/hufu_55.jpg" tppabs="http://m.vense.cn/zhuanti/hufu/images/hufu_55.jpg"></p>
<p>从业时间：<font>6年</font></p>
<p>美丽格言：</p>
<p>你的美会呈现在对方的眼睛里。</p>
<p>主攻方向：</p>
<p>美百颜综合高级护肤老师，擅长晒伤、痘肌、色斑、皱纹、泛红等各类肌肤问题的修护。精通护肤成分，了解多种美容专业知识，善于根据不同的肌肤类型搭配不同的修护方案。</p>
<!--<p><a>进入专题 >> </a></p>-->
</li>
</ul>


</div>


            		
   
 <?php
include_once("foot.php");
?>  
   
  
   
   
    



<!--tanchu-->

  
 


         <script src="js/api.js" ></script>
		 <script src="js/jquery.min.js" ></script>
    <script type="text/javascript" src="js/aui-tab.js" ></script>
	<script type="text/javascript" src="js/jquery.cookie.js" ></script>
<script type="text/javascript" src="js/aui-dialog.js"></script>
	
	<script>
	var cur_cart = JSON.parse($.cookie("cart"));
	var count_str=cur_cart.length;
	$('.cart_count').html(count_str)
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="js/ZeroClipboard.js" ></script>
	
	



	
        <script>
		
   $(".fx_v").click(function(){
                $(".fx_main").fadeIn(400);
            });

            $(".fx_close").click(function(){
                $(".fx_main").fadeOut(400);
            }); 			
			

        var searchBar = document.querySelector(".aui-searchbar");
        var searchBarInputsss = document.querySelector(".aui-searchbar inputss");
        var searchBarBtn = document.querySelector(".aui-searchbar .aui-searchbar-btn");
        var searchBarClearBtn = document.querySelector(".aui-searchbar .aui-searchbar-clear-btn");
        if (searchBar) {
            searchBarInput.onclick = function() {
                searchBarBtn.style.marginRight = 0;
            }
            searchBarInput.oninput = function() {
                if (this.value.length) {
                    searchBarClearBtn.style.display = 'block';
                    searchBarBtn.classList.add("aui-text-info");
                    searchBarBtn.textContent = "搜索";
					
                } else {
                    //searchBarClearBtn.style.display = 'none';
                    searchBarBtn.classList.remove("aui-text-info");
                    searchBarBtn.textContent = "取消";
                }
            }
        }
        searchBarClearBtn.onclick = function() {
			
            //this.style.display = 'none';
            searchBarInput.value = '';
            searchBarBtn.classList.remove("aui-text-info");
            searchBarBtn.textContent = "取消";
        }
        searchBarBtn.onclick = function() {
            var keywords = searchBarInput.value;
            if (keywords.length) {
                searchBarInput.blur();
                document.getElementById("search-keywords").textContent = keywords;
            } else {
                this.style.marginRight = "-" + this.offsetWidth + "px";
                searchBarInput.value = '';
                searchBarInput.blur();
            }
        }
		searchBarClearBtn.style.display = 'block';
		</script>
		
	<script>(function() {var _53code = document.createElement("script");_53code.src = "../tb.53kf.com/code/code/10159345/6"/*tpa=https://tb.53kf.com/code/code/10159345/6*/;var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();</script>		</body>
</html>