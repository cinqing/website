<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>订购成功！</title>
<style type="text/css">
<!--
*{margin:0;padding:0;}
body{font:14px "微软雅黑",Arial,Verdana;color:#333;text-align:left;padding-top:100px;background-color:#fff;} 
a:link,a:visited{color:#006633;text-decoration:none;}a:hover{color:#090;text-decoration:underline;}
#ddok{width:100%;height:auto;overflow:hidden;margin:0 auto;padding:20px 0;background-color:#FFF;}
#ddok table td{padding:10px 20px;}
#ddok table td.tda{text-align:right;background-color:#F7F7F7;}
#ddok table td.tdb{color:#bd0a01;}
.dgok{height:35px;text-align:center;margin:20px 0;font-size:22px;font-weight:bold;color:#006633;}
.dgok img{border:0 none;vertical-align:middle;}
.info{text-align:center; font-size:16px; margin:20px 0; color:#006633; font-weight:bold;}
-->
</style>
</head>

<body>
<?php 
     session_start();
     
?>


<div id="ddok">	
    <p class="info">下面是部分订单信息，如有错误，请及时咨询客服改正，谢谢！</p>
	<table width="40%" border="1" cellpadding="0" cellspacing="0" bordercolordark="#FFFFFF" bordercolorlight="#999999" align="center" style="margin:0 auto;">
	    
		
	    <tr>
		    <td width="30%" class="tda">收货人姓名</td>
			<td width="70%" class="tdb"><?php echo $_SESSION['temp'][0];?></td>
		</tr>
		<tr>
		    <td class="tda">收货人手机号码</td>
			<td class="tdb"><?php echo $_SESSION['temp'][1];?></td>
		</tr>
        <tr>
		    <td class="tda">所在地区</td>
			<td class="tdb"><?php echo $_SESSION['temp'][2].$_SESSION['temp'][3].$_SESSION['temp'][4];?></td>
		</tr>
				
		<tr>
		    <td class="tda">收货人详细地址</td>
			<td class="tdb"><?php echo $_SESSION['temp'][5];?></td>
		</tr>
		<tr>
		    <td width="30%" class="tda">订购产品</td>
			<td width="70%" class="tdb"><?php echo $_SESSION['temp'][7];?></td>
		</tr>
		<tr>
		    <td width="30%" class="tda">订购数量</td>
			<td width="70%" class="tdb"><?php echo $_SESSION['temp'][8];?></td>
		</tr>
		<tr>
		    <td width="30%" class="tda">订购总额</td>
			<td width="70%" class="tdb"><?php echo $_SESSION['temp'][9];?></td>
		</tr>
		<tr>
		    <td class="tda">付款方式</td>
			<td class="tdb"><?php echo $_SESSION['temp'][6];?></td>
		</tr>
        <tr>
		    <td class="tda">备注说明</td>
			<td class="tdb"><?php echo $_SESSION['temp'][10];?></td>
		</tr>
        
	</table>
	<div class="dgok"><img src="../images/ok.jpg" />　恭喜您，订购成功！</div>
	<div class="dgok"><a href="../../index.php">立即返回 &gt;&gt;</a></div>
</div>
<!--关闭session-->
<?php 
$_SESSION = array();
?>
</body>
</html>