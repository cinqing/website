<?php

//设置编码格式
header("Content-type: text/html; charset=utf-8"); 
//用mysqli来连接数据库（服务器，用户名，密码，数据库名字）
$mysqli=new mysqli("localhost","root","123321","kangaroo");
if(mysqli_connect_errno()){
    echo "连接数据库失败：".mysqli_connect_error();
    $mysqli=null;
    exit;
}
echo "连接数据库成功！<br/>";


?>



