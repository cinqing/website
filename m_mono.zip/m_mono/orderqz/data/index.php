<?php
session_start();

header("Content-Type:text/html; charset=utf8");

// $(function(){
//             $name = $.query.get("name");
//             $num = $.query.get("num");
//             $count = $.query.get("count");
//         });



      
//判断验证码是否正确
if(empty($_POST['usercode'])||$_POST['usercode'] != $_SESSION['wfcode']){
    echo "<p style='font-size:12px;color:#BD0000;'>错误：验证码不正确！<a href='javascript:history.go(-1);'>返回重新填写 >></a></p>";
    exit(0);
}

//用mysqli来连接数据库（服务器，用户名，密码，数据库名字）
$mysqli=new mysqli("localhost","root","123321","kangaroo");
if(mysqli_connect_errno()){
    echo "连接数据库失败：".mysqli_connect_error();
    $mysqli=null;
    exit;
}
//echo "连接数据库成功！<br/>";

//获取MySQL编码
//echo $mysqli->character_set_name()."<br/>";
//获取客户端信息
//echo $mysqli->get_client_info()."<br/>";

if(!isset($_POST['submit'])){
	exit("错误执行");
}//判断是否有submit操

//避免乱码
mysqli_set_charset($mysqli, 'utf8'); 


$dgname=$_POST['dgname'];//姓名
$mob=$_POST['mob'];//手机号
$province=$_POST['province'];//省份
$city=$_POST['city'];//城市
$area=$_POST['area'];//地区
$address=$_POST['address'];//详细地址
$paytype=$_POST['paytype'];//付款方式
$usercode=$_POST['usercode'];//验证码
$beizhu=$_POST['beizhu'];//备注
$productname=$_POST['productname'];//产品名称
$numbers=$_POST['productnum'];//产品数量
$total=$_POST['productcount'];//总价




// $productname=pname;//产品名称
// $numbers='';//产品数量
// $total='';//总价
// $productname=pname;
// $numbers=pnum;
// $total=count;

//include('conn.php');//链接数据库
//session传值到下一个页面，把要传的值放在一个数组里
$_SESSION["temp"]=array($dgname,$mob,$province,$city,$area,$address,$paytype,$productname,$numbers,$total,$beizhu);


$sql="insert into qzorder (name,mobile,productname,province,city,area,address,paytype,code,total,productnum,beizhu,datetimes) values('$dgname','$mob','$productname','$province','$city','$area','$address','$paytype','$usercode','$total','$numbers','$beizhu',now())";
//执行sql语句
$result = $mysqli->query($sql);
//var_dump($result);
//如果执行失败，则抛出错误
if(!$result){
	echo "sql语句错误<br/>";
    echo "error:".$mysqli->error."|".$mysqli->error;
    exit;    
}

//获取影响行数
//echo "影响行数：".$mysqli->affected_rows."<br/>";
//if($mysqli->affected_rows>0){
//    echo "执行成功，有行数被影响！<br/>";    
//}
//获取最后一个自增长ID
//echo "最后自动增长的ID：".$mysqli->insert_id;
 echo "           <script>   setTimeout(function(){window.location.href='success.php';},1000);           </script>           ";
//如果错误使用js 1秒后跳转到下单页面重试; 
$mysqli->close();//关闭数据库 




?>