$(function(){
	var timer = null;
	$('#openMenu').click(function(){
		var iH = $(window).height();
		
		//alert(iH);
		if($('#menu').css('display')=='none'){
			var msk = $('<div id="msk"></div>');
			
			$('body').append(msk);
			$(this).find('i').addClass('icon-exit');	
			$('#menu').show().animate({'left':0},500);
		}else{
			$('#menu').animate({'left':'-15em'},500);
			$(this).find('i').removeClass('icon-exit');	
			clearTimeout(timer);
			timer = setTimeout(function(){
				$('#msk').remove();
				$('#menu').hide();
			},500);
		}
	});
	var $scrollTop = $('<a data-click="��������" class="scroll-top" href="javascript:scrollTo(0,0);"></a>').appendTo($(".main"));
	$(window).scroll(function(){
		var windowHeight = $(this).height();
		var scrollTop = $(window).scrollTop();
		if(scrollTop > windowHeight / 2){
			$scrollTop.show();
		}else{
			$scrollTop.hide();
		}
	});
	
});





