<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>account</title>
	<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0">
<meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>填写订单</title>
<script type="text/javascript" src="./js/jquery2.1.js"></script>
<script type="text/javascript" src="./js/jquery.cookie.js"></script>
<script type="text/javascript" src="./js/aui-dialog.js"></script>
<link href="./css/aui.css" type="text/css" rel="stylesheet">
<style type="text/css">
.pay_type .huo{background: #f1b844;color: #fff;border: none;padding: 0.1em 0.3rem}
.pay_type .alipay{background: #3c98e3;color: #fff;border: none;padding: 0.1em 0.3rem}
.pay_goods ul li{text-align: center;}
.pay_goods .aui-list-item-inner span:first-child{padding: 0.1em}
.pay_goods .aui-list .aui-list-item,.pay_type .aui-list .aui-list-item{border-bottom: 1px solid #dddddd}

.pay_allcount .aui-list-item-inner{padding-top: 0.5em;padding-bottom: 0.5em}
#footer{border-top: 1px solid #ddd;}
#footer .aui-bar-tab-item:first-child .aui-bar-tab-label{color:#19258f;font-size: 0.8em}
#footer .aui-bar-tab-item:last-child{background: #010e80}
#footer .aui-bar-tab-item:last-child .aui-bar-tab-label{font-size: 1em;color: #fff;}
</style>
</head>
<body>

<div class="aui-content aui-margin-b-15 cart_address">
<form id="myform" enctype="multipart/form-data" target="_blank" method="post">
    <ul class="aui-list aui-form-list">
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    收货人姓名:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="content[1]" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    手机号码:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="content[3]" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                    详细地址:
                </div>
                <div class="aui-list-item-input">
                    <input type="text" name="content[5]" placeholder="">
                </div>
            </div>
        </li>
        <li class="aui-list-item">
            <div class="aui-list-item-inner">
                <div class="aui-list-item-label">
                   备注说明:
                </div>
                <div class="aui-list-item-input">
                    <textarea placeholder="" name="content[6]"></textarea>
                </div>
            </div>
        </li>
        </ul>
		<input type="hidden" name="content[4]" value="支付宝">
		<input type="hidden" value="69" name="fid">
		<input type="hidden" name="content[0]" id="proselect" value="订单金额: 0元 不满300元，需付邮费10元（实付金额）10元">
		<input type="hidden" name="extend_referer" id="extend_referer" value="">
         <input type="hidden" name="site_referer" id="site_referer" value="">
		</form>
</div>

<div class="aui-content aui-margin-b-15 pay_type">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-label-icon">
                   <button type="button" class="huo" value="货">货</button>
                </div>
                <div class="aui-list-item-inner">
                    货到付款<span>安心有保障</span><input type="radio" name="pay_type" id="huo" value="0" class="aui-radio">
                </div>
            </li>
             <li class="aui-list-item">
                <div class="aui-list-item-label-icon">
                   <button type="button" class="alipay" value="支">支</button>
                </div>
                <div class="aui-list-item-inner">
                    支付宝&nbsp;&nbsp;&nbsp;<span>安心有保障</span><input type="radio" id="zhi" class="aui-radio" name="pay_type" checked="" value="1">
                </div>
            </li>
        </ul>
    </div>
    <div class="aui-content aui-margin-b-15 pay_type">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-inner">
                    快递配送 (满300元免运费)
                </div>
            </li>
        </ul>
    </div>
    
    <div class="aui-content aui-margin-b-15 pay_goods">
    	<!-- <iframe width="100%"  frameborder="0" id="orderform" src="ordernew.php" scrolling="no" onload="this.height=800"></iframe> -->
        <ul class="aui-list aui-list-in" id="order_list">
        	
        </ul>
    </div>

    <div class="aui-content aui-margin-b-15 pay_allcount">
        <ul class="aui-list aui-list-in">
            <li class="aui-list-item">
                <div class="aui-list-item-inner">
                  <ul><li>商品价格:<span id="count">0</span>元</li><li>配送费用：<span id="yunfei">10.00</span>元</li></ul>
                  
                </div>
            </li>
        </ul>
    </div>
    <div style="height: 2.5em;margin-bottom: 0.75em">
    </div>
    <footer class="aui-bar aui-bar-tab" id="footer">
    <div class="aui-bar-tab-item aui-active" tapmode="">
        <div class="aui-bar-tab-label">实付金额:<span id="pay_count">10</span>元</div>
    </div>
    <div class="aui-bar-tab-item" tapmode="">
        <a class="aui-bar-tab-label" id="submit" target="_blank">去提交</a>
    </div>
    </footer>
	<script type="text/javascript">
	$(function(){
			var parr = Array();
			var pid='';

			parr["8"] = Array("8",
				"红色密码多效滋养面膜",
				  "pinpai/vense/images/2017091509390517205.jpg",
				  "128",
				  "25ml*5片",
				  "product.php?id=8",
				  "pinpai/vense/images/2017091509390517205.jpg",
				  "8"
				  );

			parr["12"] = Array("12",
				"舒润洁面乳",
				  "pinpai/vense/images/201709150939217135.jpg",
				  "86",
				  "150g",
				  "product.php?id=12",
				  "pinpai/vense/images/201709150939217135.jpg",
				  "12"
				  );

			parr["13"] = Array("13",
				"舒润柔肤水",
				  "pinpai/vense/images/2017091509394410724.jpg",
				  "128",
				  "150ml",
				  "product.php?id=13",
				  "pinpai/vense/images/2017091509394410724.jpg",
				  "13"
				  );

			parr["14"] = Array("14",
				"舒润滋养面膜",
				  "pinpai/vense/images/201709150940027584.jpg",
				  "128",
				  "25ML*5片",
				  "product.php?id=14",
				  "pinpai/vense/images/201709150940027584.jpg",
				  "14"
				  );

			parr["21"] = Array("21",
				"闪耀光彩CC霜",
				  "pinpai/vense/images/201709151427595502.jpg",
				  "128",
				  "50g",
				  "product.php?id=21",
				  "pinpai/vense/images/201709151427595502.jpg",
				  "21"
				  );

			parr["22"] = Array("22",
				"毛孔紧致护理套装",
				  "pinpai/vense/images/201709151429425828.jpg",
				  "296",
				  "50ml+50g+50ml",
				  "product.php?id=22",
				  "pinpai/vense/images/201709151429425828.jpg",
				  "22"
				  );

			parr["23"] = Array("23",
				"舒润柔肤乳",
				  "pinpai/vense/images/2017091509405117373.jpg",
				  "168",
				  "100ml",
				  "product.php?id=23",
				  "pinpai/vense/images/2017091509405117373.jpg",
				  "23"
				  );

			parr["24"] = Array("24",
				"赋活毛孔细致精华液",
				  "pinpai/vense/images/201709150941375066.jpg",
				  "320",
				  "120ml",
				  "product.php?id=24",
				  "pinpai/vense/images/201709150941375066.jpg",
				  "24"
				  );

			parr["26"] = Array("26",
				"舒润柔肤水（大）",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "238",
				  "300ml",
				  "product.php?id=26",
				  "pinpai/vense/images/201709150942055783.jpg",
				  "26"
				  );

			parr["27"] = Array("27",
				"毛孔细致精华液",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "108",
				  "50ml",
				  "product.php?id=27",
				  "pinpai/vense/images/201709150943335779.jpg",
				  "27"
				  );

			parr["28"] = Array("28",
				"唯恩诗黑头导出液",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "108",
				  "50ml",
				  "product.php?id=28",
				  "pinpai/vense/images/201709150945177323.jpg",
				  "28"
				  );

			parr["29"] = Array("29",
				"唯恩诗黑头吸附面膜",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "80",
				  "50g",
				  "product.php?id=29",
				  "pinpai/vense/images/201709150945494493.jpg",
				  "29"
				  );

			parr["32"] = Array("32",
				"复合益生菌固体饮料",
				  "pinpai/vense/images/20160827160102.gif",
				  "560",
				  "90g",
				  "product.php?id=32",
				  "pinpai/vense/images/20160827160102.gif",
				  "32"
				  );

			parr["35"] = Array("35",
				"唯恩诗舒润系列",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "510",
				  "150g+300ml+100ml+25ml*5",
				  "product.php?id=35",
				  "pinpai/vense/images/2017091509461016916.jpg",
				  "35"
				  );

			parr["39"] = Array("39",
				"智研光肌系列",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "864",
				  "30ml+30g+30ml+ 50g",
				  "product.php?id=39",
				  "pinpai/vense/images/201709150946511581.jpg",
				  "39"
				  );

			parr["44"] = Array("44",
				"卓研晶透祛斑精华液",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "330",
				  "30ml",
				  "product.php?id=44",
				  "pinpai/vense/images/201911151620211488.jpg",
				  "44"
				  );

			parr["45"] = Array("45",
				"肌源净澈赋活霜",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "360",
				  "50g",
				  "product.php?id=45",
				  "pinpai/vense/images/2017091509475810407.jpg",
				  "45"
				  );

			parr["46"] = Array("46",
				"唯恩诗肌源净澈系列",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "690",
				  "30ml+50g",
				  "product.php?id=46",
				  "pinpai/vense/images/201709150948174845.jpg",
				  "46"
				  );

			parr["47"] = Array("47",
				"活氧冰肌水冻膜",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "178",
				  "100g",
				  "product.php?id=47",
				  "pinpai/vense/images/201709150953045005.jpg",
				  "47"
				  );

			parr["49"] = Array("49",
				"安护鲜肌水养面膜",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=49",
				  "pinpai/vense/images/2017091509541212770.jpg",
				  "49"
				  );

			parr["50"] = Array("50",
				"安护氨基酸植萃洁面乳",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "86",
				  "80g",
				  "product.php?id=50",
				  "pinpai/vense/images/2020031811113912136.jpg",
				  "50"
				  );

			parr["51"] = Array("51",
				"安护倍润鲜肌水",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "138",
				  "100ml",
				  "product.php?id=51",
				  "pinpai/vense/images/2019010211593814223.jpg",
				  "51"
				  );

			parr["52"] = Array("52",
				"唯恩诗安护植润滋养霜",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "260",
				  "30g",
				  "product.php?id=52",
				  "pinpai/vense/images/202003161420146720.jpg",
				  "52"
				  );

			parr["53"] = Array("53",
				"安护倍润修护乳",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "198",
				  "45g",
				  "product.php?id=53",
				  "pinpai/vense/images/201806301416459980.jpg",
				  "53"
				  );

			parr["54"] = Array("54",
				"唯恩诗安护植润系列",
				  "pinpai/vense/images/202003230943113170.png",
				  "810",
				  "5件套",
				  "product.php?id=54",
				  "pinpai/vense/images/202003230943113170.png",
				  "54"
				  );

			parr["56"] = Array("56",
				"肌妍新生美眼霜",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "280",
				  "15g",
				  "product.php?id=56",
				  "pinpai/vense/images/201709150956533357.jpg",
				  "56"
				  );

			parr["57"] = Array("57",
				"肌妍新生滋养霜",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "360",
				  "50g",
				  "product.php?id=57",
				  "pinpai/vense/images/2017091509571313567.jpg",
				  "57"
				  );

			parr["58"] = Array("58",
				"肌妍新生系列",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "960",
				  "精华液30ml+滋养霜50g+眼霜15g",
				  "product.php?id=58",
				  "pinpai/vense/images/201709150957539033.jpg",
				  "58"
				  );

			parr["59"] = Array("59",
				"肌妍新生精华液",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "320",
				  "30ml",
				  "product.php?id=59",
				  "pinpai/vense/images/2017091509581617045.jpg",
				  "59"
				  );

			parr["60"] = Array("60",
				"琉晶莹彩唇膏",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "189",
				  "3.8g",
				  "product.php?id=60",
				  "pinpai/vense/images/201709150958432277.jpg",
				  "60"
				  );

			parr["61"] = Array("61",
				"炫黑纤长修护睫毛膏",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "126",
				  "7ml",
				  "product.php?id=61",
				  "pinpai/vense/images/2017091509591912492.jpg",
				  "61"
				  );

			parr["62"] = Array("62",
				"精致塑形眉彩笔",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "98",
				  "0.24g",
				  "product.php?id=62",
				  "pinpai/vense/images/2017091509593916662.jpg",
				  "62"
				  );

			parr["63"] = Array("63",
				"炫黑速干眼线液笔",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "108",
				  "0.5ml",
				  "product.php?id=63",
				  "pinpai/vense/images/2017091510000614898.jpg",
				  "63"
				  );

			parr["64"] = Array("64",
				"智研光肌精华液",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "218",
				  "30ml",
				  "product.php?id=64",
				  "pinpai/vense/images/201709151000574001.jpg",
				  "64"
				  );

			parr["65"] = Array("65",
				"智研光肌霜",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "260",
				  "50g",
				  "product.php?id=65",
				  "pinpai/vense/images/2017091510012615100.jpg",
				  "65"
				  );

			parr["66"] = Array("66",
				"唯恩诗彩妆系列",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "521",
				  "唇膏3.8g 睫毛膏7ml 眼线液笔0.5ml 眉彩笔0.2",
				  "product.php?id=66",
				  "pinpai/vense/images/2017091514363516474.jpg",
				  "66"
				  );

			parr["68"] = Array("68",
				"炫黑浓翘修护睫毛膏",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "126",
				  "7ml",
				  "product.php?id=68",
				  "pinpai/vense/images/2017091510024318152.jpg",
				  "68"
				  );

			parr["69"] = Array("69",
				"凝光沁亮肌活霜",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "360",
				  "50g",
				  "product.php?id=69",
				  "pinpai/vense/images/2017091510022316763.jpg",
				  "69"
				  );

			parr["70"] = Array("70",
				"凝光沁亮肌活精华液",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "330",
				  "50ml",
				  "product.php?id=70",
				  "pinpai/vense/images/201709151003342202.jpg",
				  "70"
				  );

			parr["71"] = Array("71",
				"凝光沁亮系列",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "690",
				  "50ml、50g",
				  "product.php?id=71",
				  "pinpai/vense/images/201709151437583434.jpg",
				  "71"
				  );

			parr["72"] = Array("72",
				"智研光肌祛痘膏",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "168",
				  "30g",
				  "product.php?id=72",
				  "pinpai/vense/images/2017091510043416438.jpg",
				  "72"
				  );

			parr["73"] = Array("73",
				"智研光肌祛痘精华液",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "218",
				  "30ml",
				  "product.php?id=73",
				  "pinpai/vense/images/201709151005001151.jpg",
				  "73"
				  );

			parr["74"] = Array("74",
				"聚能修护精华液",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "420",
				  "0.35ml*15粒",
				  "product.php?id=74",
				  "pinpai/vense/images/2017091510051717615.jpg",
				  "74"
				  );

			parr["75"] = Array("75",
				"梦幻柔光气垫BB霜送替换装",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "188",
				  "13g*2",
				  "product.php?id=75",
				  "pinpai/vense/images/201709151005396053.jpg",
				  "75"
				  );

			parr["76"] = Array("76",
				"净润舒缓卸妆液",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "168",
				  "200ml",
				  "product.php?id=76",
				  "pinpai/vense/images/201709151006019929.jpg",
				  "76"
				  );

			parr["77"] = Array("77",
				"凝光沁亮修颜霜",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "168",
				  "37ml",
				  "product.php?id=77",
				  "pinpai/vense/images/201709151006185077.jpg",
				  "77"
				  );

			parr["84"] = Array("84",
				"户外隔离防护霜",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "128",
				  "50g",
				  "product.php?id=84",
				  "pinpai/vense/images/2017091510063410477.jpg",
				  "84"
				  );

			parr["88"] = Array("88",
				"臻妍纯皙-焕能活颜面膜",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "288",
				  "25ml/片*5",
				  "product.php?id=88",
				  "pinpai/vense/images/2017091515301216028.jpg",
				  "88"
				  );

			parr["89"] = Array("89",
				"臻妍纯皙-密活亮采面膜",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=89",
				  "pinpai/vense/images/201709151529494354.jpg",
				  "89"
				  );

			parr["90"] = Array("90",
				"臻妍纯皙-冰肌盈耀面膜",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "288",
				  "25ml/片*5片",
				  "product.php?id=90",
				  "pinpai/vense/images/201709151529226909.jpg",
				  "90"
				  );

			parr["92"] = Array("92",
				"鱼胶原蛋白肽粉30支装",
				  "pinpai/vense/images/2017102412232311313.png",
				  "1680",
				  "150克（5克X 30瓶）",
				  "product.php?id=92",
				  "pinpai/vense/images/2017102412232311313.png",
				  "92"
				  );

			parr["93"] = Array("93",
				"鱼胶原蛋白肽粉10支装",
				  "pinpai/vense/images/201711061800143549.png",
				  "580",
				  "50克（5克X 10瓶）",
				  "product.php?id=93",
				  "pinpai/vense/images/201711061800143549.png",
				  "93"
				  );

			parr["94"] = Array("94",
				"植物源性花青素固体饮料",
				  "pinpai/vense/images/201906281827576188.png",
				  "580",
				  "2克*20袋",
				  "product.php?id=94",
				  "pinpai/vense/images/201906281827576188.png",
				  "94"
				  );

			parr["95"] = Array("95",
				"蔓越莓维生素C固体饮料",
				  "pinpai/vense/images/2017112709114214835.png",
				  "298",
				  "3g*30袋/盒",
				  "product.php?id=95",
				  "pinpai/vense/images/2017112709114214835.png",
				  "95"
				  );

			parr["96"] = Array("96",
				"青果肌滢润洁面乳",
				  "pinpai/vense/images/2017113018050315284.png",
				  "79",
				  "120g",
				  "product.php?id=96",
				  "pinpai/vense/images/2017113018050315284.png",
				  "96"
				  );

			parr["97"] = Array("97",
				"青果肌滢润精粹水",
				  "pinpai/vense/images/2017113017551118264.png",
				  "109",
				  "150ml",
				  "product.php?id=97",
				  "pinpai/vense/images/2017113017551118264.png",
				  "97"
				  );

			parr["98"] = Array("98",
				"青果肌滢润保湿乳",
				  "pinpai/vense/images/201711301817469051.png",
				  "119",
				  "100ml",
				  "product.php?id=98",
				  "pinpai/vense/images/201711301817469051.png",
				  "98"
				  );

			parr["99"] = Array("99",
				"青果肌滢润补水面膜",
				  "pinpai/vense/images/201711301833591400.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=99",
				  "pinpai/vense/images/201711301833591400.png",
				  "99"
				  );

			parr["100"] = Array("100",
				"青果肌净爽控油面膜",
				  "pinpai/vense/images/2017113018393711530.png",
				  "138",
				  "25ml/盒/10p",
				  "product.php?id=100",
				  "pinpai/vense/images/2017113018393711530.png",
				  "100"
				  );

			parr["102"] = Array("102",
				"鲜肌酵母精华水",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "218",
				  "120ml",
				  "product.php?id=102",
				  "pinpai/vense/images/201807131336024298.jpg",
				  "102"
				  );

			parr["103"] = Array("103",
				"唯恩诗净润卸妆乳",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "168",
				  "120g",
				  "product.php?id=103",
				  "pinpai/vense/images/2018073017031712381.jpg",
				  "103"
				  );

			parr["105"] = Array("105",
				"晶彩胶原寡肽眼膜",
				  "pinpai/vense/images/201905071131456858.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=105",
				  "pinpai/vense/images/201905071131456858.png",
				  "105"
				  );

			parr["106"] = Array("106",
				"唯恩诗角鲨烷舒缓鲜肌喷雾",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "128",
				  "150ml",
				  "product.php?id=106",
				  "pinpai/vense/images/2019062917593510153.jpg",
				  "106"
				  );

			parr["108"] = Array("108",
				"晶彩松露胜肽眼膜",
				  "pinpai/vense/images/2019092917513914239.png",
				  "168",
				  "5ml*10片",
				  "product.php?id=108",
				  "pinpai/vense/images/2019092917513914239.png",
				  "108"
				  );

			parr["109"] = Array("109",
				"VENSE唯恩诗 唯恩诗卓研晶透系列",
				  "pinpai/vense/images/201909301115234803.png",
				  "690",
				  "30ml+50g",
				  "product.php?id=109",
				  "pinpai/vense/images/201909301115234803.png",
				  "109"
				  );

			parr["110"] = Array("110",
				"保加利亚玫瑰花水面膜",
				  "pinpai/vense/images/201910291820001217.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=110",
				  "pinpai/vense/images/201910291820001217.png",
				  "110"
				  );

			parr["111"] = Array("111",
				"四重玻尿酸水库面膜",
				  "pinpai/vense/images/2019102918243214736.png",
				  "138",
				  "25ml*5片",
				  "product.php?id=111",
				  "pinpai/vense/images/2019102918243214736.png",
				  "111"
				  );

			parr["112"] = Array("112",
				"城市霓虹丝悦唇膏口红",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "99",
				  "3.4g",
				  "product.php?id=112",
				  "pinpai/vense/images/2019112815352811331.jpg",
				  "112"
				  );

			parr["113"] = Array("113",
				"卓研晶透祛斑滋养霜",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "360",
				  "50g",
				  "product.php?id=113",
				  "pinpai/vense/images/202001131800338079.jpg",
				  "113"
				  );

			parr["114"] = Array("114",
				"唯恩诗安护植润鲜肌水",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "138",
				  "100ml",
				  "product.php?id=114",
				  "pinpai/vense/images/2020022419092617370.jpg",
				  "114"
				  );

			parr["115"] = Array("115",
				"唯恩诗安护植润修护乳",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "198",
				  "45g",
				  "product.php?id=115",
				  "pinpai/vense/images/2020022422353215330.jpg",
				  "115"
				  );

			parr["116"] = Array("116",
				"唯恩诗安护鲜肌水养植萃面膜",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "128",
				  "25ml/片×5",
				  "product.php?id=116",
				  "pinpai/vense/images/202002242244575491.jpg",
				  "116"
				  );

			parr["117"] = Array("117",
				"唯恩诗清透亮采防晒霜",
				  "pinpai/vense/images/202003271311538925.png",
				  "128",
				  "50g",
				  "product.php?id=117",
				  "pinpai/vense/images/202003271311538925.png",
				  "117"
				  );

			parr["118"] = Array("118",
				"唯恩诗净润舒缓卸妆液 养肤级卸妆",
				  "pinpai/vense/images/202003301121288441.png",
				  "168",
				  "200ml",
				  "product.php?id=118",
				  "pinpai/vense/images/202003301121288441.png",
				  "118"
				  );


		var cur_cart = JSON.parse($.cookie("cart"));
		var dialog = new auiDialog();
		var sub_product='';
		var pid_array=pid.split(',');
		show_cart(cur_cart);
		//sub_product += "订单金额: "+dgprice+"元 不满300元，需付邮费10元（实付金额）"+(dgprice+10)+"元";
		//sub_product += "（实付金额）"+dgprice+"元";
		
		function show_cart(obj){
			
			if(obj){
				$("#order_list").html("");
				var count=0;
				var pstring='';
				for(var i in obj){
					if($.inArray(obj[i]['pId'],pid_array)!=-1){
						sub_product += parr[obj[i]["pId"]][1]+"["+obj[i]["proS"]+"X"+parr[obj[i]["pId"]][3]+"]="+(parseInt(obj[i]["proS"])*parseFloat(parr[obj[i]["pId"]][3]))+"元 ";	
						pstring=pstring+'<li class="aui-list-item"><div class="aui-list-item-inner"><span style="width: 15%"><img src="'+parr[obj[i]["pId"]][6]+'"  style="width:75%; margin:0 auto"></span><span style="width: 45%; font-size:13px;    display: inherit">'+parr[obj[i]["pId"]][1]+'</span><span style="width: 10%">x'+parseInt(obj[i]["proS"])+'</span><span style="width: 20%">'+parseInt(obj[i]["proS"])*parseFloat(parr[obj[i]["pId"]][3])+'元</span></div></li>';
						count+=parseFloat(parr[obj[i]["pId"]][3])*parseInt(obj[i]["proS"]);
					}
					
				}
				$("#order_list").html(pstring);
				$('#count').html(count);
				var yunfei='10.00';
				if(count>300){
					yunfei='0.00';
					$('#proselect').val(sub_product+"（实付金额）"+parseFloat(count)+"元");
				}else{
					$('#proselect').val(sub_product+"订单金额: "+parseFloat(count)+"元 不满300元，需付邮费10元（实付金额）"+((parseFloat(count)+parseFloat(yunfei)))+"元");
				}
				$('#yunfei').html(yunfei);
				$('#pay_count').html((parseFloat(count)+parseFloat(yunfei)));
			}
		}
	$('#submit').click(function(){
		submit();
	});
	function delcart(obj){
		for(var i in obj){
			if($.inArray(obj[i]['pId'],pid_array)!=-1){
				obj.splice(i,1);
			}
		}
		$.cookie("cart",JSON.stringify(obj));
	}
	function submit(){
		$("#site_referer").val(window.location.href);
		$("#extend_referer").val(document.referrer);
		var url='';
		var _j=false;
		$('#myform input').each(function(){
			if($(this).val().length==0){
				_j=true;
				return false;
			}
		});
		if(_j){
			dialog.alert({
					title:"温馨提示",
					msg:'收货地址信息不全',
					buttons:['确定']
				},function(ret){
					
				})
				return false;
		}
		
		if($('[name="pay_type"]:checked').val()==1){
			$('[name="content[4]"]').val('支付宝');
			url='success.html';
		}else{
			$('[name="content[4]"]').val('货到付款(安心有保障)');
			url='success.html';	
		}
		$('#myform').attr('action',url);
		//move cart
		delcart(cur_cart);
		$('#myform').submit();
		/*
		$.post(url,$('#myform').serialize(),function(back){
			if($('[name="content[4]"]').val()==1){
				window.location.href="pay.php";
			}else{
				window.location.href="pay.php";
			}
			
		},'html');*/
		
	}
	$('#huo').click(function(){
		$('#myform').removeAttr('target');
	});
	$('#zhi').click(function(){
		$('#myform').attr('target','_blank');
	});
	});
		</script>


</body>
</html>