<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>quzhou</title>
	<meta http-equiv="Cache-Control" content="no-transform" /> 
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<title>美百颜舒润洁面乳效果怎么样、多少钱、哪里有卖__美百颜官方网站</title>
<meta name="Description" content="美百颜舒润洁面乳,舒爽柔润，清透不紧绷,要想知道效果怎么样，多少钱，哪里有卖请点击美百颜官网" />
<meta name="Keywords" content="美百颜舒润洁面乳怎么样、美百颜舒润洁面乳多少钱" />
<!-- Bootstrap -->

<link href="../vense/css/bootstrap.min.css" rel="stylesheet">
<link href="../vense/css/vense.css" rel="stylesheet">
<link href="../vense/cssnew/vense.css" rel="stylesheet">

<link href="../vense/css/ding.css-v=1.15.css" rel="stylesheet">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript" src="../vense/js/jquery.min.js"></script>
<script type="text/javascript" src="../vense/js/jquery.cookie.js"></script>
<script type="text/javascript" src="../vense/js/cart.php"></script>
<script  type="text/javascript">window._pt_lt  =  new  Date().getTime();</script>

</head>
<body>




<div class="container">
		<div class="menu-url"> 当前位置：<a href="index.php">首页</a> &gt;
								<a href="list.php?cid=11">舒润系列</a>&gt; <a href="product.php?pid=12">舒润洁面乳</a> </div>
</div>
<div class="buying-details">
				<div id="myCarousel" class=" carousel slide pill-left col-lg-6 ">
			        <ol class="carousel-indicators carousel-detailspage">
					<li data-target="#myCarousel" data-slide-to="0" class="active"><img src="../vense/../vense/mono/images/201901261415037800.jpg"></li><li data-target="#myCarousel" data-slide-to="1" class=""><img src="../vense/../vense/mono/images/201901261415043639.jpg" alt="" ></li><li data-target="#myCarousel" data-slide-to="2" class=""><img src="../vense/mono/images/201901261415041119.jpg" alt="" ></li><li data-target="#myCarousel" data-slide-to="3" class=""><img src="../vense/../vense/mono/images/2019012614150512271.jpg" alt="" ></li><li data-target="#myCarousel" data-slide-to="4" class=""><img src="../vense/mono/images/2019012614150513911.jpg" alt="" ></li>			        </ol>
			        <div class="carousel-inner">
					<div class="item active"><img src="../vense/mono/images/201901261415037800.jpg" alt=""></div><div class="item"><img src="../vense/mono/images/201901261415043639.jpg" alt=""></div><div class="item"><img src="../vense/mono/images/201901261415041119.jpg" alt=""></div><div class="item"><img src="../vense/mono/images/2019012614150512271.jpg" alt=""></div><div class="item"><img src="../vense/mono/images/2019012614150513911.jpg" alt=""></div>			      	</div>
			       <!-- <a class="left carousel-control" href="#myCarousel" data-slide="prev"><</a>
			        <a class="right carousel-control" href="#myCarousel" data-slide="next">></a>-->
			    </div>
				<div class="col-lg-5 pull-left">
					<ul class="Product_information">
							<li><font>VENSE美百颜  </font>舒润洁面乳</li>
							<li>舒爽柔润，清透不紧绷</li>
							<li>
                            								<span>舒柔清爽</span>
                              								<span>补水不紧绷</span>
                              								<span>泡沫丰富</span>
                              								<span>洗去彩妆污垢</span>
                              								<span>150g</span>
                              							</li>
						
							<li>
								<span style="font-size:12px; color:#757575">商城价：<font style="font-size:24px; color:#010e80">￥86</font></span>&nbsp;&nbsp;
								<span style="font-size:12px; text-decoration:line-through; color:#757575">品牌指导价：￥86</span>
								<span class="tiwen">
									累计评价<a href="#pingjiasd">  121+  </a>   &nbsp;&nbsp; 商品提问   <a href="#shangpintiwen">6+</a>
								</span>
							</li>
							<li>
							<li><span><i class="iconfont">&#xe60d;</i>支持全国货到付款</span> <span style="float:right"><i class="iconfont">&#xe646;</i>支持微信 /支付宝 /网银/信用卡支付</span></li>   
							</li>
                           
                           
							<li><a href="javascript:void(0)" class="mask"><i class="iconfont">&#xe730;</i>即刻咨询肌肤顾问</a>
							<a href="https://h5.youzan.com/v2/feature/8yivcm0h" style="margin-left:310px"><img src="image/dian3.png"></a>
                            
                            
                            </li>   
							<li>
														<a href="cpshow.php?pid=13" class="ceping">查看评测报告</a>
							                            <span>数量：
                            <select name="selection"  id="proname_12">
                            <option value="1">1</option>
                            <option value="2" >2</option>
                            <option value="3">3</option>
                            <option value="4" >4</option>
                            <option value="5">5</option>
                            <option value="6" >6</option>
                            </select></span>
                            <!--
                            <span class="number">
									<a class="glyphicon glyphicon-minus number_jian" aria-hidden="true" name="subt" pro="proname_12" pid="12"></a>
									<input class="mmmm" type="text" value="1"  name="proname_12" id="proname_12" />
									<a class="glyphicon glyphicon-plus number_jia" aria-hidden="true" name="plus" pro="proname_12" pid="12"></a>
								</span>
                                -->
                            <a href="javascript:void()" class="joingwc tocart" pid="12">加入购物车</a></li>
                            <li><font>服务与支持：</font>     <span>7*24H 快速发货</span><span>支持全国货到付款</span><span>一对一会员服务指导</span></li>  
                            <li>
                            <div class="fenxiang bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1499828645242">
               <span>分享到：</span>
                 <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                    <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                    <a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
                    <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                </div>
                            </li>
					</ul>
					
					<div class="panel-group" id="accordion">
						
						
						</div>
					</div>
				</div>
                
                
                
				<div class="tuijian_box">
					<div class="tuijian_left"></div>
                    <div class="tuijian_right">
                    <h4>建议搭配使用</h4>
                                                                  <a href="product.php?pid=14"><img src="http://up.yiqiaitao.com/pinpai/vense/images/2017091816330819855.png"  alt="舒润滋养面膜" width="95"><span>舒润滋养面膜</span></a>
									
											                                               <a href="product.php?pid=23"><img src="http://up.yiqiaitao.com/pinpai/vense/images/201709181633347626.png"  alt="舒润柔肤乳" width="95"><span>舒润柔肤乳</span></a>
									
											                    
                    
                    </div>
				</div>
                
                
<div class="four_details">
	<div class="xq_dhqh">
    <ul>
    <li><a href="#miaoshu">详情描述</a></li>
    <li><a href="#jibencanshu">基本参数</a></li>
    <li><a href="#pingjiasd">评价晒单（121	）</a></li>
    <li><a href="#shangpintiwen">商品提问（6）</a></li>
    </ul>
    </div>
	<div class="xq_content">
    	<div class="xq_contentnr">
        <a name="miaoshu"></a>
        	<div class="xq_ms"><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2018122516184119637.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2017050514231389024.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2017050514231453445.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2018122516185056076.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2019012614171611068.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2017050514231569164.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2018122516190626685.jpg" /><img alt="" src="http://up.yiqiaitao.com/pinpai/vense/images/2018122516191315018.jpg" /><br /></div>
            <div class="xq_tit"><hr><a name="jibencanshu">产品基本信息</a><hr></div>
            <div class="xq_jbcs">
            <div class="xq_img"><img src="http://up.yiqiaitao.com/pinpai/vense/images/201801231540503662.png"></div>
            <div class="xq_js">
            <p class="p1"><b>产品名称：</b>舒润洁面乳</p>
            <p><b>功效：</b>温柔清洁肌肤，泡沫细腻舒润，清爽去污，并充分补水，带来洁净不紧绷的洁面体验</p>
            <p class="p1"><b>适合肤质：</b>油性肌肤  干性肌肤  混合性肌肤  </p>
            <p><b>质地：</b>白色的乳液质地细腻柔滑，肌肤触感水润，搓开后泡沫细腻，有淡雅清香，温柔清洁，洗后补水不紧绷。</p>
            <p class="p1"><b>净含量：</b>150g  </p>
            <p><b>主要成分/科技：</b>月桂醇聚醚硫酸酯钠、椰油酰胺丙基甜菜碱、月桂基葡糖苷、石榴果提取物、西洋接骨木果提取物</p>
            </div>
            </div>
            <div class="xq_tit"><hr><a name="pingjiasd">评价晒单</a><hr></div>
            <div class="xq_pingjia">
            	<div class="pingjia_left">
                <h3>最有帮助的评价<span><!--<input id="checkbox1" class="styled" type="checkbox">&nbsp;只显示带图评价--></span></h3>
                                <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>清***柔</span>
				<p>
					物流很快，前天买的，今天就到了。打开包装，产品的颜色就很清新，一看就有一种清爽感，效果应该不错。<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-08-06<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7767" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">191</font></a>
               <!--  <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7767">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                               <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>天***眼</span>
				<p>
					保湿效果非常好，用完没有紧绷感，用完，脸上滑滑的感觉。<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-08-05<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7766" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">362</font></a>
                <!-- <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7766">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                               <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>苏***吉</span>
				<p>
					这个洗面奶我已经买了三支了，还介绍同学买的，实惠又好用，我很喜欢，准备买了还要买<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-02-23<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7692" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">361</font></a>
                <!-- <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7692">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                               <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>小***谷</span>
				<p>
					产品用一段时间了，感觉清洁皮肤挺干净，美百颜家的老顾客了，现在在老师的指导下皮肤变的好很多了，真的谢谢你们的指导，赞赞<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-02-22<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7691" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">339</font></a>
               <!--  <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7691">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                               <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>多***8</span>
				<p>
					宝贝收到了 速度真的很快 东西还没有用 看起来挺不错的 是朋友推荐的  棒棒哒 过年快递恢复那么快， 在这个特殊的时期为快递点个赞 真心的满意满意 好评好评 下次有需要了肯定会回购的<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-02-22<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7690" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">412</font></a>
                <!-- <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7690">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                               <li>
				<span style="text-align:center; background:#efefef; padding:8px">会员<br>从***大</span>
				<p>
					老客户了，一直在用这款产品，非常好用补水效果超级好，冬天肌肤也没有干燥，毛孔也变小了，很好用的，推荐有需要的亲们购买哦<br>
					<span style="width:100%; margin:0">
											</span>
					<font style=" color: #b0b0b0; margin-top:0">
						2018-02-06<!--<a>赞 3</a>-->
					</font></p>
				<a href="javascript:void()" data-com="7689" class="click_number"><i class="iconfont">&#xe60f;</i><font class="zan_num_val">458</font></a>
                <!-- <div class="tijiaopl reply_div">
                	<input type="hidden"  class="reply_val" value="7689">
                    <input type="hidden"  class="id_value" value="IF3ZTNOBDH">
                	<input name="" type="text" placeholder="回复楼主" class="reply_con">
                	<input type="button" name="reply" class="answer-btn tosubmit" value="回复" >
                </div> -->
                                  <div style="clear:both"></div>
                </li>
                                                  
				<!-- <ul class="pagination">
				 <span class="disabled"></span> <li><a class="me">1</a></li>  <li><a href="/product.php?pid=12&page=2#pingjiasd">2</a> </li> <li><a href="/product.php?pid=12&page=3#pingjiasd">3</a> </li> <li><a href="/product.php?pid=12&page=2#pingjiasd">>></a></li>  <li><a href="/product.php?pid=12&page=21#pingjiasd">尾页</a></li>				</ul> -->
                </div>
            	<div class="pingjia_right">
                <h3>最新购买记录</h3>
                <div class="xq_jilu">
                <p>98.0<font>%</font></p>
                <p>购买后满意</p>
                <!--<p>628名用户投票</p>-->
                <span>购买记录：</span>
                <li> 
                <table class="upgd">
                <tr>
                    <td>用户</td>
                    <td>数量</td>
                    <td>评价</td>
                    <td>地区</td>
                </tr>
                </table>
                </li>
               
               
          <li> 
          	<iframe src="dd/index.php" height="500" scrolling="no" frameborder="0" width="350"></iframe></li>

                </div>
                </div>
                
            </div>
            
          <div class="xq_tit"><hr><a name="shangpintiwen">商品提问</a><hr></div>
           <div class="xq_question">
            	<!-- <div class="xq_tw"><form  action="" method="get">
   				<input type="hidden" id="pro_pid" value=12  placeholder="输入你的提问">
   				<input type="text" id="ask_val"  placeholder="输入你的提问">
       		 	<button class="btn " name="ask"  id="ask" type="button" value="tiwen">提问</button>
				</form>
                </div> -->
                <div class="xq_lb">
                <p class="tiwen"><a class="current">最有帮助</a> | <a>最新</a></p>
                
               <div class="helppro" style="display:block;" >
			                   <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="26"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">521</b></i></a><p>是正品吗？</p><font>2017年8月18日</font></li>
											<li><i class="iconfont"></i><span>官网直售，品质始终如一，品牌值得信赖</span><font>2017年8月18日</font></li>
					                </ul>

				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="243"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">299</b></i></a><p>男士可以用吗？</p><font>2017年8月29日</font></li>
											<li><i class="iconfont"></i><span>可以的，这款可以深层的清扫肌肤的残留，洗完之后很清爽</span><font>2017年8月29日</font></li>
					                </ul>

				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="27"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">222</b></i></a><p>好用吗，味道难闻吗？</p><font>2017年8月18日</font></li>
											<li><i class="iconfont"></i><span>淡淡的植物清香味，很清爽</span><font>2017年8月18日</font></li>
					                </ul>

				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="28"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">211</b></i></a><p>洗完一睁眼会觉得辣眼睛吗？</p><font>2017年8月18日</font></li>
											<li><i class="iconfont"></i><span>特别添加温和成分，在彻底清洁肌肤的同时不会对肌肤产生刺激，不会辣眼睛的哦</span><font>2017年8月18日</font></li>
					                </ul>

				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="241"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">168</b></i></a><p>油皮肤推荐吗</p><font>2017年8月29日</font></li>
											<li><i class="iconfont"></i><span>可以使用的，这款肌肤洗完之后没有油腻感，油性肌肤也可以使用的</span><font>2017年8月29日</font></li>
					                </ul>

				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="242"  data-pro-ptw="toptw">
                <i class="iconfont">&#xe623; <b class="pro_num_val">168</b></i></a><p>可以收缩毛孔祛痘吗</p><font>2017年8月29日</font></li>
											<li><i class="iconfont"></i><span>不能祛痘的哦，这款是清洁肌肤的，清洁干净了可以避免肌肤长痘</span><font>2017年8月29日</font></li>
					                </ul>

				             </div>
             
             
             
             
             <div class="helppro">
			                  <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="243"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">299</b></i></a><p>男士可以用吗？</p><font>2017年8月29日</font></li>
				                <li><i class="iconfont"></i><span>可以的，这款可以深层的清扫肌肤的残留，洗完之后很清爽</span><font>2017年8月29日</font></li>
				                </ul>
				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="242"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">168</b></i></a><p>可以收缩毛孔祛痘吗</p><font>2017年8月29日</font></li>
				                <li><i class="iconfont"></i><span>不能祛痘的哦，这款是清洁肌肤的，清洁干净了可以避免肌肤长痘</span><font>2017年8月29日</font></li>
				                </ul>
				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="241"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">168</b></i></a><p>油皮肤推荐吗</p><font>2017年8月29日</font></li>
				                <li><i class="iconfont"></i><span>可以使用的，这款肌肤洗完之后没有油腻感，油性肌肤也可以使用的</span><font>2017年8月29日</font></li>
				                </ul>
				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="28"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">211</b></i></a><p>洗完一睁眼会觉得辣眼睛吗？</p><font>2017年8月18日</font></li>
				                <li><i class="iconfont"></i><span>特别添加温和成分，在彻底清洁肌肤的同时不会对肌肤产生刺激，不会辣眼睛的哦</span><font>2017年8月18日</font></li>
				                </ul>
				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="27"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">222</b></i></a><p>好用吗，味道难闻吗？</p><font>2017年8月18日</font></li>
				                <li><i class="iconfont"></i><span>淡淡的植物清香味，很清爽</span><font>2017年8月18日</font></li>
				                </ul>
				                <ul>
                <li><a href="javascript:void(0)" class="pro_num_btn" data-pro-twid="26"  data-pro-ptw="toptw"><i class="iconfont">&#xe623; <b class="pro_num_val">521</b></i></a><p>是正品吗？</p><font>2017年8月18日</font></li>
				                <li><i class="iconfont"></i><span>官网直售，品质始终如一，品牌值得信赖</span><font>2017年8月18日</font></li>
				                </ul>
				             
             </div>
             
             
                </div>
            </div>
        </div>
    
    </div>
</div>



<!--<a data-click="悬浮顶部" class="scroll-top" href="javascript:scrollTo(0,0);"></a>-->


<script>
	
	$(function(){
  $('li.menufa').hover(function(){
	  
    $('li.menufa').find('.xilietc').hide();
    $(this).find('.xilietc').show();
  },function(){

	$('li.menufa').find('.xilietc').hide();
	});

});
	
	
   $(".mask").click(function(){
                $(".tcmack").fadeIn(400);
            });

            $(".mackclose").click(function(){
                $(".tcmack").fadeOut(400);
            }); 			
			

$(function(){
  $('li.ds1').hover(function(){
	  
    $('li.ds1').find('.protc').hide();
    $(this).find('.protc').show();
  },function(){

	$('li.ds1').find('.protc').hide();
	});

});
	
	
$('.scroll-top').hide();
	$(window).scroll(function(){
		var windowHeight = $(this).height();
		var scrollTop = $(window).scrollTop();
		if(scrollTop > windowHeight / 2){
			$('.scroll-top').show();
		}else{
			$('.scroll-top').hide();
		}
	});
$(function(){
$('.scroll-top').hover(function(){
	$(this).addClass('scroll-hover');
},function(){
	$(this).removeClass('scroll-hover');
});
})

</script>
<!--	<script type="text/javascript" src="http://open.yiqiaitao.com/get_info.php"></script>	-->
	<!--<script type="text/javascript">
	function fav()
	{
		if (document.all) {  
			try{
				window.external.addFavorite(window.location.href, document.title);
			}catch(e){
				window.external.addToFavoritesBar(window.location.href, document.title);
			}
		}else if(window.sidebar) {   
			window.sidebar.addPanel(document.title,window.location.href, "");   
		}else{
			alert('添加失败，请用Ctrl+D进行添加');
		}
		return false;
	}	
	</script>-->
<!--<div  style="position:fixed; right:10px; top:20%; width:140px;z-index:99999"><img src="images/right_img_celan.png" /></div>

<div style="text-align:center; padding:35px 0 10px 0px; font-size:12px; color:#999"><span id="tginfo"></span></div>-->
<!--<script src="http://open.yiqiaitao.com/winfo.php"></script>-->
<style>
/*.scroll-top{width:40px;height:40px; bottom:70px;right:40px; position:fixed;background:url(images/scrolltop.jpg) no-repeat;}
.scroll-hover{width:140px;background:url(images/scrolltopbg.jpg) no-repeat;}*/
</style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-88166597-1', 'auto');
  ga('send', 'pageview');

</script>


	<script>
	
	//var cart_display = "none";
    //var cartn_display = "none";//购物车显示购物车数量
    </script>
    

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
	

<script src="../vense/js/bootstrap.min.js"></script>
<script src="../vense/ace/assets/js/toastr-master/toastr.js"></script>
<script type="text/javascript" src="../vense/js/scroll.js"></script>
<script type="text/javascript">
$(".pro_num_btn").click(function(){
	var pro_num_btn = $(this);
	var pro_twid = pro_num_btn.attr("data-pro-twid");
	var pro_ptw = pro_num_btn.attr("data-pro-ptw");
	$.ajax({
				 type: "POST",
				 url: "product.php",
				 data: {
					 'pro_ptw':pro_ptw,
					 'pro_twid' : pro_twid,
					 },
				 dataType: "json",
				 success: function(data){
					if(data.status == '1') {
						 pro_num_btn.find('.pro_num_val').html(data.number);
					}
	
				 },
				 error: function(data){
					if(data.status == '0') {
						alert("点赞失败");
					}
				  }	
			});	
})
$(document).ready(function(e) {
          
			$(".tiwen a").hover(function(e) {
				$(".helppro").hide()
				$(".tiwen a").removeClass("current")
				$(this).addClass("current")
				$(".helppro").eq($(this).index()).show()
			});
	
        });
		
		

$("#goTotop").click(function(){  
        $('body,html').animate({scrollTop:0},1000); //点击按钮让其回到页面顶部  
    });  
	

    function getTop(){
        var top = $(document).scrollTop();
        if($(document).scrollTop()<610){
            $(".rightpf").css({
                'top':'610px',
            });
        } else {
            $(".rightpf").css('top','70px');
        }
        setTimeout(getTop);
    }
     
    getTop();


$(document).ready(function(){
	$('.list_lh li:even').addClass('lieven');
})
$(function(){
	$("div.list_lh").myScroll({
		speed:40, //数值越大，速度越慢
		rowHeight:68 //li的高度
	});
});
</script>
<script  type="text/javascript">

$('.carousel').carousel(100000);


if($('.xq_dhqh').length > 0){
var drop = $('.xq_dhqh').offset().top
    window.onscroll = function () {
        if ($(document).scrollTop() >  drop) {
            $(".xq_dhqh").addClass('tab-fixed');
        }
        else {
            $(".xq_dhqh").removeClass('tab-fixed');
        }
    }
}



$(".tosubmit").click(function(){
	var this_con = $(this).parent('.reply_div').find($(".reply_con")).val();
	var this_con = $.trim(this_con);
	var this_val = $(this).parent('.reply_div').find($(".reply_val")).val();
	var id_value = $(this).parent('.reply_div').find($(".id_value")).val();
	var reply = $(this).val();
	if(this_con == ''){
		getMsg('error','内容不允许为空');
		return false;
	}else{
		if(this_con.indexOf("http")>=0 || this_con.indexOf("com")>=0 || this_con.indexOf("cn")>=0 || this_con.indexOf("www")>=0){
			getMsg('error','内容非法');
			return false;
		}else{
			$.ajax({
				 type: "POST",
				 url: "product.php",
				 data: {
					 'reply':reply,
					 'replyval' : this_val,
					 'replycon' : this_con,
					 'id_value' : id_value
					 },
				 dataType: "json",
				 success: function(data){
					if(data.status == '1') {
						 $(".tosubmit").prop('disabled',true);
						getMsg("success","回复成功");
						setTimeout("window.location.reload()",2000);
					}
	
				 },
				 error: function(data){
					if(data.status == '0') {
						getMsg("error","回复失败");
					}
				  }	
			});
		}
	}
	
})


$("#ask").click(function(){
	var pro_pid = $("#pro_pid").val();	
	var ask_val = $("#ask_val").val();	
	var ask_val = $.trim(ask_val);
	var ask = $(this).val();	
	if(ask_val == ''){
		getMsg('error','请输入要提问的问题');
		return false;
	}else{
		$.ajax({
				 type: "POST",
				 url: "product.php",
				 data: {
					 'pro_pid' : pro_pid,
					 'ask' : ask,
					 'ask_val' : ask_val,
					 },
				 dataType: "json",
				 success: function(data){
					if(data.status == '1') {
						 $("#ask").prop('disabled',true);
						getMsg("success","提问成功,请等待回复");
						setTimeout("window.location.reload()",2000);
					}
	
				 },
				 error: function(data){
					if(data.status == '0') {
						getMsg("error","提问失败");
					}
				  }	
			});	
	}
})


$(".click_number").click(function(){
	var click_number = $(this);
	var com= click_number.attr("data-com");
	$.ajax({
				 type: "POST",
				 url: "product.php",
				 data: {
					 'comid' : com,
					 },
				 dataType: "json",
				 success: function(data){
					if(data.status == '1') {
						 click_number.find('.zan_num_val').html(data.number);
					}
	
				 },
				 error: function(data){
					if(data.status == '0') {
						alert("点赞失败");
					}
				  }	
			});	
})



function getMsg(ToastType,msg){
		toastr.options = {
		  "ToastType":'error',	
		  "closeButton": true,
		  "debug": false,
		  "progressBar": false,
		  "positionClass": "toast-top-right",
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "2000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		}
		Command: toastr[ToastType](msg);
	}
</script>
	<script>
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"分享到新浪微博",
			"bdMini":"1",
			"bdMiniList":["bdxc","tqf","douban","bdhome","sqq","thx","ibaidu","meilishuo","mogujie","diandian","huaban","duitang","hx","fx","youdao","sdo","qingbiji","people","xinhua","mail","isohu","yaolan","wealink","ty","iguba","fbook","twi","linkedin","h163","evernotecn","copy","print"],
			"bdPic":"","bdStyle":"1","bdSize":"32"},
			"share":{}
			};
		with(document)0[(
		getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5
		)];
	</script>

  
    <script src="../vense/js/ZeroClipboard.js"></script>
	<script>
		var g_url = window.location.href;
	    $('.share-copy-c input').val(g_url);
		var clip = new ZeroClipboard( document.getElementById("btnCopy"));
	</script>
</body>

</html>